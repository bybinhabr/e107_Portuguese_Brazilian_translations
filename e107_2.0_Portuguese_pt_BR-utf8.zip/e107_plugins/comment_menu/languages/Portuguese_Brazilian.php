<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/comment_menu/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("CM_L1", "N�o h� coment�rios ainda.");
define("CM_L2", "");
define("CM_L3", "Subt�tulo");
define("CM_L4", "N�mero de coment�rios a mostrar?");
define("CM_L5", "N�mero de caracteres a mostrar?");
define("CM_L6", "Postagem fixa para coment�rios muito extensos?");
define("CM_L7", "Mostrar t�tulos originais das not�cias no menu?");
define("CM_L8", "Configura��o do Menu Novos Coment�rios");
define("CM_L9", "Atualizar Configura��es do Menu");
define("CM_L10", "Configura��o do menu coment�rios salva.");
define("CM_L11", "em");
define("CM_L12", "Re:");
define("CM_L13", "Postado por");


?>
