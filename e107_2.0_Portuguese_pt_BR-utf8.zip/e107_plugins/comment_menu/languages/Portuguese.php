<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/comment_menu/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("CM_L1", "Não há comentários ainda.");
define("CM_L2", "");
define("CM_L3", "Subtítulo");
define("CM_L4", "Número de comentários a mostrar?");
define("CM_L5", "Número de caracteres a mostrar?");
define("CM_L6", "Postagem fixa para comentários muito extensos?");
define("CM_L7", "Mostrar títulos originais das notícias no menu?");
define("CM_L8", "Configuração do Menu Novos Comentários");
define("CM_L9", "Atualizar Configurações do Menu");
define("CM_L10", "Configuração do menu comentários salva.");
define("CM_L11", "em");
define("CM_L12", "Re:");
define("CM_L13", "Postado por");


?>