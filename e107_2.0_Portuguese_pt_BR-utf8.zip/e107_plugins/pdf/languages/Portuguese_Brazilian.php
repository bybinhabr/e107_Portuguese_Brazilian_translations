<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/pdf/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "Suporte � cria��o de arquivo PDF");
define("PDF_PLUGIN_LAN_3", "Configurar PDF");
define("PDF_PLUGIN_LAN_4", "Agora este plugin est� pronto para ser usado.");
define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "Prefer�ncias de PDF");
define("PDF_LAN_3", "sim");
define("PDF_LAN_4", "n�o");
define("PDF_LAN_5", "margem esquerda da p�gina");
define("PDF_LAN_6", "margem direita da p�gina");
define("PDF_LAN_7", "margem do topo da p�gina");
define("PDF_LAN_8", "fam�lia de fonte");
define("PDF_LAN_9", "tamanho padr�o da fonte");
define("PDF_LAN_10", "tamanho da fonte para o nome do site");
define("PDF_LAN_11", "tamanho da fonte para a url da p�gina");
define("PDF_LAN_12", "tamanho da fonte para o n�mero da p�gina");
define("PDF_LAN_13", "mostrar logo do site no pdf?");
define("PDF_LAN_14", "mostrar nome do site no pdf?");
define("PDF_LAN_15", "mostrar o nome do criador da p�gina (url) no pdf?");
define("PDF_LAN_16", "mostrar n�mero de p�gina no pdf?");
define("PDF_LAN_17", "atualizar");
define("PDF_LAN_18", "Prefer�ncias do PDF atualizadas com sucesso");
define("PDF_LAN_19", "P�gina");
define("PDF_LAN_20", "aviso de erro");

?>
