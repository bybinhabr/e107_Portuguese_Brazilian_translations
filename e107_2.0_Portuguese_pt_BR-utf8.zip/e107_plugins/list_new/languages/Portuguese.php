<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/list_new/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LIST_MENU_1", "adições recentes");
define("LIST_MENU_2", "por");
define("LIST_MENU_3", "em");
define("LIST_MENU_4", "em");
define("LIST_MENU_5", "dias");
define("LIST_MENU_6", "ver conteúdo de quantos dias?");
define("LIST_MENU_7", "");
define("LIST_MENU_8", "");
define("LIST_MENU_9", "");
define("LIST_MENU_10", "");
define("LIST_MENU_11", "");
define("LIST_MENU_12", "");
define("LIST_MENU_13", "");
define("LIST_MENU_14", "");
define("LIST_MENU_15", "");
define("LIST_MENU_16", "");
define("LIST_MENU_17", "");
define("LIST_MENU_18", "");
define("LIST_MENU_19", "");
define("LIST_NEWS_1", "notícias");
define("LIST_NEWS_2", "não há itens de notícia");
define("LIST_COMMENT_1", "comentários");
define("LIST_COMMENT_2", "sem comentários");
define("LIST_COMMENT_3", "notícias");
define("LIST_COMMENT_4", "faq");
define("LIST_COMMENT_5", "pesquisa");
define("LIST_COMMENT_6", "documentos");
define("LIST_COMMENT_7", "bugtrack");
define("LIST_COMMENT_8", "conteúdo");
define("LIST_COMMENT_9", "");
define("LIST_COMMENT_10", "ideias");
define("LIST_MEMBER_1", "membros");
define("LIST_MEMBER_2", "sem membros");
define("LIST_CONTENT_1", "conteúdo");
define("LIST_CONTENT_2", "nenhum conteúdo em");
define("LIST_CONTENT_3", "nenhuma categoria de conteúdo válida");
define("LIST_CHATBOX_1", "chatbox");
define("LIST_CHATBOX_2", "sem postagens no chatbox");
define("LIST_CALENDAR_1", "calendário");
define("LIST_CALENDAR_2", "sem eventos no calendário");
define("LIST_LINKS_1", "links");
define("LIST_LINKS_2", "sem links");
define("LIST_FORUM_1", "fórum");
define("LIST_FORUM_2", "sem postagens no fórum");
define("LIST_FORUM_3", "visualizações:");
define("LIST_FORUM_4", "respostas:");
define("LIST_FORUM_5", "última mensagem:");
define("LIST_FORUM_6", "em:");
define("LIST_LAN_1", "sem itens em");


?>