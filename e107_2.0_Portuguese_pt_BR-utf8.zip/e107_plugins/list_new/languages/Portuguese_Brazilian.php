<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/list_new/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) {define("PAGE_NAME", "Listar Novos �tens");}
define("LIST_PLUGIN_1", "Listar");
define("LIST_PLUGIN_2", "Este plugin permite ver uma lista de adi��es recentes em todas as categorias do e107. Poder� ver uma lista com dados desde a sua �ltima visita, ou ver uma lista geral das �ltimas adi��es. Tamb�m est� presente um menu. Todas as se��es s�o configur�veis na �rea de administra��o.");
define("LIST_PLUGIN_3", "Configurar Menu Principal");
define("LIST_PLUGIN_4", "O plugin List_new est� pronto para ser usado.");
define("LIST_PLUGIN_5", "Novos �tens");
define("LIST_PLUGIN_6", "Este plugin n�o est� instalado.");
define("LIST_ADMIN_1", "recentes");
define("LIST_ADMIN_2", "atualizar prefer�ncias");
define("LIST_ADMIN_3", "prefer�ncias atualizadas");
define("LIST_ADMIN_4", "se��o");
define("LIST_ADMIN_5", "menu");
define("LIST_ADMIN_6", "p�gina");
define("LIST_ADMIN_7", "ativar");
define("LIST_ADMIN_8", "desativar");
define("LIST_ADMIN_9", "abrir");
define("LIST_ADMIN_10", "fechar");
define("LIST_ADMIN_11", "atualizar");
define("LIST_ADMIN_12", "escolha");
define("LIST_ADMIN_13", "Bem Vindo � p�gina a lista ".SITENAME." ! Esta p�gina mostra as se��es mais comuns do site, uma lista com as mais recentes adi��es.");
define("LIST_ADMIN_14", "�ltimas adi��es");
define("LIST_ADMIN_15", "inseridas desde a sua �ltima visita");
define("LIST_ADMIN_16", "Bem Vindo � p�gina de ".SITENAME." ! Esta p�gina mostra as se��es mais comuns do site, uma lista com as novas adi��es desde a sua �ltima visita.");
define("LIST_ADMIN_SECT_1", "se��es");
define("LIST_ADMIN_SECT_2", "escolha que se��o mostrar");
define("LIST_ADMIN_SECT_3", "");
define("LIST_ADMIN_SECT_4", "estilo de visualiza��o");
define("LIST_ADMIN_SECT_5", "escolha quais se��es estar�o abertas por padr�o");
define("LIST_ADMIN_SECT_6", "");
define("LIST_ADMIN_SECT_7", "autor");
define("LIST_ADMIN_SECT_8", "escolha se o autor deve ser mostrado");
define("LIST_ADMIN_SECT_9", "");
define("LIST_ADMIN_SECT_10", "categoria");
define("LIST_ADMIN_SECT_11", "escolha se a categoria deve ser mostrada");
define("LIST_ADMIN_SECT_12", "");
define("LIST_ADMIN_SECT_13", "data");
define("LIST_ADMIN_SECT_14", "escolha se a data deve ser mostrada");
define("LIST_ADMIN_SECT_15", "");
define("LIST_ADMIN_SECT_16", "quantidade de �tens");
define("LIST_ADMIN_SECT_17", "escolha quantos �tens devem ser mostrados por se��o");
define("LIST_ADMIN_SECT_18", "");
define("LIST_ADMIN_SECT_19", "ordenar �tens");
define("LIST_ADMIN_SECT_20", "escolha a ordem pela qual as se��es devem ser mostradas");
define("LIST_ADMIN_SECT_21", "");
define("LIST_ADMIN_SECT_22", "�cone");
define("LIST_ADMIN_SECT_23", "escolha um �cone para cada se��o");
define("LIST_ADMIN_SECT_24", "");
define("LIST_ADMIN_SECT_25", "t�tulo");
define("LIST_ADMIN_SECT_26", "defina um t�tulo para cada se��o");
define("LIST_ADMIN_SECT_27", "");
define("LIST_ADMIN_OPT_1", "geral");
define("LIST_ADMIN_OPT_2", "p�gina recente");
define("LIST_ADMIN_OPT_3", "menu recente");
define("LIST_ADMIN_OPT_4", "nova p�gina");
define("LIST_ADMIN_OPT_5", "novo menu");
define("LIST_ADMIN_OPT_6", "op��es");
define("LIST_ADMIN_MENU_2", "�cone : padr�o");
define("LIST_ADMIN_MENU_3", "usar marca do theme por padr�o se nenhum �cone estiver presente ou se usar �cone estiver desativado");
define("LIST_ADMIN_MENU_4", "");
define("LIST_ADMIN_LAN_2", "t�tulo");
define("LIST_ADMIN_LAN_3", "defina um t�tulo");
define("LIST_ADMIN_LAN_4", "");
define("LIST_ADMIN_LAN_5", "�cone : usar");
define("LIST_ADMIN_LAN_6", "usar �cone de cada se��o");
define("LIST_ADMIN_LAN_7", "");
define("LIST_ADMIN_LAN_8", "caracteres");
define("LIST_ADMIN_LAN_9", "escolha quantos cabe�alhos ser�o mostrados");
define("LIST_ADMIN_LAN_10", "deixe em branco para mostrar todos os cabe�alhos");
define("LIST_ADMIN_LAN_11", "postfix");
define("LIST_ADMIN_LAN_12", "escolha um postfix se o cabe�alho for maior do que a quantidade de caracteres informado");
define("LIST_ADMIN_LAN_13", "deixe em branco para nenhum postfix");
define("LIST_ADMIN_LAN_14", "data");
define("LIST_ADMIN_LAN_15", "escolha um estilo para a data");
define("LIST_ADMIN_LAN_16", "Para mais informa��es sobre formatos de data, veja a <a href='http://www.php.net/manual/en/function.strftime.php' rel='external'>p�gina do php.net sobre a fun��o strftime</a>");
define("LIST_ADMIN_LAN_17", "data de hoje");
define("LIST_ADMIN_LAN_18", "escolha um estilo para a data se a data for hoje");
define("LIST_ADMIN_LAN_19", "Para mais informa��es sobre formatos de data, veja a <a href='http://www.php.net/manual/en/function.strftime.php' rel='external'>p�gina do php.net sobre a fun��o strftime</a>");
define("LIST_ADMIN_LAN_20", "colunas");
define("LIST_ADMIN_LAN_21", "escolha uma quantidade de colunas");
define("LIST_ADMIN_LAN_22", "defina quantas colunas quer usar. O n�mero que especificar ir� separar a p�gina em numa quantidade igual de colunas");
define("LIST_ADMIN_LAN_23", "texto de boas vindas");
define("LIST_ADMIN_LAN_24", "defina um texto de boas vindas que ser� mostrado no topo da p�gina");
define("LIST_ADMIN_LAN_25", "");
define("LIST_ADMIN_LAN_26", "mostrar vazio");
define("LIST_ADMIN_LAN_27", "defina se a mensagem tem que ser mostrada quando a se��o n�o tem resultados ");
define("LIST_ADMIN_LAN_28", "");
define("LIST_ADMIN_LAN_29", "�cone : padr�o");
define("LIST_ADMIN_LAN_30", "usar marca do theme padr�o se nenhum �cone estiver presente ou se o �cone a usar estiver desativado");
define("LIST_ADMIN_LAN_31", "");
define("LIST_ADMIN_LAN_32", "falha de tempo:dias");
define("LIST_ADMIN_LAN_33", "m�ximo de dias que os utilizadores podem ver. (dias passados)");
define("LIST_ADMIN_LAN_34", "");
define("LIST_ADMIN_LAN_35", "dias");
define("LIST_ADMIN_LAN_36", "falha de tempo");
define("LIST_ADMIN_LAN_37", "mostra uma caixa de sele��o com o n�mero de dias para ver. (dias passados)?");
define("LIST_ADMIN_LAN_38", "");
define("LIST_ADMIN_LAN_39", "abrir se os dados existirem");
define("LIST_ADMIN_LAN_40", "se��es que cont�m dados devem ser abertas por padr�o?");
define("LIST_ADMIN_LAN_41", "");
define("LIST_MENU_1", "recentes adi��es");
define("LIST_MENU_2", "por");
define("LIST_MENU_3", "no");
define("LIST_MENU_4", "em");
define("LIST_MENU_5", "dias");
define("LIST_MENU_6", "ver conte�do para quantos dias?");
define("LIST_MENU_7", "");
define("LIST_MENU_8", "");
define("LIST_MENU_9", "");
define("LIST_MENU_10", "");
define("LIST_MENU_11", "");
define("LIST_MENU_12", "");
define("LIST_MENU_13", "");
define("LIST_MENU_14", "");
define("LIST_MENU_15", "");
define("LIST_MENU_16", "");
define("LIST_MENU_17", "");
define("LIST_MENU_18", "");
define("LIST_MENU_19", "");
define("LIST_NEWS_1", "not�cias");
define("LIST_NEWS_2", "n�o h� �tens de not�cia");
define("LIST_COMMENT_1", "coment�rios");
define("LIST_COMMENT_2", "sem coment�rios");
define("LIST_COMMENT_3", "not�cias");
define("LIST_COMMENT_4", "faq");
define("LIST_COMMENT_5", "pesquisa");
define("LIST_COMMENT_6", "documentos");
define("LIST_COMMENT_7", "bugtrack");
define("LIST_COMMENT_8", "conte�do");
define("LIST_COMMENT_9", "download");
define("LIST_COMMENT_10", "id�ias");
define("LIST_DOWNLOAD_1", "downloads");
define("LIST_DOWNLOAD_2", "sem downloads");
define("LIST_MEMBER_1", "membros");
define("LIST_MEMBER_2", "sem membros");
define("LIST_CONTENT_1", "conte�do");
define("LIST_CONTENT_2", "nenhum conte�do em");
define("LIST_CONTENT_3", "nenhuma categoria de conte�do v�lida");
define("LIST_CHATBOX_1", "chatbox");
define("LIST_CHATBOX_2", "sem postagens no chatbox");
define("LIST_CALENDAR_1", "calend�rio");
define("LIST_CALENDAR_2", "sem eventos no calend�rio");
define("LIST_LINKS_1", "links");
define("LIST_LINKS_2", "sem links");
define("LIST_FORUM_1", "f�rum");
define("LIST_FORUM_2", "sem postagens no f�rum");
define("LIST_FORUM_3", "visualiza��es:");
define("LIST_FORUM_4", "respostas:");
define("LIST_FORUM_5", "�ltima mensagem:");
define("LIST_FORUM_6", "em:");


?>
