<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/trackback/languages/Portuguese_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/14 17:30:33 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_TRACKBACK_NAME", "Trackback");
define("LAN_PLUGIN_TRACKBACK_DESCRIPTION", "Este plugin ativa o uso de trackbacks nas suas postagens de notícias.");


?>