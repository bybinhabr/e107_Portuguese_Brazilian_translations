<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/forum/languages/Portuguese/Portuguese_menu.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/21 21:31:22 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_FORUM_MENU_001", "Postado por");
define("LAN_FORUM_MENU_002", "Sem postagens ainda");
define("LAN_FORUM_MENU_003", "Configurações do Menu de Novas Postagens do Fórum salvas");
define("LAN_FORUM_MENU_004", "Título");
define("LAN_FORUM_MENU_005", "Número de postagens a mostrar?");
define("LAN_FORUM_MENU_006", "Número de caracteres a mostrar?");
define("LAN_FORUM_MENU_007", "Sufixo para postagens muito longas?");
define("LAN_FORUM_MENU_008", "Mostrar tópico original no menu?");
define("LAN_FORUM_MENU_009", "Atualizar configurações de menu");
define("LAN_FORUM_MENU_0010", "Configurações do Menu de Novas Postagens do Fórum");
define("LAN_FORUM_MENU_0012", "Tempo máximo de postagens a exibir");
define("LAN_FORUM_MENU_0013", "Use zero em um site tranquilo; configurar um valor em dias vai reduzir o tempo de busca no banco de dados em um site mais visitado");


?>