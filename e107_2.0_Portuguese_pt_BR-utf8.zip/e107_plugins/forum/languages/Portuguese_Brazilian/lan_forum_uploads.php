<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/forum/languages/Portuguese_Brazilian/lan_forum_uploads.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Uploads do F�rum");
define("FRMUP_1", "Arquivos enviados no f�rum");
define("FRMUP_2", "Arquivo apagado");
define("FRMUP_3", "Erro: Imposs�vel apagar este arquivo");
define("FRMUP_4", "Apagamento do arquivo");
define("FRMUP_5", "Nome do arquivo");
define("FRMUP_6", "Resultado");
define("FRMUP_7", "Encontrado no t�pico");
define("FRMUP_8", "N�O ENCONTRADO");
define("FRMUP_9", "N�o h� arquivos enviados");
define("FRMUP_10", "Apagar");

?>
