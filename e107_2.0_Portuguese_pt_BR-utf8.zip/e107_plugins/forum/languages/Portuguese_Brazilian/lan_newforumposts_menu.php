<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/forum/languages/Portuguese_Brazilian/lan_newforumposts_menu.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("NFP_1", "Todas as �ltimas postagens est�o fora do alcance de sua classe de usu�rios, n�o h� como exibir.");
define("NFP_2", "N�o h� postagens ainda");
define("NFP_3", "Configura��o do menu de Novas Postagens no F�rum salvo");
define("NFP_4", "T�tulo");
define("NFP_5", "N�mero de postagens a mostrar?");
define("NFP_6", "N�mero de caracteres a mostrar?");
define("NFP_7", "Fixar postagens muito compridas?");
define("NFP_8", "Mostrar t�picos originais no menu?");
define("NFP_9", "Atualizar configura��es do menu");
define("NFP_10", "Configura��es do Menu de Novas Postagens no F�rum");
define("NFP_11", "Postado por");
define("NFP_12", "'Idade' m�xima (tempo de exist�ncia) para postagens serem mostradas");
define("NFP_13", "Usar zero em um site mais tranq�ilo; configurar o valor em dias ir� reduzir o tempo de busca no banco de dados em um site muito ocupado");


?>