<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/forum/languages/Portuguese_Brazilian/lan_forum_admin.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("FORLAN_1", "Voc� precisa digitar o n�mero de dias para a limpeza.");
define("FORLAN_2", "Favor selecionar se quer deletar os t�picos completamente ou fazer com que fiquem inativos (n�o s�o apagados, apenas n�o ficam vis�veis nos f�runs)");
define("FORLAN_3", "apagar");
define("FORLAN_4", "Marcar como inativo");
define("FORLAN_5", "Limpar completamente");
define("FORLAN_6", "Cancelar");
define("FORLAN_7", "Op��es do F�rum");
define("FORLAN_8", "F�runs limpos.");
define("FORLAN_9", "Limpeza n�o requerida.");
define("FORLAN_10", "Op��es Salvas");
define("FORLAN_11", "F�rum criado");
define("FORLAN_12", "F�rum atualizado");
define("FORLAN_13", "Categoria principal criada");
define("FORLAN_14", "Categoria principal atualizada");
define("FORLAN_15", "Favor marcar o box para confirmar a dele��o do f�rum");
define("FORLAN_16", "F�runs");
define("FORLAN_17", "N�o h� categorias principais ainda");
define("FORLAN_18", "Categorias Principais Existentes");
define("FORLAN_19", "Editar");
define("FORLAN_20", "Apagar");
define("FORLAN_21", "selecione para confirmar");
define("FORLAN_22", "Categoria Principal");
define("FORLAN_23", "Pode ser visto por");
define("FORLAN_24", "Indica quem pode ver o f�rum");
define("FORLAN_25", "Atualizar Categoria Principal");
define("FORLAN_26", "Criar Categoria Principal");
define("FORLAN_27", "Voc� precisa ao menos criar um categoria principal antes de criar um f�rum.");
define("FORLAN_28", "F�runs");
define("FORLAN_29", "N�o h� f�runs ainda");
define("FORLAN_30", "F�runs Existentes");
define("FORLAN_31", "Nome");
define("FORLAN_32", "Descri��o");
define("FORLAN_33", "Moderadores");
define("FORLAN_34", "Escolha a classe de usu�rios para moderar este f�rum");
define("FORLAN_35", "Atualizar F�rum");
define("FORLAN_36", "Criar F�rum");
define("FORLAN_37", "Ordem");
define("FORLAN_38", "Fechado");
define("FORLAN_39", "Membros Somente");
define("FORLAN_40", "Restrito");
define("FORLAN_41", "mover acima");
define("FORLAN_42", "mover abaixo");
define("FORLAN_43", "Pr�-Visualizar / Ordem do F�rum");
define("FORLAN_44", "Ocultar tabelas");
define("FORLAN_45", "Marque para renderizar o f�rum com as tabelas do tema");
define("FORLAN_46", "T�tulo mostrado na tabela se marcado o �tem <b>ocultar tabelas</b>");
define("FORLAN_47", "Ativar notifica��o por e-mail");
define("FORLAN_48", "Marque esta op��o para permitir aos usu�rios acesso � op��o de receber um e-mail quando algu�m responde a uma postagem no f�rum");
define("FORLAN_49", "Ativar pesquisas");
define("FORLAN_50", "Marque esta op��o para permitir que os usu�rios criem pesquisas nos f�runs - o plugin Pesquisa (Polls) deve estar instalado para usar essa fun��o");
define("FORLAN_51", "Ativar rastreamento/acompanhamento");
define("FORLAN_52", "Marque esta op��o para permitir que os usu�rios acompanhem os t�picos e sejam avisados por e-mail quando o t�pico for respondido");
define("FORLAN_53", "Prefixo do E-Mail");
define("FORLAN_54", "O texto que voc� digitar ser� o prefixo do assunto em qualquer e-mail enviado atrav�s do f�rum");
define("FORLAN_55", "Controle de t�pico popular");
define("FORLAN_56", "N�mero de postagens para fazer com que um t�pico seja popular");
define("FORLAN_57", "Postagens por p�gina");
define("FORLAN_58", "N�mero de postagens mostradas por p�gina");
define("FORLAN_59", "Limpar");
define("FORLAN_60", "Isto deletar� todos os t�picos que n�o receberam resposta no n�mero de dias que voc� digitar. <br /><b>Por favor, seja cuidadoso usando esta fun��o!</b>");
define("FORLAN_61", "Atualizar Op��es");
define("FORLAN_62", "Op��es de F�rum");
define("FORLAN_63", "Ranks");
define("FORLAN_64", "Digite os n�veis aqui. Se deixado em branco, estrelas gen�ricas ser�o usadas para mostrar os n�veis. Separe os n�veis com uma v�rgula. No m�ximo 10 n�veis, o mais baixo primeiro.");
define("FORLAN_65", "T�tulo do F�rum");
define("FORLAN_66", "Plugin de Pesquisas n�o est� instalado");
define("FORLAN_70", "Ativar anexos de arquivo/imagem");
define("FORLAN_71", "Permite aos usu�rios o envio de arquivo ou imagem nas suas postagens.");
define("FORLAN_72", "Atualizar Ordem");
define("FORLAN_73", "Ordem Atualizada");
define("FORLAN_75", "Categorias Principais");
define("FORLAN_76", "P�gina Inicial dos F�runs");
define("FORLAN_77", "Criar F�runs");
define("FORLAN_78", "Ordem dos F�runs");
define("FORLAN_79", "Prefer�ncias");
define("FORLAN_80", "Op��es");
define("FORLAN_81", "Tem certeza que quer apagar a categoria principal? - Os f�runs desta categoria ser�o apagados tamb�m!");
define("FORLAN_82", "Voc� tem certeza que quer apagar este f�rum?");
define("FORLAN_83", "Criar Categorias Principais");
define("FORLAN_84", "Membros Somente");
define("FORLAN_85", "Leitura Somente");
define("FORLAN_86", "Administradores Somente");
define("FORLAN_87", "Limpar t�picos sem respostas nesses dias:");
define("FORLAN_88", "Limpar t�picos sem respostas nesses dias:");
define("FORLAN_89", "Apagar postagens completamente");
define("FORLAN_90", "Deixar as postagens inativas");
define("FORLAN_91", "postagem(ns) ficou(ram) inativa(s)");
define("FORLAN_92", "t�pico(s) apagado(s)");
define("FORLAN_93", "resposta(s) apagada(s)");
define("FORLAN_94", "Configurar os Ranks");
define("FORLAN_95", "Ranks salvos");
define("FORLAN_96", "F�rum apagado");
define("FORLAN_97", "Categoria principal apagada");
define("FORLAN_98", "Nome do Ranking");
define("FORLAN_99", "n�mero de pontos antes de mudar de n�vel");
define("FORLAN_100", "enviar imagens para a pasta e107_themes/seu_tema/forum/");
define("FORLAN_101", "Admin Principal do Site");
define("FORLAN_102", "Controle");
define("FORLAN_103", "Admin do Site");
define("FORLAN_104", "Imagem do Ranking");
define("FORLAN_105", "Moderador do F�rum");
define("FORLAN_106", "Tipo de Limpeza:");
define("FORLAN_107", "F�rum");
define("FORLAN_108", "apagado");
define("FORLAN_109", "dias:");
define("FORLAN_110", "Limpar");
define("FORLAN_111", "desativado");
define("FORLAN_112", "Ativar Redirecionador");
define("FORLAN_113", "Marque esta op��o para fazer o navegador redirecionar � p�gina do f�rum depois de cada resposta");
define("FORLAN_114", "T�tulo Customizado do Usu�rio");
define("FORLAN_115", "Marque esta op��o para permitir que os usu�rios mudem os T�tulos Personalizados");
define("FORLAN_116", "Postagens Reportadas");
define("FORLAN_117", "Ir� apagar os dados das postagens reportadas. N�o a postagem em si.");
define("FORLAN_118", "Postagem reportada apagada");
define("FORLAN_120", "Marque esta op��o para permitir os usu�rios a criarem T�tulos Personalizados");
define("FORLAN_121", "N�o h� postagens reportadas");
define("FORLAN_122", "Clique aqui para enviar um e-mail ao admin quando algu�m reporta uma postagem");
define("FORLAN_123", "Regras do F�rum");
define("WMGLAN_1", "Regras para Visitantes");
define("WMGLAN_2", "Regras para Membros");
define("WMGLAN_3", "Regras para Administradores");
define("WMGLAN_4", "Enviar");
define("WMGLAN_5", "Configurar as Regras do F�rum");
define("WMGLAN_6", "Ativar?");
define("FORLAN_126", "Mostrar Dicas");
define("FORLAN_127", "Clique para mostrar um bal�o com dicas contendo a primeira postagem do t�pico quando o mouse passar por cima do nome do mesmo.");
define("FORLAN_128", "Tamanho da dica");
define("FORLAN_129", "Ir� determinar o n�mero de caracteres a serem exibidos no bal�o com a dica.");
define("FORLAN_130", "clique aqui");
define("FORLAN_131", "para configurar o tamanho m�ximo de arquivo, tipos permitidos, etc.");
define("FORLAN_132", "Enfatizar T�picos");
define("FORLAN_133", "D� �nfase especial a t�picos marcando-os (separe se��es de t�picos e cabe�alhos)");
define("FORLAN_134", "Largura m�xima de imagem enviada");
define("FORLAN_135", "Deixar em branco para desativar a reamostragem autom�tica");
define("FORLAN_136", "Criar link para a imagem em tamanho original");
define("FORLAN_137", "Ative para reamostrar imagens grandes e criar um link para o tamanho original.  Se desativado, a imagem original ser� descartada");
define("FORLAN_138", "Limpar os seguintes f�runs");
define("FORLAN_139", "Para usar esta op��o, voc� precisa 'Ativar a postagem de imagem' na <a href='".e_ADMIN."image.php'>p�gina de imagens</a>");
define("FORLAN_140", "Ver");
define("FORLAN_141", "postagem");
define("FORLAN_142", "Permiss�o de postagem");
define("FORLAN_143", "Indica quem pode postar no f�rum");
define("FORLAN_144", "Configura��o de moderadores");
define("FORLAN_145", "Configurar sub-f�runs");
define("FORLAN_146", "N�o h� sub-f�runs ainda");
define("FORLAN_147", "Atualizar sub-f�runs");
define("FORLAN_148", "Criar sub-f�runs");
define("FORLAN_149", "sub-f�runs");
define("FORLAN_150", "sub-f�rum");
define("FORLAN_151", "ID");
define("FORLAN_152", "postagens");
define("FORLAN_153", "Ferramentas");
define("FORLAN_154", "Resposta Apagada");
define("FORLAN_155", "Categorias do F�rum");
define("FORLAN_156", "Selecione o(s) f�rum(ns) para realizar a a��o");
define("FORLAN_157", "Todos os F�runs");
define("FORLAN_158", "Recalcular a informa��o da �ltima postagem do f�rum");
define("FORLAN_159", "Selecione para recalcular a informa��o de �ltima postagem");
define("FORLAN_160", "Selecione para realizar a opera��o neste f�rum apenas, n�o em t�picos");
define("FORLAN_161", "Recalcular contagem de postagens / respostas");
define("FORLAN_162", "Selecione para recalcular a contagem dos t�picos e respostas do f�rum");
define("FORLAN_163", "Recalcular a contagem de postagem de usu�rios no f�rum");
define("FORLAN_164", "Selecione para recalcular a contagem de usu�rios no f�rum");
define("FORLAN_165", "Executar fun��es");
define("FORLAN_166", "Ferramentas do F�rum");
define("FORLAN_167", "Contagens atualizadas para o f�rum");
define("FORLAN_168", "Informa��o das �ltimas postagens atualizadas para o f�rum");
define("FORLAN_169", "Contagem de usu�rio no f�rum atualizada");
define("FORLAN_170", "Comunicados");
define("FORLAN_171", "Comunicados nas postagens do f�rum");
define("FORLAN_172", "Apagar este Comunicado");
define("FORLAN_173", "T�tulo do t�pico");
define("FORLAN_174", "Reportado pelo usu�rio");
define("FORLAN_175", "Comunicado Enviado");
define("FORLAN_176", "Comunicar");
define("FORLAN_177", "Notifica��o por e-mail ativada por padr�o");
define("FORLAN_178", "Marque para que o checkbox da notifica��o por e-mail fique ativado por padr�o");
define("FORLAN_179", "(Adicionando um * no come�o do nome do f�rum far� deste f�rum um recipiente para sub-f�runs somente. O tema do f�rum deve suportar esta op��o tamb�m.)");
define("FORLAN_180", "Confirmar a opera��o de apagar");
define("FORLAN_181", "Confirme a Dele��o");
define("FORLAN_182", "tamb�m recalcular as respostas para todos os t�picos no f�rum selecionado");
define("FORLAN_183", "(esta fun��o n�o � permitida quando selecionar 'todos os f�runs' dado o n�mero de perguntas que ir� gerar)");


?>