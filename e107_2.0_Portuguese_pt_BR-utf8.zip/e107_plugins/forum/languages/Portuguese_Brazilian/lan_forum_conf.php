<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/forum/languages/Portuguese_Brazilian/lan_forum_conf.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("FORLAN_5", "Pesquisa apagada.");
define("FORLAN_6", "T�pico apagado");
define("FORLAN_7", "respostas apagadas");
define("FORLAN_8", "Dele��o cancelada.");
define("FORLAN_9", "T�pico movido.");
define("FORLAN_10", "Remo��o cancelada.");
define("FORLAN_11", "Voltar para os F�runs");
define("FORLAN_12", "Configura��o do F�rum");
define("FORLAN_13", "Tem certeza absoluta que quer apagar esta pesquisa?<br />Uma vez apagada ela <b><u>n�o poder�</u></b> ser ativada novamente.");
define("FORLAN_14", "Cancelar");
define("FORLAN_15", "Confirmar Apagar Postagem do F�rum");
define("FORLAN_16", "Confirmar Apagar Pesquisa");
define("FORLAN_17", "postado por");
define("FORLAN_18", "Voc� tem certeza absoluta que quer apagar este f�rum?");
define("FORLAN_19", "T�picos e postagens relacionados?");
define("FORLAN_20", "a pesquisa tamb�m ser� apagada");
define("FORLAN_21", "Tamb�m apagar");
define("FORLAN_22", "postagem?<br />Uma vez apagado");
define("FORLAN_23", "n�o poder�</u></b> ser revisto");
define("FORLAN_24", "Mover t�pico para o f�rum");
define("FORLAN_25", "Mover T�pico");
define("FORLAN_26", "Apagar resposta");
define("FORLAN_27", "movido");
define("FORLAN_28", "N�o � poss�vel renomear o t�tulo do t�pico");
define("FORLAN_29", "Adicionar");
define("FORLAN_30", "para o t�tulo");
define("FORLAN_31", "Renomear para:");
define("FORLAN_32", "Op��es de renomear t�picos:");

?>
