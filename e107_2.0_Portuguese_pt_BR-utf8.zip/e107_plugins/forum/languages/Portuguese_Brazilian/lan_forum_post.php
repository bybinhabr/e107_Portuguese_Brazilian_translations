<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/forum/languages/Portuguese_Brazilian/lan_forum_post.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "F�rum");
define("LAN_01", "F�runs");
define("LAN_02", "Responder para:");
define("LAN_03", "Novo T�pico");
define("LAN_1", "Normal");
define("LAN_2", "Marcado");
define("LAN_3", "An�ncio");
define("LAN_4", "Postar Pesquisa");
define("LAN_5", "Pergunta da Pesquisa:");
define("LAN_6", "Adicionar outra op��o");
define("LAN_7", "Op��es de voto:");
define("LAN_8", "Permitir voto de todos");
define("LAN_9", "Permitir votos de membros somente");
define("LAN_10", "Login");
define("LAN_11", "Lembrar de mim");
define("LAN_16", "Usu�rio:");
define("LAN_17", "Senha:");
define("LAN_20", "Erro");
define("LAN_27", "Voc� deixou campo(s) requerido(s) em branco");
define("LAN_28", "Voc� n�o postou nada...");
define("LAN_29", "Editado");
define("LAN_45", "Estes f�runs s� podem receber postagens de membros registrados e logados, favor clicar");
define("LAN_60", "Iniciar Novo T�pico");
define("LAN_61", "Seu Nome:");
define("LAN_62", "Assunto:");
define("LAN_63", "Postagem:");
define("LAN_64", "Enviar novo t�pico");
define("LAN_73", "Resposta:");
define("LAN_74", "Responder para t�pico");
define("LAN_77", "Atualizar T�pico");
define("LAN_78", "Atualizar Resposta");
define("LAN_94", "Postado por");
define("LAN_95", "Sem autoriza��o");
define("LAN_96", "Voc� n�o est� autorizado a editar esta postagem.");
define("LAN_100", "T�pico");
define("LAN_101", "�ltimo");
define("LAN_102", " respostas");
define("LAN_103", "Rever t�pico. (Ir� abrir uma nova janela.)");
define("LAN_133", "Muito Obrigado");
define("LAN_174", "Registrar");
define("LAN_175", "Login");
define("LAN_212", "Esqueceu a senha?");
define("LAN_310", "N�o h� como acessar a postagem com este usu�rio - se este � o seu usu�rio, favor fazer login para postar.");
define("LAN_311", "An�nimo");
define("LAN_322", "Postado:");
define("LAN_323", "Pr�-visualizar");
define("LAN_324", "Sua mensagem foi postada com sucesso.");
define("LAN_325", "Clique aqui para ver sua mensagem");
define("LAN_326", "Clique aqui para voltar ao f�rum");
define("LAN_327", "Rever");
define("LAN_380", "Se voc� quiser ser notificado por e-mail quando uma resposta for dada ao seu t�pico, clique no box");
define("LAN_381", "Resposta no f�rum de");
define("LAN_382", "Postagem(ns) realizada(s):");
define("LAN_383", "Favor clicar no link para ver o t�pico completo...");
define("LAN_384", "Resposta ao f�rum em");
define("LAN_385", "Postagem:");
define("LAN_386", "Se voc� n�o quer adicionar uma pesquisa, deixe os campos em branco");
define("LAN_387", "Ok");
define("LAN_388", "Voltar ao topo");
define("LAN_389", "Postagem duplicada, redirecionando ...");
define("LAN_390", "Anexar arquivo / imagem");
define("LAN_391", "Op��es");
define("LAN_392", "Arquivo para anexar");
define("LAN_393", "<b>Aten��o!</b><br />Tipos de arquivo permitidos:");
define("LAN_394", "Qualquer outro tipo de arquivo enviado ser� apagado instantaneamente.");
define("LAN_395", "Tamanho m�ximo de arquivo");
define("LAN_396", "bytes");
define("LAN_397", "Este t�pico est� fechado.");
define("LAN_398", "Este f�rum � somente leitura");
define("LAN_399", "Voc� n�o est� autorizado a postar neste f�rum.");
define("LAN_400", "postar t�pico como");
define("LAN_401", "Ir para");
define("LAN_402", "pesquisa");
define("LAN_403", "an�ncio");
define("LAN_404", "marcado");
define("LAN_405", "F�runs");
define("LAN_406", "Re:");
define("LAN_407", "Redirecionar");
define("LAN_408", "Se o seu navegador n�o suporta redirecionamento, favor clicar");
define("LAN_409", "AQUI");
define("LAN_410", "para ser redirecionado");
define("LAN_411", "aqui");
define("LAN_412", "para ir at� a pagina de registro");
define("LAN_413", "Sua pesquisa foi postada com sucesso.");
define("LAN_414", "Clique Aqui para ver sua pesquisa");
define("LAN_415", "Sua resposta foi postada com sucesso.");
define("LAN_416", "Anexar arquivo");
define("LAN_417", "Adicionar outro anexo");
define("POLL_506", "Permitir m�ltiplas escolhas?");
define("POLL_507", "sim");
define("POLL_508", "n�o");
define("LAN_FORUM_1", "Uploads n�o permitidos: ".e_FILE."diret�rio p�blico n�o tem permiss�o de escrita");
define("LAN_FORUM_2", "Postagem duplicada");

?>
