<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/forum/languages/Portuguese_Brazilian/lan_forum_viewtopic.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "F�rum");
define("LAN_01", "F�runs");
define("LAN_02", "Ir para p�gina");
define("LAN_03", "Ok");
define("LAN_04", "Anterior");
define("LAN_05", "Pr�ximo");
define("LAN_06", "Registrado");
define("LAN_07", "Localiza��o");
define("LAN_08", "Website");
define("LAN_09", "Visitas ao site desde o registro");
define("LAN_10", "Voltar para o topo");
define("LAN_65", "Ir para");
define("LAN_66", "Este t�pico est� fechado agora");
define("LAN_67", "postagens");
define("LAN_194", "Visitantes");
define("LAN_195", "Membros Registrados");
define("LAN_321", "Moderadores:");
define("LAN_389", "T�pico anterior");
define("LAN_390", "T�pico seguinte");
define("LAN_391", "Rastrear T�pico");
define("LAN_392", "Cancelar Rastreamento do T�pico");
define("LAN_393", "Resposta R�pida");
define("LAN_394", "Pr�-visualizar");
define("LAN_395", "Responder ao T�pico");
define("LAN_396", "Website");
define("LAN_397", "E-Mail");
define("LAN_398", "Perfil");
define("LAN_399", "Mensagem Privada");
define("LAN_400", "Editar");
define("LAN_401", "Citar");
define("LAN_402", "Autor");
define("LAN_403", "Postagem");
define("LAN_404", "N�o h� t�pico anterior");
define("LAN_405", "N�o h� t�pico seguinte");
define("LAN_406", "Moderador: Editar");
define("LAN_435", "Moderador: Apagar");
define("LAN_408", "Moderador: Mover");
define("LAN_409", "Tem certeza que quer deletar este t�pico e todas as respostas?");
define("LAN_410", "Tem certeza que quer deletar esta resposta?");
define("LAN_411", "postador por");
define("LAN_412", "T�tulo");
define("LAN_413", "Reportar");
define("LAN_414", "Reportar este t�pico para o moderador");
define("LAN_415", "T�tulo do t�pico");
define("LAN_416", "Digite seu comunicado");
define("LAN_417", "O administrador ir� analisar o t�pico. Voc� pode postar uma mensagem explicando o que voc� encontrou de errado no t�pico.");
define("LAN_418", "<b>N�o</b> use este formul�rio para entrar em contato com o administrador por qualquer outro motivo.");
define("LAN_419", "Enviar Comunicado");
define("LAN_420", "Clique para ver a postagem");
define("LAN_421", "T�pico do f�rum reportado por");
define("LAN_422", "Esta postagem foi reportada do site");
define("LAN_423", "Mensagem n�o pode ser enviada.");
define("LAN_424", "A Postagem foi reportado ao moderador.<br />Muito Obrigado.");
define("LAN_425", "Mensagem de:");
define("LAN_426", "Reportando postagem no t�pico:");
define("LAN_427", "Erro enviando e-mail");
define("LAN_428", "Postagem foi reportada");
define("LAN_429", "Clique aqui para retornar ao f�rum");
define("LAN_430", "pesquisa");
define("FORLAN_26", "Resposta apagada");
define("FORLAN_10", "Come�ar Novo T�pico");
define("LAN_29", "Editado");
define("LAN_431", "Distribua este t�pico: rss 0.92");
define("LAN_432", "Distribua este t�pico: rss 2.0");
define("LAN_433", "Distribua este t�pico: RDF");
define("FORLAN_101", "Enviar T�pico por E-Mail");
define("FORLAN_102", "Vers�o para Impress�o");
define("FORLAN_103", "[usu�rio apagado]");
define("FORLAN_104", "T�pico n�o encontrado");
define("FORLAN_HIDDEN", "OCULTAR - LOGIN E RESPONDER PARA REVELAR");

?>
