<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/forum/languages/Portuguese_Brazilian/lan_forum_stats.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("e_PAGETITLE", "Estat�sticas do F�rum");
define("FSLAN_1", "Geral");
define("FSLAN_2", "F�rum aberto");
define("FSLAN_3", "Aberto h�");
define("FSLAN_4", "Total de postagens");
define("FSLAN_5", "T�picos do f�rum");
define("FSLAN_6", "Respostas do f�rum");
define("FSLAN_7", "T�picos do f�rum visualizados");
define("FSLAN_8", "Tamanho da base de dados (tabelas do f�rum apenas)");
define("FSLAN_9", "M�dia de tamanho de c�lula na tabela do f�rum");
define("FSLAN_10", "T�picos mais ativos");
define("FSLAN_11", "Rank");
define("FSLAN_12", "T�pico");
define("FSLAN_13", "Respostas");
define("FSLAN_14", "Iniciado por");
define("FSLAN_15", "Data");
define("FSLAN_16", "T�picos mais visualizados");
define("FSLAN_17", "Visualizados");
define("FSLAN_18", "Maiores postadores");
define("FSLAN_19", "Nome");
define("FSLAN_20", "Postagens");
define("FSLAN_21", "Maiores iniciadores de t�picos");
define("FSLAN_22", "Maiores postadores de respostas");
define("FSLAN_23", "Estat�sticas do F�rum");
define("FSLAN_24", "M�dia de postagens por dia");

?>
