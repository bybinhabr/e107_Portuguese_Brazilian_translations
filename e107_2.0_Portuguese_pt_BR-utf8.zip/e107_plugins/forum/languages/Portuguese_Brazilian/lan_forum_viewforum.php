<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/forum/languages/Portuguese_Brazilian/lan_forum_viewforum.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "F�rum");
define("LAN_01", "F�runs");
define("LAN_02", "Voltar para o topo");
define("LAN_03", "Ok");
define("LAN_53", "T�pico");
define("LAN_54", "Iniciado por");
define("LAN_55", "Respostas");
define("LAN_56", "Visualiza��es");
define("LAN_57", "�ltima Postagem");
define("LAN_58", "N�o h� t�picos neste f�rum ainda.");
define("LAN_59", "Voc� precisa ser um membro registrado e logado para postar neste f�rum. Clique em registre-se ou fa�a login no menu.");
define("LAN_79", "Novas postagens");
define("LAN_80", "N�o h� novas postagens");
define("LAN_81", "Fechar t�pico");
define("LAN_180", "Buscar");
define("LAN_199", "Posts n�o lidos existentes");
define("LAN_202", "Marcado");
define("LAN_203", "Marcado/Fechado");
define("LAN_204", "Voc� <b>pode</b> come�ar novos t�picos");
define("LAN_205", "Voc� <b>n�o pode</b> come�ar novos t�picos");
define("LAN_206", "Voc� <b>pode</b> postar respostas");
define("LAN_207", "Voc� <b>n�o pode</b> postar respostas");
define("LAN_208", "Voc� <b>pode</b> editar suas postagens");
define("LAN_209", "Voc� <b>n�o pode</b> editar suas postagens");
define("LAN_316", "Ir para p�gina:");
define("LAN_317", "Nenhum");
define("LAN_321", "Moderadores:");
define("LAN_395", "[popular]");
define("LAN_396", "An�ncio");
define("LAN_397", "Este f�rum � somente leitura");
define("LAN_398", "Desmarcar t�pico");
define("LAN_399", "Bloquear t�pico");
define("LAN_400", "Desbloquear t�pico");
define("LAN_401", "Marcar t�pico");
define("LAN_402", "Mover t�pico");
define("LAN_403", "Ir para o f�rum");
define("LAN_404", "Este f�rum � moderado por");
define("LAN_405", "usu�rios navegando no f�rum neste momento");
define("LAN_406", "usu�rios navegando no f�rum neste momento");
define("LAN_407", "membro");
define("LAN_408", "visitante");
define("LAN_409", "membros");
define("LAN_410", "visitantes");
define("LAN_411", "T�picos Importantes");
define("LAN_412", "T�picos do F�rum");
define("LAN_431", "Distribua este f�rum: rss 0.92");
define("LAN_432", "Distribua este f�rum: rss 2.0");
define("LAN_433", "Distribua este f�rum: RDF");
define("LAN_434", "Tem certeza que quer deletar este t�pico e todas as respostas?");
define("LAN_435", "T�pico apagado");
define("FORLAN_CLOSE", "T�pico fechado");
define("FORLAN_OPEN", "T�pico re-aberto.");
define("FORLAN_STICK", "T�pico marcado.");
define("FORLAN_UNSTICK", "T�pico desmarcado.");
define("FORLAN_6", "T�pico apagado");
define("FORLAN_7", "respostas apagadas");
define("FORLAN_8", "aqui");
define("FORLAN_9", "para registrar ou fa�a login no menu.");
define("FORLAN_10", "Come�ar Novo T�pico");
define("FORLAN_11", "Novas Postagens");
define("FORLAN_12", "N�o h� Novas Postagens");
define("FORLAN_13", "Novas Postagens em T�pico Popular");
define("FORLAN_14", "N�o h� Novas Postagens em T�pico Popular");
define("FORLAN_15", "Marcar T�pico");
define("FORLAN_16", "Fechar T�pico Marcado");
define("FORLAN_17", "T�pico de An�ncio");
define("FORLAN_18", "Fechar T�pico");
define("FORLAN_19", "[usu�rio apagado]");
define("FORLAN_20", "Sub-f�rum");
define("FORLAN_21", "T�picos");
define("FORLAN_22", "�ltima Postagem");

?>
