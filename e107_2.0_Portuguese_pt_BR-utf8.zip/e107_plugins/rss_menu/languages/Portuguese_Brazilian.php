<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/rss_menu/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("RSS_LAN05", "N�mero de �tens (0=inativo)");
define("RSS_MENU_L1", "podem ser distribu�das usando os alimentadores RSS.");
define("RSS_MENU_L2", "Alimentadores RSS");
define("RSS_MENU_L3", "Nossas not�cias ");
define("RSS_MENU_L4", "Nossos Coment�rios");
define("RSS_MENU_L5", "Nossos t�picos dos F�runs");
define("RSS_MENU_L6", "Nossas postagens dos f�runs");
define("RSS_MENU_L7", "Nossas postagens no Chat");
define("RSS_MENU_L8", "Nossas postagens no bugtracker");
define("RSS_MENU_L9", "Nossos downloads");
define("RSS_NEWS", "Not�cias");
define("RSS_COM", "Coment�rios");
define("RSS_ART", "Artigos");
define("RSS_REV", "Revis�es");
define("RSS_FT", "T�picos do F�rum");
define("RSS_FP", "Postagens do F�rum");
define("RSS_FSP", "Postagem Espec�fica do F�rum");
define("RSS_BUG", "Bugtracker");
define("RSS_FOR", "F�rum");
define("RSS_DL", "Downloads");
define("RSS_PLUGIN_LAN_1", "RSS");
define("RSS_PLUGIN_LAN_6", "Links de alimentadores");
define("RSS_PLUGIN_LAN_7", "RSS das not�cias");
define("RSS_PLUGIN_LAN_8", "RSS dos downloads");
define("RSS_PLUGIN_LAN_9", "RSS dos coment�rios");
define("RSS_PLUGIN_LAN_10", "RSS das categorias de not�cias:");
define("RSS_PLUGIN_LAN_11", "RSS das categorias de download:");
define("RSS_PLUGIN_LAN_14", "Coment�rios");
define("RSS_LAN_ADMINMENU_1", "Op��es de RSS");
define("RSS_LAN_ADMINMENU_2", "Listando");
define("RSS_LAN_ADMINMENU_4", "Importar");
define("RSS_LAN_ERROR_1", "Este n�o � um alimentador RSS v�lido<br /><br /><a href='".e_SELF."'><< retornar para a listagem de alimentadores RSS</a>");
define("RSS_LAN_ERROR_2", "Seu arquivo e107_config.php ou seus arquivos de idioma cont�m espa�os ou caracteres como ï»¿﻿ antes do caractere <? . Voc� precisa remover isto com um editor n�o-UTF-8 para ter um alimentador RSS v�lido.");
define("RSS_LAN_ERROR_3", "Nenhum alimentador RSS presente ainda.<br />Favor usar a fun��o importar para disponibilizar alimentadores RSS ou criar um manualmente.");
define("RSS_LAN_ERROR_4", "N�o h� alimentadores RSS dispon�veis ainda.");
define("RSS_LAN_ERROR_5", "Esta entrada RSS n�o existe");
define("RSS_LAN_ERROR_6", "N�o h� alimentadores RSS para importar");
define("RSS_LAN_ERROR_7", "Alguns campos requeridos est�o faltando.");
define("RSS_LAN_ADMIN_1", "RSS existentes");
define("RSS_LAN_ADMIN_2", "ID");
define("RSS_LAN_ADMIN_3", "Caminho");
define("RSS_LAN_ADMIN_4", "Nome");
define("RSS_LAN_ADMIN_5", "URL");
define("RSS_LAN_ADMIN_6", "Texto");
define("RSS_LAN_ADMIN_7", "Limite");
define("RSS_LAN_ADMIN_8", "Visibilidade");
define("RSS_LAN_ADMIN_9", "Tipo");
define("RSS_LAN_ADMIN_10", "criar entrada RSS");
define("RSS_LAN_ADMIN_11", "importar alimentadores RSS");
define("RSS_LAN_ADMIN_12", "ID do T�pico");
define("RSS_LAN_ADMIN_13", "Incluir �tens do menu Other-news no alimentador de Not�cias?");
define("RSS_LAN_ADMIN_14", "Ativar");
define("RSS_LAN_ADMIN_15", "Selecione os links para marc�-los para importa��o...");
define("RSS_LAN_ADMIN_16", "importar?");
define("RSS_LAN_ADMIN_17", "importar links marcados");
define("RSS_LAN_ADMIN_18", "alimentador(es) RSS importado(s).");
define("RSS_LAN_ADMIN_21", "ativo e vis�vel na listagem RSS");
define("RSS_LAN_ADMIN_22", "ativo mas n�o vis�vel na listagem RSS");
define("RSS_LAN_ADMIN_23", "inativo");
define("RSS_LAN_ADMIN_26", "Marcar Tudo");
define("RSS_LAN_ADMIN_27", "Desmarcar Tudo");
define("RSS_LAN_ADMIN_31", "limite de entradas RSS atualizado");
define("RSS_LAN_0", "RSS");
define("RSS_LAN_2", "@semspam.com");
define("RSS_LAN_3", "semautor@semspam.com");


?>