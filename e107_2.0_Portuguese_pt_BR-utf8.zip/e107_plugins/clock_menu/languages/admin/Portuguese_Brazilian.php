<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/clock_menu/languages/admin/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("CLOCK_AD_L1", "Configura��o do clock menu salva");
define("CLOCK_AD_L2", "Subt�tulo");
define("CLOCK_AD_L3", "Atualizar Prefer�ncias");
define("CLOCK_AD_L4", "Configura��o do Clock Menu");
define("CLOCK_AD_L5", "AM/PM");
define("CLOCK_AD_L6", "Se selecionado, voc� indicar� o tempo como (0h -12h AM/PM). N�o selecionado voc� indicar� um formato (0h - 24h)");
define("CLOCK_AD_L7", "Prefixo da Data");
define("CLOCK_AD_L8", "Se desejar acrescente uma palavra antes da data (ex: dia) que seria visto na p�gina desta maneira (Segunda feira, <b>dia</b> 6 de Fevereiro 20...) caso n�o deseje, deixe vazio.");
define("CLOCK_AD_L9", "Sufixo 1");
define("CLOCK_AD_L10", "Sufixo 2");
define("CLOCK_AD_L11", "Sufixo 3");
define("CLOCK_AD_L12", "Sufixo 4 e mais");
define("CLOCK_AD_L13", "Se sua l�ngua requerer um sufixo imediatamente depois dos n�meros para a data, preencha estes campos com o sufixo somente (Exemplo: 'st' para 1, 'nd' para 2, 'rd' para 3 e 'th' para 4 � mais para indicado para usu�rios de l�ngua inglesa). recomendado: <b>(deixe em branco)</b>.");
define("CLOCK_AD_L14", "");
define("CLOCK_AD_L15", "");
define("CLOCK_AD_L16", "");
define("CLOCK_AD_L17", "");
define("CLOCK_AD_L18", "");
define("CLOCK_AD_L19", "");
define("CLOCK_AD_L20", "");
define("CLOCK_AD_L21", "");
define("CLOCK_AD_L22", "");
define("CLOCK_AD_L23", "");
define("CLOCK_AD_L24", "");

?>
