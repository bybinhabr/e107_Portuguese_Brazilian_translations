<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/integrity_check/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("Integ_01", "Grava��o com sucesso");
define("Integ_02", "Falha na grava��o");
define("Integ_03", "Arquivos Faltantes:");
define("Integ_04", "Erros CRC:");
define("Integ_05", "Incapaz de abrir arquivo...");
define("Integ_06", "Verificar integridade dos arquivos");
define("Integ_07", "Nenhum arquivo dispon�vel");
define("Integ_08", "Verificar integridade");
define("Integ_09", "Criar arquivo sfv");
define("Integ_10", "A pasta selecionada <u>n�o</u> ser� gravada no arquivo crc.");
define("Integ_11", "Nome do arquivo:");
define("Integ_12", "Criar arquivo sfv");
define("Integ_13", "Verificando a integridade");
define("Integ_14", "Cria��o do arquivo SFV imposs�vel, porque a pasta ".e_PLUGIN."integrity_check/<b>{output}</b> n�o permite escrita. Por favor altere o CHMOD desta pasta para 777!");
define("Integ_15", "Todos os arquivos foram verificados e est�o o.k.!");
define("Integ_16", "Nenhum arquivo crc do n�cleo do sistema dispon�vel");
define("Integ_17", "Nenhum arquivo crc dos plugins dispon�vel");
define("Integ_18", "Criar arquivo CRC dos plugins");
define("Integ_19", "Arquivo Checksum do N�cleo do Sistema");
define("Integ_20", "Arquivo Checksum dos Plugins");
define("Integ_21", "Selecione o plugin para o qual quer criar um arquivo crc.");
define("Integ_22", "Usar gzip");
define("Integ_23", "Verificar somente themes instalados");
define("Integ_24", "P�gina Inicial do Admin");
define("Integ_25", "Sair da �rea do Admin");
define("Integ_26", "Carregar site com o cabe�alho normal");
define("Integ_27", "USE O ARQUIVO FILEINSPECTOR PARA CHECAR OS ARQUIVOS DO N�CLEO DO SISTEMA");
define("Integ_30", "Para for�ar menos a CPU, pode fazer a verifica��o em 1 - 10 passos.");
define("Integ_31", "Passos:");
define("Integ_32", "Existe um arquivo chamado <b>log_crc.txt</b> na pasta crc. Por favor apague-o! (Ou tente atualizar a p�gina)");
define("Integ_33", "Existe um arquivo chamado <b>log_miss.txt</b> na pasta crc. Por favor apague-o! (Ou tente atualizar a p�gina)");
define("Integ_34", "A sua pasta CRC n�o permite escrita!");
define("Integ_35", "Devido aos seguintes motivos, s� � permitido escolher <b>um</b> passo:");
define("Integ_36", "Clique aqui, se n�o quer esperar 5 segundos at� o pr�ximo passo:");
define("Integ_37", "Clique aqui");
define("Integ_38", "Ainda faltam <u><i>{counts}</i></u> linhas...");
define("Integ_39", "Por favor apague o arquivo:<br />".e_PLUGIN."integrity_check/<u><i>do_core_file.php</i></u>!<br />Esta desatualizado e nunca foi destinado ao p�blico...");

?>
