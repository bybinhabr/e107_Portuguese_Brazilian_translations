<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/newsfeed/languages/Portuguese_admin.php $
|        $Revision: 1.0 $
|        $Id: 2015/03/08 12:20:03 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("NFLAN_03", "Configurar Alimentadores de Notícias (newsfeeds)");
define("NFLAN_04", "O plugin Newsfeeds foi instalado com sucesso. Para adicionar alimentadores de notícias e configurar, retorne para a página principal de administração e clique no ícone, na seção de plugins.");
define("NFLAN_07", "Alimentadores de Notícias existentes");
define("NFLAN_08", "Primeira página dos Alimentadores de Notícias");
define("NFLAN_09", "Criar newsfeed");
define("NFLAN_10", "URL para o alimentador RSS");
define("NFLAN_11", "Caminho para a imagem");
define("NFLAN_12", "Ativação");
define("NFLAN_13", "Nenhum (inativo)");
define("NFLAN_14", "No menu apenas");
define("NFLAN_17", "Digite 'default' (padrão) para usar a imagem definida no alimentador. Para usar sua própria imagem, digite o caminho completo. Deixe em branco para não suar imagem.");
define("NFLAN_18", "Intervalo de atualização em segundos");
define("NFLAN_19", "ex.: 3600 - os alimentadores irão atualizar a cada hora");
define("NFLAN_20", "Na página principal de alimentadores de notícias apenas");
define("NFLAN_21", "Em ambos, no menu e na página de alimentadores");
define("NFLAN_22", "Escolher onde você quer que os alimentadores sejam mostrados.");
define("NFLAN_26", "Intervalo de atualização");
define("NFLAN_37", "Descrição curta para o alimentador. Digite 'default' (padrão) para usar a descrição definida no alimentador.");
define("NFLAN_41", "Sem alimentadores definidos ainda");
define("NFLAN_42", "<b>&raquo;</b> <u>Nome do Alimentador:</u> O nome que identifica o alimentador pode ser qualquer coisa que você quiser. <br /><br /> <b>&raquo;</b> <u>URL para o alimentador rss:</u> O endereço do alimentador rss<br /><br /> <b>&raquo;</b> <u>Caminho para imagem:</u>Se o alimentador tem uma imagem definida nele, digite 'default' (padrão) para usá-la. Para usar sua própria imagem, digite o caminho completo do endereço url dela. Deixe em branco para não usar imagem alguma. <br /><br /> <b>&raquo;</b> <u>Descrição:</u> Digite uma descrição curta para o alimentador, ou 'default' (padrão) para usar a descrição definida no alimentador (se tiver uma). <br /><br /> <b>&raquo;</b> <u>Intervalo de atualização em segundos:</u> A quantidade em segundos do tempo a atualizar o alimentador de notícias, por exemplo, 1800: 30 minutos, 3600: uma hora. <br /><br /> <b>&raquo;</b> <u>Ativação:</u> Onde você quer que o alimentador mostre os resultados, para ver no menu de alimentadores rss, você precisa ativar o menu na <a href='".e_ADMIN."menus.php'>página de menus</a>. <br /><br />Para uma boa lista de alimentadores rss disponíveis, veja <a href='http://www.syndic8.com/' rel='external'>syndic8.com</a> ou <a href='http://feedfinder.feedster.com/index.php' rel='external'>feedster.com</a>");
define("NFLAN_43", "Alimentadores de Notícias - Ajuda");
define("NFLAN_44", "clique para ver");
define("NFLAN_45", "Número de itens a mostrar no menu");
define("NFLAN_46", "Número de itens a mostrar na página principal");
define("NFLAN_47", "0 ou em branco para mostrar tudo");
define("NFLAN_49", "Não foi possível processar os dados rss - usa uma sintaxe fora do padrão");
define("LAN_AL_NEWSFD_01", "Alimentador de Notícia criado");
define("LAN_AL_NEWSFD_02", "Alimentador de Notícia atualizado");
define("LAN_AL_NEWSFD_03", "Alimentador de Notícia deletado");
define("LAN_AL_NEWSFD_04", "");
define("LAN_AL_NEWSFD_05", "");


?>