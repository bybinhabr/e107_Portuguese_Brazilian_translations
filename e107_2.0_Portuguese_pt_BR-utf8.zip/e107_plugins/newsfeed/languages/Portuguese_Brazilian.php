<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/newsfeed/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("NFLAN_01", "Not�cias Externas");
define("NFLAN_02", "Este plugin ir� trazer not�cias de outros sites atrav�s de rss feeds e mostrar� de acordo com suas prefer�ncias");
define("NFLAN_03", "Configurar Not�cias Externas");
define("NFLAN_04", "O plugin Newsfeeds foi instalado com sucesso. Para adicionar not�cias externas e configurar, retorne � p�gina principal de admin e clique no �cone de Not�cias Externas na se��o de plugins.");
define("NFLAN_05", "Editar");
define("NFLAN_06", "Apagar");
define("NFLAN_07", "Not�cias Externas Existentes");
define("NFLAN_08", "P�gina Inicial de Not�cias Externas");
define("NFLAN_09", "Criar not�cia externa");
define("NFLAN_10", "URL para o rss feed");
define("NFLAN_11", "Caminho para a imagem");
define("NFLAN_12", "Ativa��o");
define("NFLAN_13", "Em nenhum lugar (inativo)");
define("NFLAN_14", "Apenas em um menu");
define("NFLAN_15", "Criar Not�cia Externa");
define("NFLAN_16", "Atualizar Not�cia Externa");
define("NFLAN_17", "digite 'default' na caixa para usar a imagem definida pelo plugin, para usar sua pr�pria imagem digite o caminho completo, deixe em branco para n�o usar imagem.");
define("NFLAN_18", "Intervalo de atualiza��o em segundos");
define("NFLAN_19", "ex.: 3600: o newsfeed ir� atualizar a cada hora");
define("NFLAN_20", "Ativar o newsfeed na p�gina principal/home apenas");
define("NFLAN_21", "Em ambos: no menu e na p�gina de not�cias externas");
define("NFLAN_22", "escolha onde voc� quer que as not�cias externas/newsfeed sejam mostradas");
define("NFLAN_23", "Not�cia externa adicionada � base de dados.");
define("NFLAN_24", "Campo(s) requerido(s) deixados em branco.");
define("NFLAN_25", "Not�cias externas atualizadas na base de dados");
define("NFLAN_26", "Intervalo de Atualiza��o");
define("NFLAN_27", "Op��es");
define("NFLAN_28", "URL");
define("NFLAN_29", "Not�cias externas dispon�veis");
define("NFLAN_30", "Nome da fonte da not�cia externa");
define("NFLAN_31", "Voltar para a lista das fontes de  not�cias externas");
define("NFLAN_32", "Nenhuma fonte de not�cia externa foi identificada com esta numera��o");
define("NFLAN_33", "Data de publica��o");
define("NFLAN_34", "n�o se sabe");
define("NFLAN_35", "portado por");
define("NFLAN_36", "Descri��o");
define("NFLAN_37", "pequena descri��o da fonte de not�cia externa, digite 'default' para usar a descri��o definida pela fonte");
define("NFLAN_38", "Chamadas");
define("NFLAN_39", "Detalhes");
define("NFLAN_40", "Not�cia externa apagada");
define("NFLAN_41", "N�o h� not�cias externas definidas ainda");
define("NFLAN_42", "<b>�</b> <u>Nome da fonte de not�cia externa:</u>	Um nome para identificar a fonte de not�cias, pode ser qualquer coisa que voc� quiser.	<br /><br />	<b>�</b> <u>URL para o rss:</u>	O endere�o da fonte rss	<br /><br />	<b>�</b> <u>Caminho para a imagem:</u>	Se a fonte j� foi definida para ter uma imagem, digite 'default' para us�-la. Para usar sua pr�pria imagem, digite o caminho completo para ela. Deixe em branco para n�o usar imagem nenhuma.	<br /><br />	<b>�</b> <u>Descri��o:</u>	Digite uma descri��o curta para a fonte, ou 'default' para usar a descri��o definida pela fonte (se tiver alguma).	<br /><br />	<b>�</b> <u>Intervelo de atualiza��o em segundos:</u>	A quantidade de segundos que demora para atualizar as not�cias, por exemplo: 1800 = 30 minutos e 3600 = 1 hora.	<br /><br />	<b>�</b> <u>Ativa��o:</u>	Onde voc� quer que apare�a as not�cias da fonte, para ver em menus, voc� precisa ativar o menu newsfeeds na <a href='".e_ADMIN."menus.php'>p�gina de menus</a>.	<br /><br />Para uma lista de not�cias externas dispon�veis (em ingl�s), veja <a href='http://www.syndic8.com/' rel='external'>syndic8.com</a> ou <a href='http://feedfinder.feedster.com/index.php' rel='external'>feedster.com</a>. Tamb�m existem muitos sites brasileiros de not�cias que oferecem o link (URL) para o arquivo rss!");
define("NFLAN_43", "Ajuda do plugin Not�cias Externas");
define("NFLAN_44", "clique para visualizar");
define("NFLAN_45", "N�mero de �tens a serem mostrados no menu");
define("NFLAN_46", "N�mero de �tens a serem mostrados na p�gina principal");
define("NFLAN_47", "0 ou deixe em branco para mostrar tudo");
define("NFLAN_48", "Imposs�vel salvar dados raw no banco de dados.");
define("NFLAN_49", "Imposs�vel interpretar dados rss - usa sintaxes fora do padr�o");


?>
