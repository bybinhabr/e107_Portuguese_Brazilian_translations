<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/online_extended_menu/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("ONLINE_EL1", "Visitantes:");
define("ONLINE_EL2", "Membros:");
define("ONLINE_EL3", "Nesta p�gina:");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Membros");
define("ONLINE_EL6", "Membro mais novo");
define("ONLINE_EL7", "visualizando");
define("ONLINE_EL8", "mais tempo online:");
define("ONLINE_EL9", "em");
define("ONLINE_TRACKING_MESSAGE", "O rastreamento de usu�rios online est� desabilitado atualmente, por favor habilite acessando [link=".e_ADMIN."users.php?options]aqui[/link][br]");


?>