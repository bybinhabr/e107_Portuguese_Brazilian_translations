<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/tagwords/languages/Portuguese.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/15 17:36:51 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_TAG_INS_1", "Etiquetas (Tagwords)");
define("LAN_TAG_INS_2", "Sistema completo de Etiquetas");
define("LAN_TAG_INS_3", "Configurar Etiquetas");
define("LAN_TAG_INS_4", "Etiquetas está instalado<br />Para configurar, favor clicar no link da seção de plugins, na página inicial de administração do site");
define("LAN_TAG_SEARCH_1", "Procurar Por:");
define("LAN_TAG_SEARCH_2", "Procurar");
define("LAN_TAG_SEARCH_3", "Ver");
define("LAN_TAG_1", "Etiquetas");
define("LAN_TAG_2", "Etiqueta");
define("LAN_TAG_3", "Etiquetas atualizadas");
define("LAN_TAG_4", "classificar");
define("LAN_TAG_5", "mostrar");
define("LAN_TAG_6", " ");
define("LAN_TAG_7", "< Voltar à página principal das Etiquetas");
define("LAN_TAG_8", "resultado encontrado para");
define("LAN_TAG_9", "resultados encontrados para");
define("LAN_TAG_10", "ordem alfabética");
define("LAN_TAG_11", "por tamanho");
define("LAN_TAG_12", "lista de etiquetas");
define("LAN_TAG_13", "etiqueta tagcloud");
define("LAN_TAG_14", "seleção:");
define("LAN_TAG_15", "todas as áreas");
define("LAN_TAG_16", "Etiqueta TagCloud");
define("LAN_TAG_17", "Lista de Etiquetas");
define("LAN_TAG_18", "não foram encontradas etiquetas para esta seleção");
define("LAN_TAG_19", "classificar escolha");
define("LAN_TAG_20", "estilo de classificação");
define("LAN_TAG_21", "cada etiqueta em uma linha separada");
define("LAN_TAG_OPT_1", "preferências das etiquetas");
define("LAN_TAG_OPT_2", "tamanho de palavra mínima necessária para a lista de etiquetas");
define("LAN_TAG_OPT_3", "lista de etiquetas visível somente para");
define("LAN_TAG_OPT_4", "ordem padrão das etiquetas");
define("LAN_TAG_OPT_5", "alfabética");
define("LAN_TAG_OPT_6", "por tamanho");
define("LAN_TAG_OPT_7", "estilo de etiqueta padrão");
define("LAN_TAG_OPT_8", "tagcloud");
define("LAN_TAG_OPT_9", "lista de etiquetas");
define("LAN_TAG_OPT_10", "sim");
define("LAN_TAG_OPT_11", "não");
define("LAN_TAG_OPT_12", "opções de ordem de etiquetas");
define("LAN_TAG_OPT_13", "opções de tipos de etiquetas");
define("LAN_TAG_OPT_14", "opções da área de etiquetas");
define("LAN_TAG_OPT_15", "número máximo de palavras no menu");
define("LAN_TAG_OPT_16", "página de etiquetas");
define("LAN_TAG_OPT_17", "menu de etiquetas");
define("LAN_TAG_OPT_18", "título do menu");
define("LAN_TAG_OPT_19", "opções de busca de etiquetas");
define("LAN_TAG_OPT_20", "frequência depois das etiquetas");
define("LAN_TAG_OPT_21", "código/shortcode");
define("LAN_TAG_OPT_22", "separador de palavras");
define("LAN_TAG_OPT_23", "áreas");
define("LAN_TAG_OPT_24", "marque áreas ativas");
define("LAN_TAG_OPT_25", "genérico");
define("LAN_TAG_OPT_26", "mostrar");
define("LAN_TAG_MENU_1", "ver etiquetas completas");
define("LAN_TAG_MENU_2", "Etiquetas");
define("LAN_TAG_CORE_NEWS_1", "Notícias");
define("LAN_TAG_CORE_CPAGES_1", "Páginas");
define("LAN_TAG_URL_NAME", "Etiquetas");
define("LAN_TAG_URL_DEFAULT_LABEL", "Padrão");
define("LAN_TAG_URL_DEFAULT_DESCR", "Exemplo: http://seusite.com.br/etiquetas/alguma-tag");


?>