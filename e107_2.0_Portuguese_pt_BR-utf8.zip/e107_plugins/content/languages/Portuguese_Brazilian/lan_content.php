<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/content/languages/Portuguese_Brazilian/lan_content.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("CONTENT_EMAILPRINT_LAN_1", "este conte�do � de");
define("POPUP_LAN_1", "clique para ver imagem ampliada");
define("CONTENT_NOTIFY_LAN_1", "Eventos de Conte�do");
define("CONTENT_NOTIFY_LAN_2", "Item de conte�do submetido pelo usu�rio");
define("CONTENT_NOTIFY_LAN_3", "Conte�do Enviado");
define("CONTENT_TYPE_LAN_0", "categorias");
define("CONTENT_TYPE_LAN_1", "autores");
define("CONTENT_TYPE_LAN_2", "arquivo");
define("CONTENT_TYPE_LAN_3", "mais votado");
define("CONTENT_TYPE_LAN_4", "mais avaliado");
define("CONTENT_TYPE_LAN_5", "recente");
define("CONTENT_ICON_LAN_0", "editar");
define("CONTENT_ICON_LAN_1", "apagar");
define("CONTENT_ICON_LAN_2", "op��es");
define("CONTENT_ICON_LAN_3", "detalhes do usu�rio");
define("CONTENT_ICON_LAN_4", "arquivo anexado");
define("CONTENT_ICON_LAN_5", "novo");
define("CONTENT_ICON_LAN_6", "enviar conte�do");
define("CONTENT_ICON_LAN_7", "lista de autores");
define("CONTENT_ICON_LAN_8", "perigo");
define("CONTENT_ICON_LAN_9", "ok");
define("CONTENT_ICON_LAN_10", "erro");
define("CONTENT_ICON_LAN_11", "ordenar os itens na categoria");
define("CONTENT_ICON_LAN_12", "ordenar os itens na p�gina principal/pai");
define("CONTENT_ICON_LAN_13", "administra��o personalizada");
define("CONTENT_ICON_LAN_14", "gerenciador de conte�do personalizado");
define("CONTENT_ICON_LAN_15", "visualizar");
define("CONTENT_ADMIN_DATE_LAN_0", "Janeiro");
define("CONTENT_ADMIN_DATE_LAN_1", "Fevereiro");
define("CONTENT_ADMIN_DATE_LAN_2", "Mar�o");
define("CONTENT_ADMIN_DATE_LAN_3", "Abril");
define("CONTENT_ADMIN_DATE_LAN_4", "Maio");
define("CONTENT_ADMIN_DATE_LAN_5", "Junho");
define("CONTENT_ADMIN_DATE_LAN_6", "Julho");
define("CONTENT_ADMIN_DATE_LAN_7", "Agosto");
define("CONTENT_ADMIN_DATE_LAN_8", "Setembro");
define("CONTENT_ADMIN_DATE_LAN_9", "Outubro");
define("CONTENT_ADMIN_DATE_LAN_10", "Novembro");
define("CONTENT_ADMIN_DATE_LAN_11", "Dezembro");
define("CONTENT_ADMIN_DATE_LAN_12", "dia");
define("CONTENT_ADMIN_DATE_LAN_13", "m�s");
define("CONTENT_ADMIN_DATE_LAN_14", "ano");
define("CONTENT_ADMIN_DATE_LAN_15", "data inicial");
define("CONTENT_ADMIN_DATE_LAN_16", "data final");
define("CONTENT_ADMIN_DATE_LAN_17", "Voc� pode especificar uma data inicial para este conte�do. Se voc� usar uma data no futuro, o conte�do ser� vis�vel desta data em diante. Se voc� n�o precisa especificar uma data de in�cio, pode deixar estes campos como est�o.");
define("CONTENT_ADMIN_DATE_LAN_18", "Voc� pode especificar uma data final para este conte�do. Com uma data final, voc� pode especificar at� quando o item ser� vis�vel. Se voc� n�o precisa de uma data final, deixe esses campos como est�o.");
define("CONTENT_PAGETITLE_LAN_0", "Conte�do");
define("CONTENT_PAGETITLE_LAN_1", "Principal");
define("CONTENT_PAGETITLE_LAN_2", "Recentes");
define("CONTENT_PAGETITLE_LAN_3", "Categoria");
define("CONTENT_PAGETITLE_LAN_4", "Mais Votados");
define("CONTENT_PAGETITLE_LAN_5", "Autor");
define("CONTENT_PAGETITLE_LAN_6", "Arquivo");
define("CONTENT_PAGETITLE_LAN_7", "Enviar");
define("CONTENT_PAGETITLE_LAN_8", "Enviar Item de Conte�do");
define("CONTENT_PAGETITLE_LAN_9", "Gerenciador de Conte�do Personalizado");
define("CONTENT_PAGETITLE_LAN_10", "Visualizar Itens");
define("CONTENT_PAGETITLE_LAN_11", "Editar Item");
define("CONTENT_PAGETITLE_LAN_12", "Criar Item");
define("CONTENT_PAGETITLE_LAN_13", "Categorias");
define("CONTENT_PAGETITLE_LAN_14", "Lista de Autores");
define("CONTENT_PAGETITLE_LAN_15", "Mais Pontuados");
define("CONTENT_SEARCH_LAN_0", "nenhum conte�do encontrado com essa palavra-chave.");
define("CONTENT_ORDER_LAN_0", "organizar por...");
define("CONTENT_ORDER_LAN_1", "t�tulo (ASC)");
define("CONTENT_ORDER_LAN_2", "t�tulo (DESC)");
define("CONTENT_ORDER_LAN_3", "data (ASC)");
define("CONTENT_ORDER_LAN_4", "data (DESC)");
define("CONTENT_ORDER_LAN_5", "refer�ncia (ASC)");
define("CONTENT_ORDER_LAN_6", "refer�ncia (DESC)");
define("CONTENT_ORDER_LAN_7", "categoria pai/principal (ASC)");
define("CONTENT_ORDER_LAN_8", "categoria pai/principal (DESC)");
define("CONTENT_ORDER_LAN_9", "ordenar (ASC)");
define("CONTENT_ORDER_LAN_10", "ordenar (DESC)");
define("CONTENT_ORDER_LAN_11", "autor (ASC)");
define("CONTENT_ORDER_LAN_12", "autor (DESC)");
define("CONTENT_LAN_0", "Conte�do");
define("CONTENT_LAN_1", "Lista dos mais Recentes");
define("CONTENT_LAN_2", "Lista de Categorias");
define("CONTENT_LAN_3", "Categoria");
define("CONTENT_LAN_4", "Lista de Autores");
define("CONTENT_LAN_5", "Autor");
define("CONTENT_LAN_6", "todas as categorias");
define("CONTENT_LAN_7", "todos os autores");
define("CONTENT_LAN_8", "itens mais votados");
define("CONTENT_LAN_9", "em");
define("CONTENT_LAN_10", "em");
define("CONTENT_LAN_11", "por");
define("CONTENT_LAN_12", "itens mais pontuados");
define("CONTENT_LAN_13", "lista");
define("CONTENT_LAN_14", "-- categorias --");
define("CONTENT_LAN_15", "n�o h� autores ainda");
define("CONTENT_LAN_16", "[leia mais]");
define("CONTENT_LAN_17", " ");
define("CONTENT_LAN_18", "buscar por palavra-chave");
define("CONTENT_LAN_19", "buscar");
define("CONTENT_LAN_20", "resultados da busca de conte�dos");
define("CONTENT_LAN_21", "nenhum tipo de conte�do ainda.");
define("CONTENT_LAN_22", "tipos de conte�do");
define("CONTENT_LAN_23", "Lista de Conte�dos Recentes");
define("CONTENT_LAN_24", "trecho");
define("CONTENT_LAN_25", "Categorias de Conte�do");
define("CONTENT_LAN_26", "Categoria de Conte�do");
define("CONTENT_LAN_27", "subcategorias");
define("CONTENT_LAN_28", "subcategorias principais/pai");
define("CONTENT_LAN_29", "desconhecido");
define("CONTENT_LAN_30", "item de conte�do");
define("CONTENT_LAN_31", "itens de conte�do");
define("CONTENT_LAN_32", "Lista de Autores de Conte�do");
define("CONTENT_LAN_33", "Ir para a P�gina");
define("CONTENT_LAN_34", "conte�do");
define("CONTENT_LAN_35", "coment�rios");
define("CONTENT_LAN_36", "moderar coment�rios");
define("CONTENT_LAN_37", "n�o h� itens de conte�do votados ainda");
define("CONTENT_LAN_38", "Conte�dos mais votados");
define("CONTENT_LAN_39", "lista de autores");
define("CONTENT_LAN_40", "detalhes do autor");
define("CONTENT_LAN_41", "anexado");
define("CONTENT_LAN_42", "arquivo");
define("CONTENT_LAN_43", "arquivos");
define("CONTENT_LAN_44", "cliques:");
define("CONTENT_LAN_45", "pontua��o dada ao autor:");
define("CONTENT_LAN_46", "�ndice de artigos");
define("CONTENT_LAN_47", "autor");
define("CONTENT_LAN_48", "itens de conte�do");
define("CONTENT_LAN_49", "�ltimo item de conte�do");
define("CONTENT_LAN_50", "data");
define("CONTENT_LAN_51", "Lista de Tipos");
define("CONTENT_LAN_52", "nenhum autor v�lido encontrado");
define("CONTENT_LAN_53", "item");
define("CONTENT_LAN_54", "itens");
define("CONTENT_LAN_55", "�ltimo item em");
define("CONTENT_LAN_56", "mostrar resumo de");
define("CONTENT_LAN_57", "coment�rios:");
define("CONTENT_LAN_58", "principal");
define("CONTENT_LAN_59", "conte�do");
define("CONTENT_LAN_60", "recentes");
define("CONTENT_LAN_61", "visualizar itens recentes");
define("CONTENT_LAN_62", "visualizar todas as categorias");
define("CONTENT_LAN_63", "visualizar todos os autores");
define("CONTENT_LAN_64", "visualizar os itens mais votados");
define("CONTENT_LAN_65", "enviar conte�do");
define("CONTENT_LAN_66", "clique aqui para enviar o conte�do, voc� pode escolher a categoria na p�gina de envio.");
define("CONTENT_LAN_67", "gerenciador de conte�do personalizado");
define("CONTENT_LAN_68", "clique aqui para gerenciar seu conte�do pessoal.");
define("CONTENT_LAN_69", "enviar email");
define("CONTENT_LAN_70", "imprimir o");
define("CONTENT_LAN_71", "item de conte�do");
define("CONTENT_LAN_72", "item de categoria");
define("CONTENT_LAN_73", "n�o h� itens de conte�do ainda");
define("CONTENT_LAN_74", " ");
define("CONTENT_LAN_75", "enviar item de conte�do");
define("CONTENT_LAN_76", "criar um arquivo pdf de");
define("CONTENT_LAN_77", "buscar conte�do");
define("CONTENT_LAN_78", "p�gina sem t�tulo");
define("CONTENT_LAN_79", "p�gina");
define("CONTENT_LAN_80", "itens recentes:");
define("CONTENT_LAN_81", "categorias");
define("CONTENT_LAN_82", "n�o h� itens ainda em");
define("CONTENT_LAN_83", "arquivo de item");
define("CONTENT_LAN_84", "Arquivo de Conte�do");
define("CONTENT_LAN_85", "lista de autores");
define("CONTENT_LAN_86", "ver itens mais votados");
define("CONTENT_LAN_87", "Conte�dos Mais Votados");
define("CONTENT_LAN_88", "n�o h� itens de conte�do votados ainda");
define("CONTENT_LAN_89", "selecionar p�gina");
define("CONTENT_LAN_90", "p�gina anterior");
define("CONTENT_LAN_91", "pr�xima p�gina");
define("CONTENT_LAN_92", "- atual -");
define("CONTENT_LAN_ALL", "tudo");
define("CONTENT_MENU_LAN_0", "Menu de conte�do:");
define("CONTENT_MENU_LAN_1", "n�o h� itens de conte�do ainda");
define("CONTENT_MENU_LAN_2", "itens recentes");
define("CONTENT_MENU_LAN_3", "categorias");
define("CONTENT_MENU_LAN_4", "links de conte�do");
define("CONTENT_MENU_LAN_5", "");
define("CONTENT_MENU_LAN_6", "");
define("CONTENT_MENU_LAN_7", "");
define("CONTENT_MENU_LAN_8", "");
define("CONTENT_MENU_LAN_9", "");
define("CONTENT_MENU_LAN_10", "");
define("CONTENT_MENU_LAN_11", "");
define("CONTENT_MENU_LAN_12", "");
define("CONTENT_MENU_LAN_13", "");
define("CONTENT_MENU_LAN_14", "");
define("CONTENT_MENU_LAN_15", "");
define("CONTENT_MENU_LAN_16", "");
define("CONTENT_MENU_LAN_17", "");
define("CONTENT_MENU_LAN_18", "");
define("CONTENT_MENU_LAN_19", "");
define("CONTENT_MENU_LAN_20", "");


?>