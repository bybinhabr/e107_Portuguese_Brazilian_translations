<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/content/languages/Portuguese_Brazilian/lan_content_help.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("CONTENT_ADMIN_HELP_1", "�rea de Ajuda do Gerenciador de Conte�do");
define("CONTENT_ADMIN_HELP_ITEM_1", "<i>se voc� ainda n�o adicionou categorias principais/pai, favor fazer isso clicando no link<a href='".e_SELF."?cat.create'>Criar Nova Categoria</a>.</i><br /><br /><b>categoria</b><br />selecione uma categoria do menu pulldown para gerenciar o conte�do daquela categoria.<br /><br />Selecionando uma categoria principal no menu pulldown ir� aparecer todos os �tens de conte�do daquela categoria.<br />Selecionando uma subcategoria ir� mostrar apenas os �tens daquela subcategoria espec�fica.<br /><br />Voc� poder� tamb�m usar o menu na direita para ver todos os �tens de conte�do de uma categoria espec�fica.");
define("CONTENT_ADMIN_HELP_ITEM_2", "<b>primeiras letras</b><br />se existirem m�ltiplos conte�dos iniciando com as mesmas letras no t�tulo, voc� ver� bot�es para selecionar apenas aqueles conte�dos que come�am com aquela letra. Selecionando o bot�o 'tudo' vai mostrar uma lista de todos os conte�dos que existem nesta categoria.<br /><br /><b>lista detalhada</b><br />Voc� v� uma lista de �tens de conte�dos com seu id, �cone, autor, cabe�alho/t�tulo e op��es.<br /><br /><b>explica��o dos �cones</b><br />".CONTENT_ICON_USER." : link para o perfil do autor<br />".CONTENT_ICON_LINK." : link para o conte�do<br />".CONTENT_ICON_EDIT." : editar o item de conte�do<br />".CONTENT_ICON_DELETE." : deletar o item de conte�do<br />");
define("CONTENT_ADMIN_HELP_ITEMEDIT_1", "<b>formul�rio de edi��o</b><br />voc� pode agora editar todas as informa��es do �tem de conte�do e submeter suas mudan�as.<br /><br />Se voc� precisar mudar a categoria para este �tem de conte�do, favor fazer isso primeiro. Depois que voc� selecionou a categoria correta, mude ou adicione qualquer campo presente, antes de enviar suas mudan�as.");
define("CONTENT_ADMIN_HELP_ITEMCREATE_1", "<b>categoria</b><br />favor selecionar a categoria no box de sele��o criado para seu �tem de conte�do.<br />");
define("CONTENT_ADMIN_HELP_ITEMCREATE_2", "<b>formul�rio de cria��o</b><br />voc� pode agora disponibilizar informa��es para seu �tem de conte�do e envi�-lo.<br /><br />Esteja atento do fato que diferentes categorias principais/pai podem ter configura��es de prefer�ncias diferentes; diferentes campos podem ser disponibilizados para voc� preencher. Mas mesmo assim, voc� sempre precisar� selecionar uma categoria primeiro, antes de voc� preencher os outros campos!");
define("CONTENT_ADMIN_HELP_CAT_1", "<i>esta p�gina mostra todas as categorias e subcategorias presentes.</i><br 
/><br /><b>lista detalhada</b><br />Voc� v� aqui uma lista de todas as 
subcategorias com sua id/identifica��o, �cone, autor, categoria e op��es.<br 
/><br /><b>explica��o dos �cones</b><br />".CONTENT_ICON_USER." : link para 
o perfil do autor<br />".CONTENT_ICON_LINK." : link para a categoria<br 
/>".CONTENT_ICON_EDIT." : editar a categoria<br />".CONTENT_ICON_DELETE." : 
deletar a categoria<br />");
define("CONTENT_ADMIN_HELP_CAT_2", "<i>esta p�gina permite criar uma nova categoria</i><br /><br />Sempre 
escolha uma categoria principal/pai antes de preencher os outros campos!<br 
/><br />Isto precisa ser feito, porque algumas prefer�ncias �nicas de uma 
categoria precisam ser lidas no sistema.<br /><br />Por padr�o, a p�gina de 
categoria � mostrada para criar uma nova categoria principal.");
define("CONTENT_ADMIN_HELP_CAT_3", "<i>esta p�gina mostra o formul�rio de edi��o de categoria.</i><br /><br 
/><b>formul�rio de edi��o de categoria</b><br />voc� pode editar agora toda 
a informa��o para esta (sub)categoria e submeter as mudan�as.<br /><br />Se 
voc� quiser mudar a localiza��o da categoria principal, favor fazer isto 
primeiro. Depois que voc� configurar a categoria correta, edite todos os 
outros campos.");
define("CONTENT_ADMIN_HELP_ORDER_1", "<i>esta p�gina mostra todas as categorias e subcategorias presentes.</i><br 
/><br /><b>lista detalhada</b><br />voc� v� o id da categoria e o nome dela. 
Tamb�m v� muitas op��es para gerenciar a ordem das categorias.<br /><br 
/><b>explica��o dos �cones</b><br />".CONTENT_ICON_USER." : link para o 
perfil do autor<br />".CONTENT_ICON_LINK." : link para a categoria<br 
/>".CONTENT_ICON_ORDERALL." : gerenciar a ordem geral de um �tem de conte�do 
na categoria.<br />".CONTENT_ICON_ORDERCAT." : gerenciar a ordem de �tens de 
conte�do em uma categoria espec�fica.<br />".CONTENT_ICON_ORDER_UP." : o 
bot�o para cima permite mover o �tem de conte�do uma vez para cima na 
ordem.<br />".CONTENT_ICON_ORDER_DOWN." : o bot�o para baixo permite mover o 
�tem de conte�do uma vez para baixo na ordem.<br /><br /><b>ordem</b><br 
/>aqui voc� pode configurar manualmente a ordem de todas as categorias em 
cada categoria principal. Voc� precisa mudar os valores nas caixas de 
sele��o para ordenar e ent�o pressionar o bot�o de atualizar abaixo para 
salvar a nova ordem.<br />");
define("CONTENT_ADMIN_HELP_ORDER_2", "<i>esta p�gina mostra todos os �tens de conte�do da categoria que voc� 
selecionou.</i><br /><br /><b>lista detalhada</b><br />voc� v� o id do 
conte�do, o autor e o t�tulo do conte�do. Tamb�m v� diversas op��es para 
gerenciar a ordem dos �tens de conte�do.<br /><br /><b>explica��o dos 
�cones</b><br />".CONTENT_ICON_USER." : link para o perfil do autor<br 
/>".CONTENT_ICON_LINK." : link para o �tem de conte�do<br 
/>".CONTENT_ICON_ORDER_UP." : o bot�o para cima permite mover o �tem de 
conte�do uma vez para cima na ordem.<br />".CONTENT_ICON_ORDER_DOWN." : o 
bot�o para baixo permite mover o �tem de conte�do uma vez para baixo na 
ordem.<br /><br /><b>ordem</b><br />aqui voc� pode configurar manualmente a 
ordem de todas as categorias dentro desta categoria principal. Voc� precisa 
mudar os valores na caixa de sele��o para organizar da maneira que quiser e 
depois pressionar no bot�o abaixo para atualizar e ent�o salvar a nova 
ordem.<br />");
define("CONTENT_ADMIN_HELP_ORDER_3", "<i>esta p�gina mostra todos os �tens de conte�do de uma categoria principal 
que voc� selecionou.</i><br /><br /><b>lista detalhada</b><br />voc� v� o id 
do conte�do, o autor e t�tulo. Tamb�m v� diversas op��es para gerenciar a 
ordem dos �tens de conte�do.<br /><br /><b>explica��o dos �cones</b><br 
/>".CONTENT_ICON_USER." : link para o perfil do autor<br 
/>".CONTENT_ICON_LINK." : link para o �tem de conte�do<br 
/>".CONTENT_ICON_ORDER_UP." : o bot�o para cima permite mover um �tem de 
conte�do uma vez para cima na ordem.<br />".CONTENT_ICON_ORDER_DOWN." : o 
bot�o para baixo permite mover o �tem de conte�do uma vez para baixo na 
ordem.<br /><br /><b>ordem</b><br />aqui voc� pode configurar manualmente a 
ordem de todas as categorias nesta categoria principal. Voc� precisa mudar 
os valores nas caixas de sele��o para ordenar e depois pressionar o bot�o 
abaixo para salvar a nova ordem.<br />");
define("CONTENT_ADMIN_HELP_OPTION_1", "Nesta p�gina voc� pode selecionar uma categoria principal para configurar suas op��es, ou pode editar as prefer�ncias padr�o.<br /><br /><b>explica��o dos �cones</b><br />".CONTENT_ICON_USER." : link para o perfil do autor<br />".CONTENT_ICON_LINK." : link para a categoria<br />".CONTENT_ICON_OPTIONS." : editar as op��es<br /><br /><br />
As prefer�ncias padr�o s�o usadas apenas quando voc� cria uma nova categoria principal. Ent�o, quando voc� cria uma nova categoria principal, as prefer�ncias padr�o ser�o gravadas. Voc� pode mudar isso e ter certeza que suas categorias rec�m-criadas j� ter�o algumas fun��es j� configuradas.
<br /><br />
Cada categoria principal/pai tem sua pr�pria configura��o de op��es, que s�o �nicas para cada categoria espec�fica");
define("CONTENT_ADMIN_HELP_MANAGER_1", "Nesta p�gina voc� v� uma lista de todas as categorias. Voc� pode administrar o 'gerenciador de conte�do personalizado/pessoal' para cada categoria clicando no �cone.<br /><br /><b>explica��o dos �cones</b><br />".CONTENT_ICON_USER." : link para o perfil do autor<br />".CONTENT_ICON_LINK." : link para a categoria<br />".CONTENT_ICON_CONTENTMANAGER_SMALL." : editar o gerenciador de conte�dos pessoais<br />");
define("CONTENT_ADMIN_HELP_MANAGER_2", "<i>nesta p�gina voc� pode configurar usu�rios para uma categoria selecionada que voc� tenha clicado</i><br /><br /><b>gerenciador pessoal</b><br />Voc� pode associar usu�rios para certas categorias. Fazendo isso, os usu�rios poder�o gerenciar conte�do pessoal em alguns �tens, fora da �rea de administra��o (content_manager.php).<br /><br />Associe usu�rios na coluna da esquerda clicando nos nomes. Voc� ver� os nomes se moverem para a coluna da direita. Depois de associar, clique no bot�o para confirmar.");
define("CONTENT_ADMIN_HELP_SUBMIT_1", "<i>Nesta p�gina voc� v� uma lista de �tens de conte�do que s�o enviados pelos usu�rios.</i><br /><br /><b>lista detalhada</b><br />Voc� v� uma lista de �tens de conte�do com sua identifica��o, �cone, categoria principal, t�tulo, autor e op��es.<br /><br /><b>op��es</b><br />Voc� pode postar ou deletar um �tem de conte�do usando os bot�es mostrados.");
define("CONTENT_ADMIN_HELP_OPTION_DIV_1", "esta p�gina permite que voc� configure op��es para a p�gina de administra��o de �tens de conte�do.<br /><br />Voc� pode definir quais se��es est�o dispon�veis quando um administrador (ou dono de um conte�do pessoal) criar um novo �tem de conte�do<br /><br /><b>tags de dados customizadas</b><br />Voc� pode permitir que um usu�rio ou admin adicione campos opcionais no �tem de conte�do usando estas tags de dados customizadas. Estes campos opcionais s�o pares de valores em branco. Por exemplo: voc� pode adicionar um campo chave para 'fot�grafo' e disponibilizar um valor para o campo com 'todas as fotos tiradas por mim'. Ambas as chaves e valores s�o campos de texto vazios que ser�o mostrados no formul�rio de cria��o do conte�do.<br /><br /><b>tags de dados pr�-configuradas</b><br />diferentemente das tags de dados customizadas, voc� pode adicionar tags pr�-configuradas. A diferen�a � que nas tags de dados pr�-configuradas, os campos j� estar�o l� e o usu�rio apenas d� o valor do campo. No mesmo exemplo acima, o campo 'fot�grafo' pode ser pr�-definido, e o usu�rio precisa digitar 'todas as fotos tiradas por mim'. Voc� pode escolher o tipo de elemento selecionando uma op��o na caixa de sele��o. Na janela popup voc� pode digitar todas as informa��es para as tags pr�-definidas.<br />");
define("CONTENT_ADMIN_HELP_OPTION_DIV_2", "As op��es de envio t�m efeito no formul�rio de envio dos usu�rios - para os �tens de conte�do.<br /><br />Voc� pode definir quais se��es estar�o dispon�veis para um usu�rio quando este envia um �tem de conte�do.<br /><br />".CONTENT_ADMIN_OPT_LAN_11.":<br />".CONTENT_ADMIN_OPT_LAN_12."");
define("CONTENT_ADMIN_HELP_OPTION_DIV_3", "Nas op��es de Caminho e Tema voc� define onde est�o as imagens e os arquivos no servidor.<br /><br />voc� pode definir qual tema ser� usado para esta categoria principal/pai. Voc� pode criar temas adicionais copiando (e renomeando) o diret�rio 'padr�o' inteiro no seu diret�rio de templates.<br /><br />Voc� pode definir um esquema de layout padr�o para novos �tens de conte�do. Voc� pode criar novos esquemas de layout criando um arquivo content_content_template_XXX.php na pasta 'templates/default'. Estes layouts podem ser usados dando a cada conte�do principal um diferente layout.<br /><br />");
define("CONTENT_ADMIN_HELP_OPTION_DIV_4", "As Op��es Gerais s�o as usadas pelas p�ginas de conte�do do plugin de gerenciamento de conte�dos.");
define("CONTENT_ADMIN_HELP_OPTION_DIV_5", "Estas op��es afetam a �rea do Gerenciador de Conte�do Pessoal/Personalizado na administra��o do gerenciador de conte�dos.<br /><br />".CONTENT_ADMIN_OPT_LAN_63."");
define("CONTENT_ADMIN_HELP_OPTION_DIV_6", "Estas op��es s�o usadas no Menu para esta categoria principal se voc� ativou o menu.<br /><br />".CONTENT_ADMIN_OPT_LAN_68."<br /><br />".CONTENT_ADMIN_OPT_LAN_118.":<br />".CONTENT_ADMIN_OPT_LAN_119."<br /><br />");
define("CONTENT_ADMIN_HELP_OPTION_DIV_7", "As op��es de Visualiza��o de �tem de Conte�do afetam na pequena visualiza��o dada a um �tem de menu.<br /><br />Esta visualiza��o � dada a muitas p�ginas, como a p�gina atual, os �tens vistos na p�gina de categoria e os �tens vistos na p�gina de autor.<br /><br />".CONTENT_ADMIN_OPT_LAN_68."");
define("CONTENT_ADMIN_HELP_OPTION_DIV_8", "A P�gina de Categorias mostra informa��es das categorias de conte�do na principal.<br /><br />S�o duas �reas distintas:<br /><br />todas as categorias:<br />esta p�gina mostra todas as categorias dentro desta categoria principal<br /><br />Ver Categorias:<br />esta p�gina mostra o �tem de categoria, opcionalmente as subcategorias dentro da categoria e os �tens de conte�do na categoria ou as categorias<br />");
define("CONTENT_ADMIN_HELP_OPTION_DIV_9", "A P�gina de Conte�dos mostra o �tem de Conte�do.<br /><br />voc� pode definir quais se��es mostrar, marcando/desmarcando as caixas.<br /><br />voc� pode mostrar os endere�os de e-mail (emailaddress) de um autor que n�o � membro do site.<br /><br />voc� pode ocultar os �cones de e-mail/impress�o/pdf, o sistema de vota��o e os coment�rios.<br /><br />".CONTENT_ADMIN_OPT_LAN_74."");
define("CONTENT_ADMIN_HELP_OPTION_DIV_10", "A P�gina do Autor mostra uma lista de todos os autores �nicos dos �tens de conte�do.<br /><br />Voc� pode definir quais se��es mostrar marcando/desmarcando as caixas.<br /><br />Voc� pode limitar o n�mero de �tens mostrados por p�gina.<br />");
define("CONTENT_ADMIN_HELP_OPTION_DIV_11", "A P�gina de Arquivo mostra todos os �tens na categoria principal.<br /><br />voc� pode definir quais se��es mostrar marcando/desmarcando as caixas.<br /><br />voc� pode mostrar o endere�o de e-mail (emailaddress) de um autor que n�o � membro registrado no site.<br /><br />Voc� pode limitar o n�mero de �tens a mostrar por p�gina.<br /><br />".CONTENT_ADMIN_OPT_LAN_66."<br /><br />".CONTENT_ADMIN_OPT_LAN_68."");
define("CONTENT_ADMIN_HELP_OPTION_DIV_12", "A P�gina de Mais Votados mostra todos os �tens de conte�do que foram avaliados por usu�rios.<br /><br />Voc� pode escolher se��es a mostrar marcando nas caixas.<br /><br />Tamb�m pode definir o endere�o de e-mail de um autor que n�o � registrado para ser mostrado.");
define("CONTENT_ADMIN_HELP_OPTION_DIV_13", "A P�gina de Top Score/Mais Avaliados mostra todos os �tens de conte�do que foram avaliados pelo autor do �tem de conte�do.<br /><br />Voc� pode escolher se��es a mostrar marcando as caixas.<br /><br />Tamb�m pode definir um e-mail de um autor que n�o � membro registrado para ser mostrado.");
define("CONTENT_ADMIN_HELP_OPTION_DIV_14", "esta p�gina permite a voc� configurar op��es para a p�gina de administra��o - criar categoria.<br /><br />Voc� pode definir que se��es estar�o dispon�veis quando um administrador (ou usu�rio que possui conte�do no gerenciador pessoal) criar uma nova categoria de conte�do.");


?>
