<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/chatbox_menu/languages/Portuguese_Brazilian/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("CHATBOX_L1", "N�o h� como aceitar postagens deste nome de usu�rio - se este � o seu nome de usu�rio, favor fazer login para postar.");
define("CHATBOX_L2", "�rea de Chat");
define("CHATBOX_L3", "Voc� precisa est� logado para postar coment�rios neste site - favor fazer login ou caso n�o esteja registrado ainda, clique <a href='".e_BASE."signup.php'>AQUI</a> para registrar-se");
define("CHATBOX_L4", "Enviar");
define("CHATBOX_L5", "Limpar");
define("CHATBOX_L6", "[bloqueado pelo admin]");
define("CHATBOX_L7", "Desbloqueado");
define("CHATBOX_L8", "Informa��es");
define("CHATBOX_L9", "Bloqueado");
define("CHATBOX_L10", "Apagar");
define("CHATBOX_L11", "N�o h� mensagens ainda.");
define("CHATBOX_L12", "Visualizar todas as postagens");
define("CHATBOX_L13", "moderar �rea de chat");
define("CHATBOX_L14", "Emoticons");
define("CHATBOX_L15", "Postagem muito extensa, ou campo vazio enviado");
define("CHATBOX_L16", "An�nimo");
define("CHATBOX_L17", "Postagem duplicada");
define("CHATBOX_L18", "Moderar mensagens da �rea de Chat");
define("CHATBOX_L19", "Voc� poder� postar apenas a cada ".FLOODTIMEOUT." segundos");
define("CHATBOX_L20", "�rea de Chat (todas as postagens)");
define("CHATBOX_L21", "Postagens no Chat");
define("CHATBOX_L22", "em");
define("CHATBOX_L23", "Erro!");
define("CHATBOX_L24", "Voc� n�o tem as permiss�es corretas para visualizar esta p�gina.");
define("CHATBOX_L25", "[ esta postagem foi bloqueada pelo admin ]");
define("NT_LAN_CB_1", "Eventos da �rea de Chat");
define("NT_LAN_CB_2", "Mensagem postada");
define("NT_LAN_CB_3", "Postado por");
define("NT_LAN_CB_4", "Endere�o IP");
define("NT_LAN_CB_5", "Mensagem");
define("NT_LAN_CB_6", "Mensagem postada na �rea de Chat");

?>
