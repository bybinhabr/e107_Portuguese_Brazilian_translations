<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/chatbox_menu/languages/Portuguese_Brazilian/Portuguese_Brazilian_config.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("CHBLAN_1", "Configura��es da �rea de Chat atualizadas.");
define("CHBLAN_2", "Moderado.");
define("CHBLAN_3", "N�o h� postagens ainda na �rea de chat");
define("CHBLAN_4", "Membro");
define("CHBLAN_5", "Convidado");
define("CHBLAN_6", "desbloquear");
define("CHBLAN_7", "bloquear");
define("CHBLAN_8", "apagar");
define("CHBLAN_9", "Moderar a �rea de Chat");
define("CHBLAN_10", "Moderar postagens");
define("CHBLAN_11", "Postagens exibidas na �rea de chat");
define("CHBLAN_12", "<u>Quantidade de postagens a mostrar na �rea de chat</u>");
define("CHBLAN_13", "Trocar links");
define("CHBLAN_14", "Se selecionado, os links postados ser�o trocados pelo texto digitado abaixo");
define("CHBLAN_15", "Senten�a para troca, se ativado");
define("CHBLAN_16", "os links ser�o trocados por esta senten�a");
define("CHBLAN_17", "Contagem da quebra de palavras");
define("CHBLAN_18", "Palavras mais extensas que o n�mero configurado ser�o quebradas");
define("CHBLAN_19", "Atualizar Prefer�ncias do Chat");
define("CHBLAN_20", "Prefer�ncias do Chat");
define("CHBLAN_21", "Limpar");
define("CHBLAN_22", "<u>Deletar postagens mais antigas de um certo per�odo de tempo</u>");
define("CHBLAN_23", "Deletar postagens mais antigas que");
define("CHBLAN_24", "Um dia");
define("CHBLAN_25", "Uma semana");
define("CHBLAN_26", "Um m�s");
define("CHBLAN_27", "- Apagar todas as postagens -");
define("CHBLAN_28", "�rea de Chat limpa.");
define("CHBLAN_29", "Mostrar �rea de Chat dentro de uma camada com barras de rolagem");
define("CHBLAN_30", "Altura da camada");
define("CHBLAN_31", "Mostrar Emoticons");
define("CHBLAN_32", "Classe de usu�rio do moderador");
define("CHBLAN_33", "Contagem de usu�rios recalculada");
define("CHBLAN_34", "Recalcular contagem de postagens de usu�rios");
define("CHBLAN_35", "Recalcular");
define("CHBLAN_36", "Op��es de exibi��o da �rea de Chat");
define("CHBLAN_37", "Chat Normal");
define("CHBLAN_38", "Usar c�digo javascript para atualizar postagens dinamicamente (AJAX)");

?>
