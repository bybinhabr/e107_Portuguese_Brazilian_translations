<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/newforumposts_main/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("NFPM_LAN_1", "T�pico");
define("NFPM_LAN_2", "Enviado por");
define("NFPM_LAN_3", "Visualiza��es");
define("NFPM_LAN_4", "Respostas");
define("NFPM_LAN_5", "�ltima Postagem");
define("NFPM_LAN_6", "T�picos");
define("NFPM_LAN_7", "por");
define("NFPM_L1", "Este plugin mostra uma lista de novas mensagens no f�rum na sua p�gina principal");
define("NFPM_L2", "�ltimas Mensagens no F�rum");
define("NFPM_L3", "Para configurar, por favor clique no link na se��o de plugins da p�gina principal da administra��o");
define("NFPM_L4", "Ativar em que �rea?");
define("NFPM_L5", "Inativo");
define("NFPM_L6", "Topo da p�gina");
define("NFPM_L7", "Fundo da p�gina");
define("NFPM_L8", "T�tulo");
define("NFPM_L9", "N�mero de novas mensagens a mostrar?");
define("NFPM_L10", "Mostrar dentro de uma janela deslizante?");
define("NFPM_L11", "Altura da Janela");
define("NFPM_L12", "Configura��o de Novas Mensagens no F�rum");
define("NFPM_L13", "Atualizar Prefer�ncias de Novas Mensagens no F�rum");
define("NFPM_L14", "As Prefer�ncias de Novas Mensagens no F�rum foram atualizadas.");
define("NFPM_L15", "Selecione para mostrar as �ltimas mensagens no f�rum.<br />Por padr�o s�o os �ltimos t�picos.");
define("NFPM_L16", "[usu�rio apagado]");

?>
