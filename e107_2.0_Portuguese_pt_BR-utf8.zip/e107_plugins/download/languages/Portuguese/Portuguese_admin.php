<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/download/languages/Portuguese/Portuguese_admin.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/28 19:29:11 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/
define("LAN_DL_OPTIONS", "Opções");
define("LAN_DL_DOWNLOAD_OPT_GENERAL", "Geral");
define("LAN_DL_DOWNLOAD_OPT_BROKEN", "Relatórios");
define("LAN_DL_DOWNLOAD_OPT_AGREE", "Acordos");
define("LAN_DL_UPLOAD", "Upload");
define("LAN_DL_USE_PHP", "Usar PHP");
define("LAN_DL_USE_PHP_INFO", "Marcando isso irá enviar todos os pedidos de transferência por meio de PHP");
define("LAN_DL_SUBSUB_CAT", "Mostrar sub-sub-categorias");
define("LAN_DL_SUBSUB_CAT_INFO", "Verificando isso vai mostrar as sub-sub-categorias na página de download principal");
define("LAN_DL_SUBSUB_COUNT", "Combine contagens de categorias");
define("LAN_DL_SUBSUB_COUNT_INFO", "Incluir contagem de sub-sub-categoria nas contagens de sub-categoria");
define("DOWLAN_1", "Download adicionado ao banco de dados.");
define("DOWLAN_2", "Download atualizado no banco de dados.");
define("DOWLAN_5", "Não existem categorias de download definidas ainda, até que você defina alguns você não pode entrar com nenhum download.");
define("DOWLAN_8", "Nada modificado - nada foi salvo");
define("DOWLAN_9", "Detalhes do Download:");
define("DOWLAN_10", "Uploads");
define("DOWLAN_11", "Categoria");
define("DOWLAN_12", "Nome");
define("DOWLAN_13", "Arquivo");
define("DOWLAN_15", "Autor");
define("DOWLAN_16", "Email do Autor");
define("DOWLAN_17", "Website do Autor");
define("DOWLAN_18", "Descrição");
define("DOWLAN_19", "Imagem Principal");
define("DOWLAN_20", "Imagem de Thumbnail");
define("DOWLAN_21", "Status");
define("DOWLAN_22", "Listar uploads");
define("DOWLAN_23", "Tipos de arquivos");
define("DOWLAN_24", "Atualizar Download");
define("DOWLAN_25", "Enviar Download");
define("DOWLAN_27", "Download");
define("DOWLAN_28", "Nenhum");
define("DOWLAN_31", "Categorias");
define("DOWLAN_32", "Downloads");
define("DOWLAN_33", "Tem certeza que quer deletar este download?");
define("DOWLAN_42", "Ver Imagens");
define("DOWLAN_43", "Visível para");
define("DOWLAN_55", "Número de downloads a mostrar por página");
define("DOWLAN_56", "Classificar por");
define("DOWLAN_59", "Nome do Arquivo");
define("DOWLAN_62", "Ascendente");
define("DOWLAN_63", "Descendente");
define("DOWLAN_64", "Atualizar Opções");
define("DOWLAN_65", "Opções Atualizadas");
define("DOWLAN_66", "Tamanho do Arquivo");
define("DOWLAN_67", "ID");
define("DOWLAN_68", "Faltando Arquivo!");
define("DOWLAN_100", "Ativar Acordo de Download");
define("DOWLAN_101", "Texto do Acordo");
define("DOWLAN_102", "Permitir Comentários?");
define("DOWLAN_103", "Remover dos Uploads");
define("DOWLAN_104", "foi removido da pasta de uploads públicos");
define("DOWLAN_105", "Voltar para Uploads Públicos");
define("DOWLAN_106", "Pode ser baixado por");
define("DOWLAN_107", "Contagem de Limite de download");
define("DOWLAN_108", "Limite de Banda de download");
define("DOWLAN_109", "a cada");
define("DOWLAN_110", "dias");
define("DOWLAN_111", "kb");
define("DOWLAN_112", "Limites");
define("DOWLAN_113", "Classe de usuário");
define("DOWLAN_114", "Adicionar Novo Limite");
define("DOWLAN_115", "Atualizar limites");
define("DOWLAN_122", "Inativo");
define("DOWLAN_123", "Ativo - Arquivo está sujeito a limites de download");
define("DOWLAN_124", "Ativo - Arquivo NÃO está sujeito aos limites de download");
define("DOWLAN_125", "Limites de Download ativo");
define("DOWLAN_128", "Espelhos/Mirrors");
define("DOWLAN_129", "Deixe em branco para não usar espelhos");
define("DOWLAN_130", "Adicionar outro espelho");
define("DOWLAN_131", "Selecionar um arquivo local");
define("DOWLAN_132", "Favor digitar um espelho a usar, o endereço para o download e o tamanho do arquivo");
define("DOWLAN_133", "Espelho atualizado no banco de dados");
define("DOWLAN_134", "Espelho salvo no banco de dados");
define("DOWLAN_135", "Espelho deletado");
define("DOWLAN_136", "imagem");
define("DOWLAN_137", "Tem certeza que quer deletar este espelho?");
define("DOWLAN_138", "Espelhos existentes");
define("DOWLAN_139", "Endereço");
define("DOWLAN_140", "Faça Upload de imagens para a pasta e107_files/downloadimages para mostrá-las aqui, ou digite o endereço completo se a imagem for remota");
define("DOWLAN_141", "Localização");
define("DOWLAN_142", "Atualizar Espelho");
define("DOWLAN_143", "Criar Espelho");
define("DOWLAN_144", "Sem espelhos definidos na seção de espelhos.");
define("DOWLAN_145", "Download visível para");
define("DOWLAN_146", "Customizar Mensagem de Download negado ou URL");
define("DOWLAN_148", "Verificar para atualizar a data para a data atual");
define("DOWLAN_149", "URL");
define("DOWLAN_150", "Enviar Email para o admin quando downloads quebrados forem reportados");
define("DOWLAN_151", "Reportar Download Quebrado disponível para");
define("DOWLAN_152", "Não há como mover o arquivo");
define("DOWLAN_153", "Mover arquivo para dentro da pasta de download");
define("DOWLAN_154", "se usar espelhos, selecione como eles serão mostrados");
define("DOWLAN_155", "Tipo de exibição de espelhos:");
define("DOWLAN_156", "mostrar lista de espelho, permite ao usuário escolher qual espelho quer");
define("DOWLAN_157", "usar um espelho randômico - sem escolha do usuário");
define("DOWLAN_160", "Ordem da lista de espelhos");
define("DOWLAN_161", "Randômica");
define("DOWLAN_164", "Downloads recentes (em dias)");
define("DOWLAN_165", "Manutenção de Download");
define("DOWLAN_166", "Duplicados");
define("DOWLAN_167", "Órfãos");
define("DOWLAN_168", "Faltando");
define("DOWLAN_169", "Inativos");
define("DOWLAN_171", "Log");
define("DOWLAN_172", "Sem entradas");
define("DOWLAN_173", "Tem certeza que quer deletar este arquivo?");
define("DOWLAN_174", "Nenhum arquivo órfão foi encontrado");
define("DOWLAN_175", "Local");
define("DOWLAN_176", "Externo");
define("DOWLAN_178", "Sem categoria");
define("DOWLAN_179", "Selecione uma opção a partir do menu de Opções de Manutenção");
define("DOWLAN_180", "Tamanho do arquivo (banco de dados/disco)");
define("DOWLAN_181", "Não pode ser lido");
define("DOWLAN_182", "Data");
define("DOWLAN_185", "Arquivos com referências múltiplas no banco de dados");
define("DOWLAN_186", "Arquivos não referenciados no BD");
define("DOWLAN_187", "Entradas no BD apontando para arquivos não existentes");
define("DOWLAN_188", "Entradas no BD marcadas como inativas");
define("DOWLAN_189", "Entradas no BD não associadas com uma categoria");
define("DOWLAN_190", "Tamanhos diferentes entre o BD e o arquivo em si");
define("DOWLAN_191", "Entradas no Log de Downloads");
define("DOWLAN_192", "Executar opção selecionada");
define("DOWLAN_193", "Selecionar Opção");
define("DOWLAN_195", "Tipo de espelho");
define("DOWLAN_196", "lista");
define("DOWLAN_197", "randômico");
define("DOWLAN_HELP_1", "Ajuda");
define("DOWLAN_HELP_2", "<p>Criar/editar um download.</p><p>Digite apenas um de: Arquivo, URL ou Espelho.</p><p>Certifique-se que você escolheu uma categoria, caso contrário, seu download não poderá ser visto na página de downloads.</p>");
define("DOWLAN_HELP_3", "Ajuda para categoria");
define("DOWLAN_HELP_4", "Ajuda para opções");
define("DOWLAN_HELP_5", "Use as páginas de manutenção para encontrar downloads duplicados, arquivos órfãos, entradas quebradas ou faltantes, gerenciar downloads inativos, atualizar os tamanhos de arquivos e ver o log de download.");
define("DOWLAN_HELP_6", "Ajuda para limites");
define("DOWLAN_HELP_7", "Ajuda para espelhos");
define("DOWLAN_HELP_8", "Ajuda para lista de upload");
define("DOWLAN_HELP_9", "Ajuda para tipos de upload");
define("DOWLAN_HELP_10", "Ajuda para opções de upload");


?>