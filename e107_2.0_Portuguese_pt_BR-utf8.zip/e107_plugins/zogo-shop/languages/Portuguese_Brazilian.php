<?php
// Traduzido para o Portugu�s do Brasil por bybinhabr da comunidade e107Brasil.NET e testado por Diego Bispo
// Categories page
//
define("lan_category","Categorias");

//
// Product display page (also re-used elsewhere
//
define("lan_product_name","Nome do Produto");
define("lan_price","Pre�o");
define("lan_quantity","Quantidade");
define("lan_options","Op��es");
define("lan_add_to_cart","Adicionar ao Carrinho");
define("lan_go_to", "Ir para a P�gina:");
define("lan_not_in_stock", "Fora de Estoque <br>Favor checar em breve");
define("lan_sub_cats", "Sub-Categorias");

//
// Cart page (some of the above are used)
//
define("lan_price_per_item", "Pre�o por item");
define("lan_cart_error", "Aconteceu um erro ao adicionar o(s) item/�tens no seu carrinho");
define("lan_shopping_cart", USERNAME.", seu Carrinho de Compras");
define("lan_total", "<font size='3'>Valor Total: </font>");
define("lan_update_cart", "Atualizar Item");
define("lan_delete_cart", "Deletar");
define("lan_shopping_cart_link", "Carrinho de Compras");
define("lan_postage_calculated_next", "Postagem e Pacote ser�o calculados quando voc� preencher seus detalhes");
define("lan_postage", "Postagem e Pacote:");
define("lan_postage_included", "A postagem est� inclu�da no pre�o do produto");
define("lan_empty_cart", "Esvaziar Carrinho");
define("lan_checkout", "Finalizar Pedido");
define("lan_cart_emptied", "Carrinho de Compras Vazio");
define("lan_cart_empty_complete", "Seu carrinho de compras est� vazio");
define("lan_tax_inc", "Taxas:");
define("lan_tax_ex", "Taxas:");
define("lan_subtotal", "SubTotal:");

//
// Checkout Pages
//
define("lan_checkout", "Finalizar Pedido");
define("lan_must_be_member", "Voc� precisa ser um membro registrado e logado para fazer uma compra <br><a href='".e_SIGNUP."'>Clique AQUI para se Registrar</a> <br><a href='".e_LOGIN."'>Clique AQUI para fazer Login</a>");
define("lan_name", "Primeiro Nome: ");
define("lan_last_name", "�ltimo Nome: ");
define("lan_email", "E-mail: ");
define("lan_address", "Endere�o: ");
define("lan_city", "Cidade: ");
define("lan_state", "Estado: ");
define("lan_country", "Pa�s: ");
define("lan_zip", "CEP: ");
define("lan_region", "Regi�o: ");
define("lan_proceed_pay", "Proceder para Pagamento");
define("lan_payment_method", "M�todo de Pagamento: ");
define("lan_coupon_code", "C�digo de Cupom: ");

//
// Payment pages
//
define("lan_click_to_complete", "VOC� PRECISA CLICAR AQUI PARA FINALIZAR SUA COMPRA!");
define("lan_payment", "Pagamento");
define("lan_pay_now", "Clique AQUI para pagar agora");
define("lan_valid_coupon_title", "Desconto Aplicado");
define("lan_valid_coupon", "Seu c�digo foi aceito e o desconto foi aplicado.");
define("lan_invalid_coupon_title", "C�digo Inv�lido");
define("lan_invalid_coupon", "O seu c�digo de desconto expirou ou j� foi usado");

//
// Order pages
//
define("lan_order_number", "N�mero de Ordem: ");
define("lan_error_processing", "Seu pagamento foi completado, mas aconteceu um erro ao processar seu pedido, favor entrar em contato conosco para assist�ncia enviando o seguinte n�mero de pedido: ".$_GET["o"]);
define("lan_cart_not_found", "Seus �tens n�o foram encontrados no carrinho. Se voc� acha que isto � um erro, favor entrar em contato conosco enviando o seguinte n�mero de pedido: ".$_GET["o"]);
define("lan_payment_failed", "H� um erro com seu pagamento, favor retornar ao carrinho de compras e tentar novamente");
define("lan_printable_invoice", "Clique aqui para fazer o download do seu recibo (PDF)");

//
// the invoice text/terms
//
define("lan_invoice_text", "Este recibo deve ser guardado como prova de sua compra. | Agradecemos por ter feito uma compra em nossa loja | e esperamos negociar novamente em breve.");
define("lan_invoice_title", "Recibo: ");
define("lan_invoice_business", SITENAME);
define("lan_business_details", "Castro - Paran�");
define("lan_invoice_payment_mode", "M�TODO DE PAGAMENTO");
define("lan_invoice_date", "DATA");
define("lan_invoice_page", "P�GINA");
define("lan_invoice_tax_heading", "Impostos");
define("lan_tax_ID", "- isento -");
define("lan_invoice_ref", "REF");
define("lan_invoice_ph", "Postagem");
define("lan_invoice_tax", "Taxas:");
define("lan_invoice_total", "Total:");




//
// Admin Languages
//

define("lan_admin_prod_no_prod_title", "Erro no Produto");
define("lan_admin_prod_no_prod_error", "N�o h� produtos nesta categoria");
define("lan_manage_products_title", "Gerenciar Produtos");
define("lan_manage_products_products", "Produtos Dispon�veis");
define("lan_admin_go", "Filtrar");
define("lan_admin_edit", "Editar");
define("lan_admin_delete", "Deletar");
define("lan_manage_cats_title", "Lista de Categorias");
define("lan_manage_cats_products", "Categorias Dispon�veis");
define("lan_admin_cat_active", "Categorias Ativas");
define("lan_admin_cat_inactive", "Categorias Inativas");
define("lan_admin_prod_price", "Pre�o do Produto");
define("lan_admin_prod_postage", "Pre�o da Postagem");
define("lan_admin_prod_stock", "Em Estoque");
define("lan_admin_prod_thumbnail", "Visualiza��o / Thumbnail do Produto");
define("lan_admin_prod_image", "Imagem do Produto");
define("lan_admin_prod_description", "Descri��o do Produto: (para a p�gina de detalhes)");
define("lan_submit", "Enviar");
define("lan_admin_prod_cat", "Categorias");

define("lan_admin_product_update_title", "Produto Atualizado");
define("lan_admin_product_updated", "O produto foi atualizado com sucesso");
define("lan_admin_del_title", "Produto Deletado");
define("lan_admin_del_text", "O produto foi deletado com sucesso");
define("lan_admin_prod_active", "Ativo");
define("lan_admin_del_c_title", "Categoria Deletada");
define("lan_admin_del_c_text", "A categoria foi deletada com sucesso");

define("lan_category_name", "Nome da Categoria");
define("lan_admin_cat_parent", "Categoria PAI");
define("lan_admin_cat_order", "Ordem da Categoria");
define("lan_admin_cat_description", "Descri��o da Categoria");
define("lan_admin_cat_thumbnail", "Imagem da Categoria");
define("lan_admin_cat1_active", "Ativa");
define("lan_admin_cat_update_title", "Categoria Atualizada");
define("lan_admin_cat_updated", "A categoria foi atualizada com sucesso");

define("lan_admin_disable", "Desativar");
define("lan_admin_enable", "Ativar");

define("lan_admin_disabled", "<b>Desativado</b>");
define("lan_admin_enabled", "<b>Ativado</b>");


//
// Admin menu text
//
define("lan_admin_menu_settings", "Configura��es Principais do ZoGo");
define("lan_admin_menu_products", "Gerenciar os Produtos da Loja");
define("lan_admin_menu_categories", "Gerenciar as Categorias da Loja");
define("lan_admin_menu_options", "Gerenciar Produtos Op��es/Atributos");
define("lan_admin_menu_coupons", "Gerenciar Cupons/Descontos");
define("lan_admin_menu_post", "Gerenciar Regi�es de Postagem");
define("lan_admin_menu_index", "P�gina de Hist�rico da Loja");
define("lan_admin_menu_sales", "Gerenciar Pedidos");

define("lan_admin_info_block_title", "Informa��o da Loja");
define("lan_admin_info_block_product", "Produtos Ativos no Cat�logo");
define("lan_admin_info_block_inactive_product", "Produtos Inativos no Cat�logo");
define("lan_admin_info_block_active_category", "Categorias Ativas no Cat�logo");
define("lan_admin_info_block_inactive_category", "Categorias Inativas no Cat�logo");
define("lan_admin_orders_block_total_offline_orders", "Total de pedidos offline");

define("lan_admin_orders_block_title", "Vis�o Geral dos Pedidos");
define("lan_admin_orders_block_orders", "A��es Pendentes do Admin");
define("lan_admin_orders_block_total_orders", "Total de Pedidos");
define("lan_admin_orders_block_total_complete_orders", "Total de Pedidos Finalizados");


//
// Zogo settings langs
//
define("lan_admin_store_name", "Nome da Loja");
define("lan_admin_store_language", "Idioma da Loja");
define("lan_admin_order_email", "Email para enviar os detalhes do Pedido");
define("lan_admin_use_coupons", "Usar Cupons");
define("lan_admin_store_currency", "Moeda da Loja (REAL, USD, etc)");
define("lan_admin_store_cur_symbol", "S�mbolo da Moeda");
define("lan_admin_store_order_id", "N�mero do Pedido");
define("lan_admin_store_products_order", "Ordenar Produtos por");
define("lan_admin_store_products_perpage", "Produtos Por P�gina");
define("lan_admin_store_cat_display", "Estilo da apresenta��o das Categorias");
define("lan_admin_customer_member", "Comprador precisa ser membro para comprar");
define("lan_admin_tax_inc", "Taxas Inclusas (As taxas j� foram inclu�das no valor do produto)");
define("lan_admin_store_tax_rate", "Porcentagem de Taxas (como %)");
define("lan_admin_post_included", "Inclusas no pre�o do produto");
define("lan_admin_post_peritem", "Postagem do Item baseada em");
define("lan_admin_post_region", "Baseada em Regi�o");
define("lan_admin_store_post_method", "M�todo de Postagem");
define("lan_admin_store_warning", "Aviso de Estoque Baixo");
define("lan_sell_minus_stock", "Vender Item quando n�o estiver em estoque");

define("lan_admin_settings_update_title", "Atualiza��es Atualizadas");
define("lan_admin_settings_updated", "As configura��es de sua loja foram atualizadas com sucesso");
define("lan_admin_settings_inserted_title", "Configura��es Adicionadas");
define("lan_admin_settings_inserted", "Suas configura��es foram salvas");

define("lan_admin_nocat_title", "N�o h� Categorias");
define("lan_admin_nocat_error", "Voc� n�o tem nenhuma categoria ainda");


//
// Product options
//
define("lan_manage_products_attributes_title", "Gerenciar Atributos");
define("lan_manage_products_attributes", "Atributo do Produto");
define("lan_admin_store_no_attributes_title", "Sem Atributos/Op��es");
define("lan_admin_store_no_attributes_text", "Sem Atributos, ou nenhum produto foi selecionado");
define("lan_admin_del_title_at", "Atributo Deletado");
define("lan_admin_del_text_at", "O atributo foi deletado");
define("lan_admin_prod_at_val", "Valor da Op��o");
define("lan_admin_prod_at_group", "Grupo da Op��o (sens�vel a mai�scula/min�scula)");
define("lan_attribute_name", "T�tulo da Op��o");
define("lan_admin_prod_at_operator", "Operador");
define("lan_admin_prod_at", "Produto");
define("lan_filter_products_title", "Filtrar por Produto");
define("lan_filter_products", "Produtos");

//
// Coupons
//
define("lan_admin_no_coupons_title", "Sem Cupons");
define("lan_admin_no_coupons_error", "N�o h� cupons no seu sistema");

define("lan_coupon_name", "T�tulo do Cupom");
define("lan_manage_coupons_title", "Gerenciar Cupons");
define("lan_admin_coupon_code", "C�digo do Cupom");
define("lan_admin_coupon_exp", "Expira em (mm/dd/yyyy)");
define("lan_admin_coupon_type", "Tipo de Desconto");
define("lan_admin_coupon_used", "Quantidade de vezes que poder� ser usado");
define("lan_admin_coupon_valid", "Quantidade de vezes permitidas");
define("lan_admin_coupon_discount", "Quantidade de Desconto");

define("lan_admin_coupon_update_title", "Cupom Atualizado");
define("lan_admin_coupon_updated", "O cupom foi atualizado com sucesso");

define("lan_admin_coupon_created_title", "Cupom Criado");
define("lan_admin_coupon_created", "O cupom foi criado com sucesso");

define("lan_manage_postage_regions_title", "Gerenciar Regi�es Postais");
define("lan_manage_postage_regions", "Regi�es Postais");

define("lan_manage_postage_name", "Regi�o");
define("lan_admin_postage_price", "Pre�o da Postagem");
define("lan_admin_prostage_extra", "Quantidade Extra");
define("lan_admin_region_update_title", "Regi�o atualizada");
define("lan_admin_region_updated", "A regi�o foi atualizada");
define("lan_manage_regions", "Gerenciar Regi�es");
define("lan_admin_coupons_error", "N�o h� cupons dispon�veis no momento");


define("lan_no_perms_to_order", "Voc� n�o tem permiss�o para ver este pedido. Voc� talvez n�o esteja logado, ou o pedido n�o existe, ou pertence a outra pessoa");

//
//emails
//
define("lan_admin_success_purchase_subject", "Uma compra foi feita na sua loja virtual");
define("lan_customer_email_success_subject", "Seu Pedido foi feito com sucesso");
define("lan_admin_email_process_error_subject", "Aconteceu um erro ao processar um pedido");
define("lan_customer_email_process_error_subject", "Aconteceu um erro ao processar seu pedido");
define("lan_admin_email_cart_subject", "Um pedido falhou e n�o pode ser localizado");
define("lan_customer_email_cart_subject", "Seu pedido n�o pode ser finalizado");
define("lan_admin_email_payment_error_subject", "O pagamento e o pedido falharam");
define("lan_customer_email_payment_error_subject", "Seu pagamento n�o teve sucesso");

//
// Gateway management
//
define("lan_admin_gateway_account", "Conta Gateway");
define("lan_admin_menu_gateway", "Gerenciar Gateways");
define("lan_admin_gateway_field", "Detalhes Extras ");
define("lan_gateway_update_title", "Gateway Atualizado");
define("lan_gateway_update_text", "O gateway foi atualizado com sucesso");


//
// order management
//

define("lan_admin_orders_number", "N�mero do Pedido");
define("lan_admin_orders_user", "Usu�rio");
define("lan_admin_orders_gateway", "Gateway Usado");
define("lan_admin_orders_lastmod", "�ltima Modifica��o");
define("lan_admin_orders_status", "Status do Pedido");
define("lan_admin_orders_search", "Procurar Pedidos");
define("lan_admin_order_filter", "Filtrar por");
define("lan_admin_order_shipped", "Enviado: ");
define("lan_admin_order_completed", "Completado: ");
define("lan_delete_order", "Deletar Pedido");


//
// zogo-shop 1.1
//
define("lan_advanced_prod_options", "Op��es Avan�adas");
define("lan_admin_prod_download", "Produtos por Download");
define("lan_admin_prod_download_file", "Arquivo de Download");
define("lan_admin_prod_go_to_page", "Rodar Fun��o no Produto depois da compra");
define("lan_admin_prod_go_to_info", "<br>Vari�veis Permitidas: \$theorder, \$thestatus, \$theOnumber, \$thegateway, \$theregion, \$coupon");
define("lan_product_vars", "Fun��o das Vari�veis");
define("lan_product_function_1", "Fun��es Definidas");
define("lan_admin_download_dir", "Diret�rio de Download (caminho completo da URL)");
define("lan_admin_license", "N�mero da Licen�a");
define("lan_admin_special_info", "Coloque um pre�o aqui para colocar o produto em \"Especial\"");
define("lan_admin_prod_special", "Pre�o Especial");
define("lan_product_was", "era");
define("lan_product_now", "agora");

define("lan_zogo_download_title", "Downloads Dispon�veis");
define("lan_zogo_download_error", "Voc� precisa fazer login para acessar os downloads");
define("lan_zogo_download_download", "Seu arquivo est� sendo baixado");
define("lan_zogo_download", "Download");

define("lan_admin_custom_function", "Gerenciar Fun��es Customizadas");
define("lan_admin_prod_no_function_title", "N�o h� Fun��es Definidas");
define("lan_admin_prod_no_function_error", "Voc� n�o tem nenhuma fun��o atualmente");
define("lan_manage_products_functions_title", "Fun��es Dispon�veis");
define("lan_manage_functions_attributes", "Fun��es");
define("lan_function_name", "Nome da Fun��o: (exclua vari�veis. ex.: minha_funcao() )");
define("lan_admin_function_function", "Fun��o (c�digo PHP completo)");
define("lan_admin_function_update_title", "Fun��o Atualizada");
define("lan_admin_function_updated", "A Fun��o foi atualizada com sucesso");
define("lan_admin_function_insert_error_title", "Erro na inser��o de dados");
define("lan_admin_function_error", "Aconteceu um erro quando tentava criar a fun��o. O banco de dados retornou o seguinte erro");
define("lan_admin_function_inserted_title", "Fun��o Inserida");
define("lan_admin_function_inserted", "A Fun��o foi criada com sucesso");

define("lan_admin_content_insert_error_title", "Erro");
define("lan_admin_content_error", "Retornou um erro enquanto inseria seu conte�do");
define("lan_admin_content_inserted_title", "Conte�do Inserido");
define("lan_admin_content_inserted", "Sua p�gina personalizada de conte�do foi inserida corretamente");
define("lan_admin_content_update_title", "Conte�do Atualizado");
define("lan_admin_content_updated", "A p�gina customizada de conte�do foi atualizada");

define("lan_admin_prod_no_content_title", "N�o h� Conte�do");
define("lan_admin_prod_no_content_error", "N�o h� conte�do definido");
define("lan_manage_products_content_title", "Conte�do Atual");
define("lan_manage_content_attributes", "Conte�do");
define("lan_content_name", "Nome do Conte�do");
define("lan_admin_content_content", "P�gina de Conte�do");
define("lan_content_page", "P�gina");
define("lan_content_position", "Posi��o");
define("lan_admin_custom_content", "Conte�do de P�gina Customizada");
?>