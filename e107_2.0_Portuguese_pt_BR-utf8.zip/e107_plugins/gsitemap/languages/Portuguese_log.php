<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/gsitemap/languages/Portuguese_log.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/28 19:35:58 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_AL_GSMAP_01", "Importar links do site");
define("LAN_AL_GSMAP_02", "Link deletado do Mapa do site ");
define("LAN_AL_GSMAP_03", "Link adicionado no Mapa do Site");
define("LAN_AL_GSMAP_04", "Link atualizado no Mapa do Site");
define("LAN_AL_GSMAP_05", " ");


?>