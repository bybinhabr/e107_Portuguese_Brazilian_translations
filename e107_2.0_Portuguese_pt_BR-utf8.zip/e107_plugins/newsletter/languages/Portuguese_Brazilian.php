<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/newsletter/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("NLLAN_MENU_CAPTION", "Boletim de Not�cias");
define("NLLAN_01", "Boletim de Not�cias");
define("NLLAN_02", "Fornece uma forma simples e r�pida de configurar e enviar boletim de not�cias");
define("NLLAN_03", "Configurar Boletim de Not�cias");
define("NLLAN_04", "O plugin newsletter foi instalado com sucesso. Para configurar, volte � p�gina principal da administra��o e clique em 'Boletim de Not�cias' na se��o de plugins.");
define("NLLAN_05", "Nenhum boletim de not�cia definido ainda");
define("NLLAN_06", "Nome");
define("NLLAN_07", "Assinantes");
define("NLLAN_08", "Op��es");
define("NLLAN_09", "Tem certeza que quer apagar este boletim de not�cias?");
define("NLLAN_10", "Boletins de Not�cia Existentes");
define("NLLAN_11", "Ainda n�o h� edi��es de boletim de not�cias");
define("NLLAN_12", "Edi��o");
define("NLLAN_13", "[ ID do Parente ] Assunto/T�tulo");
define("NLLAN_14", "Enviado?");
define("NLLAN_15", "Op��es");
define("NLLAN_16", "sim");
define("NLLAN_17", "N�o enviado - clique para enviar");
define("NLLAN_18", "Tem certeza que quer enviar esta edi��o para os assinantes?");
define("NLLAN_19", "Tem certeza que quer apagar esta edi��o do boletim de not�cias?");
define("NLLAN_20", "Edi��es Existentes");
define("NLLAN_21", "T�tulo");
define("NLLAN_22", "Descri��o");
define("NLLAN_23", "Cabe�alho");
define("NLLAN_24", "Rodap�");
define("NLLAN_25", "Atualizar Boletim de Not�cias");
define("NLLAN_26", "Criar Boletim de Not�cias");
define("NLLAN_27", "Boletim de not�cias atualizado na base de dados.");
define("NLLAN_28", "Boletim de not�cias definido e gravado na base de dados.");
define("NLLAN_29", "Ainda n�o h� boletins de not�cias definidos.");
define("NLLAN_30", "Boletim de Not�cias");
define("NLLAN_31", "Assunto / T�tulo");
define("NLLAN_32", "Edi��o N�mero");
define("NLLAN_33", "Texto");
define("NLLAN_34", "Atualizar Envios");
define("NLLAN_35", "Criar Envios");
define("NLLAN_36", "Atualizar Edi��o do Boletim de Not�cias");
define("NLLAN_37", "Criar Edi��o do Boletim de Not�cias");
define("NLLAN_38", "Boletim de not�cias atualizada na base de dados.");
define("NLLAN_39", "Edi��o do boletim de not�cias gravado na base de dados - para enviar,clique em 'Lan�ar Edi��o' no menu Op��es.");
define("NLLAN_40", "Envio completo - edi��o enviada a");
define("NLLAN_41", " assinante(s).");
define("NLLAN_42", "Boletim de not�cias apagado.");
define("NLLAN_43", "Edi��o do boletim de not�cias apagado.");
define("NLLAN_44", "P�gina Inicial do Boletim de Not�cias");
define("NLLAN_45", "Criar Boletim de Not�cias");
define("NLLAN_46", "Criar Envios");
define("NLLAN_47", "Op��es do Boletim de Not�cias");
define("NLLAN_48", "voc� � assinante deste boletim de not�cias - se deseja encerrar a assinatura, por favor clique no bot�o abaixo.");
define("NLLAN_49", "Tem certeza de que deseja cancelar a assinatura deste boletim de not�cias?");
define("NLLAN_50", "Clique no bot�o para assinar ( o endere�o da assinatura �");
define("NLLAN_51", "Cancelar Assinatura");
define("NLLAN_52", "Assinar");
define("NLLAN_53", "Tem a certeza de que deseja assinar esta newsletter?");
define("NLLAN_54", "Enviando");
define("NLLAN_55", "ID");
define("NLLAN_56", "ID da Newsletter n�o est� dispon�vel");
define("NLLAN_57", "Retornar � p�gina anterior");
define("NLLAN_58", "Erro");
define("NLLAN_59", "Nome");
define("NLLAN_60", "Email");
define("NLLAN_61", "A��es");
define("NLLAN_62", "Usu�rio foi banido! (ou n�o fez login completo)");
define("NLLAN_63", "Total de inscritos");
define("NLLAN_64", "Retornar � primeira p�gina da Newsletter");
define("NLLAN_65", "Vis�o geral de Inscritos - ID newsletter");


?>