<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/pm/languages/admin/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("ADLAN_PM", "Mensagens Privadas");
define("ADLAN_PM_1", "Para ativar, favor ir � tela de menus e selecionar o private_msg em uma de suas �reas de menu. <br /><br />Se voc� quiser converter mensagens de uma vers�o anterior, favor ir � p�gina de configura��o do plugin e selecione o link 'converter'.");
define("ADLAN_PM_2", "Configurar Mensagens Privadas");
define("ADLAN_PM_3", "Configura��es das Mensagens Privadas n�o encontradas, valores configurados para o padr�o");
define("ADLAN_PM_4", "Op��es Atualizadas");
define("ADLAN_PM_5", "Limite para classe de usu�rios selecionada j� existentes");
define("ADLAN_PM_6", "Limite adicionado com sucesso");
define("ADLAN_PM_7", "Limite n�o adicionado - erro desconhecido");
define("ADLAN_PM_8", "Limite atualizado");
define("ADLAN_PM_9", " - Limite removido com sucesso");
define("ADLAN_PM_10", " - Limite n�o removido - erro desconhecido");
define("ADLAN_PM_11", " - Limite atualizado com sucesso");
define("ADLAN_PM_12", "Op��es das Mensagens Privadas");
define("ADLAN_PM_13", "Convers�o das Mensagens Privadas");
define("ADLAN_PM_14", "Limites das Mensagens Privadas");
define("ADLAN_PM_15", "Adicionar Limite de Mensagens Privadas");
define("ADLAN_PM_16", "T�tulo do Plugin");
define("ADLAN_PM_17", "Mostrar anima��o de nova Mensagem Privada");
define("ADLAN_PM_18", "Mostrar caixa dropdown de usu�rio");
define("ADLAN_PM_19", "Tempo limite de mensagens LIDAS");
define("ADLAN_PM_20", "Tempo limite de mensagens N�O LIDAS");
define("ADLAN_PM_21", "Notificar nova mensagem privada com pop-up");
define("ADLAN_PM_22", "Tempo de atraso da janela pop-up");
define("ADLAN_PM_23", "Restringir uso de Mensagens Privadas para");
define("ADLAN_PM_24", "N�mero de Mensagens Privadas a mostrar por p�gina");
define("ADLAN_PM_25", "Ativar notifica��es por e-mail de Mensagens Privadas");
define("ADLAN_PM_26", "Permitir ao usu�rio solicitar notifica��o quando a mensagem for lida");
define("ADLAN_PM_27", "Permitir postagem de anexos");
define("ADLAN_PM_28", "Tamanho m�ximo de anexo");
define("ADLAN_PM_29", "Permitir envio para todos os membros");
define("ADLAN_PM_30", "Permitir envio para diversos usu�rios");
define("ADLAN_PM_31", "Ativar envio para classe de usu�rios");
define("ADLAN_PM_32", "Atualizar Prefer�ncias");
define("ADLAN_PM_33", "Inativo (sem limites)");
define("ADLAN_PM_34", "Mensagens Privadas - contagem");
define("ADLAN_PM_35", "Tamanho das caixas de mensagens privadas");
define("ADLAN_PM_36", "Classe de usu�rio");
define("ADLAN_PM_37", "Limites de contagem");
define("ADLAN_PM_38", "Limites de Tamanho (em KB)");
define("ADLAN_PM_39", "Caixa de Entrada:");
define("ADLAN_PM_40", "Caixa de Sa�da:");
define("ADLAN_PM_41", "N�o h� limites configurados.");
define("ADLAN_PM_42", "Atualizar Limites");
define("ADLAN_PM_43", "Adicionar Novo Limite");
define("ADLAN_PM_44", "segundos");
define("ADLAN_PM_45", "Limitar Mensagem Privada Por:");
define("ADLAN_PM_46", "Convers�o de Mensagem Privada");
define("ADLAN_PM_47", "Parece que voc� n�o tem nenhuma mensagem antiga, de vers�es anteriores, pode desinstalar o plugin antigo com seguran�a");
define("ADLAN_PM_48", "Voc� tem {OLDCOUNT} mensagens da vers�o anterior, favor decidir o que quer fazer com essas mensagens<br /><br />Se for converter as mensagens, qualquer mensagem convertida com sucesso ser� removida do sistema antigo.");
define("ADLAN_PM_49", "Converter para o novo sistema de Mensagens Privadas");
define("ADLAN_PM_50", "Descartar mensagens antigas");
define("ADLAN_PM_51", "Mensagem Privada #{PMNUM} n�o convertida");
define("ADLAN_PM_52", "mensagens convertidas");
define("ADLAN_PM_53", "N�o h� registros a converter.");
define("ADLAN_PM_54", "Configura��es Principais");
define("ADLAN_PM_55", "Limites");
define("ADLAN_PM_56", "Convers�o");
define("ADLAN_PM_57", "Este plugin tem fun��o completa de sistema de Mensagens Privadas.");
define("ADLAN_PM_58", "Mensagem Privada");


?>
