<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/pm/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LAN_PM", "Mensagens Privadas");
define("LAN_PM_1", "Enviar Mensagem Privada");
define("LAN_PM_2", "Para");
define("LAN_PM_3", "Pr�-visualizar");
define("LAN_PM_4", "Classe de usu�rio");
define("LAN_PM_5", "Assunto");
define("LAN_PM_6", "Mensagem");
define("LAN_PM_7", "Emoticons");
define("LAN_PM_8", "Anexos");
define("LAN_PM_9", "Ler mensagens recebidas");
define("LAN_PM_10", "Envie-me um e-mail quando essa mensagem privada for lida");
define("LAN_PM_11", "adicionar novo anexo");
define("LAN_PM_12", "Voc� n�o est� autorizado a usar o sistema de mensagens privadas");
define("LAN_PM_13", "Sua caixa de saida est� {PERCENT}% cheia, delete algumas para liberar o envio");
define("LAN_PM_14", "ERRO: Prov�vel mensagem duplicada, n�o foi poss�vel enviar mensagem privada");
define("LAN_PM_15", "Voc� n�o possui permiss�o para enviar mensagens para essa classe de usu�rios");
define("LAN_PM_16", "Deve ser membro dessa classe");
define("LAN_PM_17", "Usu�rio n�o encontrado");
define("LAN_PM_18", "Voc� n�o possui permiss�o para enviar mensagens privadas para:");
define("LAN_PM_19", "Sua caixa de sa�da est� cheia, voc� n�o pode enviar mais mensagens privadas");
define("LAN_PM_21", "Adicionando essa mensagem privada voc� exceder� o m�ximo de sua caixa de sa�da, mensagem n�o enviada");
define("LAN_PM_22", "Falha no envio de arquivo");
define("LAN_PM_23", "Voc� n�o possui permiss�es para enviar anexos");
define("LAN_PM_24", "Apagando Mensagens Privadas");
define("LAN_PM_25", "Caixa de Entrada");
define("LAN_PM_26", "Caixa de Sa�da");
define("LAN_PM_27", "N�o lida");
define("LAN_PM_28", "N/A");
define("LAN_PM_29", "Mensagem Enviada");
define("LAN_PM_30", "Mensagem Lida");
define("LAN_PM_31", "Para");
define("LAN_PM_32", "Recebidas");
define("LAN_PM_33", "Enviada");
define("LAN_PM_34", "Sem Mensagens");
define("LAN_PM_35", "Enviar nova mensagem");
define("LAN_PM_36", "total");
define("LAN_PM_37", "n�o lida");
define("LAN_PM_38", "Enviar mensagem privada para a classe de usu�rio");
define("LAN_PM_39", "Erro ao enviar a mensagem privada para");
define("LAN_PM_40", "Mensagem privada enviada para o usu�rio");
define("LAN_PM_41", "N�o enviou a mensagem privada para a sua caixa de sa�da");
define("LAN_PM_42", "Mensagem privada apagada da caixa de entrada");
define("LAN_PM_43", "Mensagem privada apagada da caixa de sa�da");
define("LAN_PM_44", "Bloqueio removido: {UNAME} est� liberado para lhe enviar mensagens privadas");
define("LAN_PM_45", "ERRO: Bloqueio n�o foi removido, erro desconhecido");
define("LAN_PM_46", "N�o foi poss�vel Bloquear {UNAME}");
define("LAN_PM_47", "Bloqueio adicionado: {UNAME} n�o poder� lhe enviar mais mensagens privadas");
define("LAN_PM_48", "ERRO: Bloqueio n�o foi adicionado, erro desconhecido");
define("LAN_PM_49", "ERRO: Bloqueio j� existe para {UNAME}");
define("LAN_PM_50", "Bloquear Usu�rio");
define("LAN_PM_51", "Desbloquear Usu�rio");
define("LAN_PM_52", "Apagar");
define("LAN_PM_53", "Apagar Selecionado");
define("LAN_PM_54", "Mensagem original");
define("LAN_PM_55", "Enviar Resposta");
define("LAN_PM_56", "Voc� n�o tem permiss�o para responder essa mensagem");
define("LAN_PM_57", "Mensagem n�o encontrada");
define("LAN_PM_58", "Re:");
define("LAN_PM_59", "Ir para p�gina");
define("LAN_PM_60", "Voc� n�o tem permiss�o para visualizar essa mensagem");
define("LAN_PM_61", "Sem assunto");
define("LAN_PM_62", "Arquivo: [{FILENAME}] excedeu o tamanho limite - n�o foi anexada");
define("LAN_PM_63", "classe:");
define("LAN_PM_64", "ERRO: Voc� n�o tem permiss�o de bloquear mensagens dos administradores do site");
define("LAN_PM_65", "ERRO: Nada para enviar");
define("LAN_PM_100", "Nova mensagem privada de ");
define("LAN_PM_101", "Voc� recebeu uma mensagem privada nova de");
define("LAN_PM_102", "Mensagem enviada por:");
define("LAN_PM_103", "Assunto da mensagem:");
define("LAN_PM_104", "N�mero de anexos:");
define("LAN_PM_105", "Voc� pode ver a mensagem privada em:");
define("LAN_PM_106", "Mensagem privada lida por");
define("LAN_PM_107", "A mensagem privada enviada para {UNAME} foi lida em");
define("LAN_PM_108", "Mensagem enviada em:");
define("LAN_PM_109", "Nova(s) Mensagem(ns)");
define("LAN_PM_110", "ok");
define("LAN_PM_111", "Ler");


?>