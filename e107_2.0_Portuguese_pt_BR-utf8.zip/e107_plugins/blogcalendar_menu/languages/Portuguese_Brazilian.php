<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/blogcalendar_menu/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("BLOGCAL_L1", "Not�cias para");
define("BLOGCAL_L2", "Arquivo");
define("BLOGCAL_D1", "Seg");
define("BLOGCAL_D2", "Ter");
define("BLOGCAL_D3", "Qua");
define("BLOGCAL_D4", "Qui");
define("BLOGCAL_D5", "Sex");
define("BLOGCAL_D6", "Sab");
define("BLOGCAL_D7", "Dom");
define("BLOGCAL_M1", "Janeiro");
define("BLOGCAL_M2", "Fevereiro");
define("BLOGCAL_M3", "Mar�o");
define("BLOGCAL_M4", "Abril");
define("BLOGCAL_M5", "Maio");
define("BLOGCAL_M6", "Junho");
define("BLOGCAL_M7", "Julho");
define("BLOGCAL_M8", "Agosto");
define("BLOGCAL_M9", "Setembro");
define("BLOGCAL_M10", "Outubro");
define("BLOGCAL_M11", "Novembro");
define("BLOGCAL_M12", "Dezembro");
define("BLOGCAL_1", "�tens de Not�cia");
define("BLOGCAL_CONF1", "N� de colunas para exibir os meses");
define("BLOGCAL_CONF2", "Espa�o entre c�lulas");
define("BLOGCAL_CONF3", "Atualizar Prefer�ncias de Menu");
define("BLOGCAL_CONF4", "Configura��es do Menu do Calend�rio");
define("BLOGCAL_CONF5", "Configura��es do menu do calend�rio salvas");
define("BLOGCAL_ARCHIV1", "Selecione Arquivo");

?>
