<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/blogcalendar_menu/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("BLOGCAL_L1", "Notícias para");
define("BLOGCAL_L2", "Arquivo");
define("BLOGCAL_D1", "Seg");
define("BLOGCAL_D2", "Ter");
define("BLOGCAL_D3", "Qua");
define("BLOGCAL_D4", "Qui");
define("BLOGCAL_D5", "Sex");
define("BLOGCAL_D6", "Sáb");
define("BLOGCAL_D7", "Dom");
define("BLOGCAL_M1", "Janeiro");
define("BLOGCAL_M2", "Fevereiro");
define("BLOGCAL_M3", "Março");
define("BLOGCAL_M4", "Abril");
define("BLOGCAL_M5", "Maio");
define("BLOGCAL_M6", "Junho");
define("BLOGCAL_M7", "Julho");
define("BLOGCAL_M8", "Agosto");
define("BLOGCAL_M9", "Setembro");
define("BLOGCAL_M10", "Outubro");
define("BLOGCAL_M11", "Novembro");
define("BLOGCAL_M12", "Dezembro");
define("BLOGCAL_1", "Itens de Notícia");
define("BLOGCAL_CONF1", "Nº de colunas para exibir os meses");
define("BLOGCAL_CONF2", "Espaço entre células");
define("BLOGCAL_CONF3", "Atualizar Preferências de Menu");
define("BLOGCAL_CONF4", "Configurações do Menu do Calendário");
define("BLOGCAL_CONF5", "Configurações do menu do calendário salvas");
define("BLOGCAL_ARCHIV1", "Selecione Arquivo");


?>