<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/online/languages/Portuguese.php $
|        $Revision: 1.0 $
|        $Id: 2015/03/01 00:36:20 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_LASTSEEN_1", "Menu Últimas Visitas");
define("LAN_ONLINE_TRACKING_MESSAGE", "Acompanhamento de usuário online está desativado, favor ativá-lo [link=".e_ADMIN."users.php?options]aqui[/link][br]");
define("LAN_ONLINE_1", "Convidados:");
define("LAN_ONLINE_2", "Membros:");
define("LAN_ONLINE_3", "Nesta página:");
define("LAN_ONLINE_4", "Online");
define("LAN_ONLINE_5", "");
define("LAN_ONLINE_6", "Membro mais novo:");
define("LAN_ONLINE_7", "vendo");
define("LAN_ONLINE_8", "Mais tempo online:");
define("LAN_ONLINE_9", "em");
define("LAN_ONLINE_10", "Online Menu");
define("LAN_ONLINE_ADMIN_1", "menu últimas visitas");
define("LAN_ONLINE_ADMIN_2", "Título do menu últimas visitas");
define("LAN_ONLINE_ADMIN_3", "Número de registros a serem exibidos");
define("LAN_ONLINE_ADMIN_4", "online menu");
define("LAN_ONLINE_ADMIN_5", "Título do menu online");
define("LAN_ONLINE_ADMIN_6", "Mostrar lista de membros online?");
define("LAN_ONLINE_ADMIN_7", "Mostrar lista estendida de membros online?");
define("LAN_ONLINE_ADMIN_8", "Exibe uma lista de membros separados por vírgulas.");


?>