<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/login_menu/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LOGIN_MENU_L1", "Usu�rio:");
define("LOGIN_MENU_L2", "Senha:");
define("LOGIN_MENU_L3", "Registrar");
define("LOGIN_MENU_L4", "Esqueceu a senha?");
define("LOGIN_MENU_L5", "Bem-Vindo");
define("LOGIN_MENU_L6", "Relembrar senha");
define("LOGIN_MENU_L7", "Erro de conex�o por identifica��o de usu�rio (poss�vel cookie corrompido).<br />Por favor <a href=\"".e_BASE."index.php?logout\">clique aqui</a> para destru�-lo.");
define("LOGIN_MENU_L8", "Desconectar");
define("LOGIN_MENU_L9", "Erro de Login");
define("LOGIN_MENU_L10", "O site est� em manuten��o - isso significa que os membros do sites ser�o redirecionados para sitedown.php. Para alterar esse estado, v� em admin/manuten��o.");
define("LOGIN_MENU_L11", "�rea de Admin");
define("LOGIN_MENU_L12", "Prefer�ncias");
define("LOGIN_MENU_L13", "Perfil");
define("LOGIN_MENU_L14", "novo �tem");
define("LOGIN_MENU_L15", "novos �tens");
define("LOGIN_MENU_L16", "postagem no chat");
define("LOGIN_MENU_L17", "postagens no chat");
define("LOGIN_MENU_L18", "coment�rio");
define("LOGIN_MENU_L19", "coment�rios");
define("LOGIN_MENU_L20", "postagem no f�rum");
define("LOGIN_MENU_L21", "postagens no f�rum");
define("LOGIN_MENU_L22", "novo membro do site");
define("LOGIN_MENU_L23", "novos membros do site");
define("LOGIN_MENU_L24", "Clique aqui para ver a lista de novos �tens");
define("LOGIN_MENU_L25", "Desde a sua �tima visita");
define("LOGIN_MENU_L26", "n�o");
define("LOGIN_MENU_L27", "e");
define("LOGIN_MENU_L28", "Login");
define("LOGIN_MENU_L29", "novo artigo");
define("LOGIN_MENU_L30", "novos artigos");
define("LOGIN_MENU_L31", "Mostrar novas not�cias");
define("LOGIN_MENU_L32", "Mostrar novos artigos");
define("LOGIN_MENU_L33", "Mostrar novas mensagens de chat");
define("LOGIN_MENU_L34", "Mostrar novos coment�rios");
define("LOGIN_MENU_L35", "Mostrar novas mensagens no f�rum");
define("LOGIN_MENU_L36", "Mostrar novos membros cadastrados");
define("LOGIN_MENU_L39", "Sair da Administra��o");
define("LOGIN_MENU_L40", "Re-enviar e-mail de ativa��o");
define("LOGIN_MENU_L41", "Configura��es do Menu de Login");


?>
