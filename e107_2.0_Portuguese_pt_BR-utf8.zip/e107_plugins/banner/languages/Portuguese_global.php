<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/banner/languages/Portuguese_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/15 19:54:07 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_BANNER_NAME", "Banners");
define("LAN_PLUGIN_BANNER_DESCRIPTION", "Adiciona banners de anunciantes em seu site do e107");


?>