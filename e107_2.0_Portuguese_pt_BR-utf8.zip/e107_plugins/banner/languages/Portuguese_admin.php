<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/banner/languages/Portuguese_admin.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/28 19:07:18 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("BNRLAN_00", "Nenhum banner criado ainda.");
define("BNRLAN_01", "ID de banner não encontrado.");
define("BNRLAN_7", "Estatísticas");
define("BNRLAN_8", "Nada");
define("BNRLAN_9", "Inicia em");
define("BNRLAN_10", "Termina em");
define("BNRLAN_11", "Campanha");
define("BNRLAN_12", "Login do Cliente");
define("BNRLAN_13", "Senha do Cliente");
define("BNRLAN_14", "Imagem do Banner");
define("BNRLAN_15", "URL do clique");
define("BNRLAN_16", "Número de impressões compradas");
define("BNRLAN_17", "Data de início");
define("BNRLAN_18", "Data de fim");
define("BNRLAN_25", "Adicionar nova ou escolher campanha existente");
define("BNRLAN_28", "Adicionar nova ou escolher cliente existente");
define("BNRLAN_29", "Digitar novo cliente");
define("BNRLAN_30", "Novo Cliente");
define("BNRLAN_31", "Sem limites quando deixado em branco.");
define("BNRLAN_32", "Escolher imagem do banner");
define("BNRLAN_33", "Código");
define("BNRLAN_35", "Menu do banner");
define("BNRLAN_36", "Configuração do menu do banner");
define("BNRLAN_37", "Título");
define("BNRLAN_38", "Anúncio");
define("BNRLAN_39", "Campanhas mostradas no menu");
define("BNRLAN_40", "Sem campanhas ainda.");
define("BNRLAN_41", "Número de banners a mostrar");
define("BNRLAN_42", "Isto só é usado quando múltiplas campanhas são selecionadas.");
define("BNRLAN_43", "Como mostrar as campanhas?");
define("BNRLAN_44", "Escolher tipo de renderização...");
define("BNRLAN_45", "Uma campanha em um menu apenas");
define("BNRLAN_46", "Todas as campanhas em um menu apenas");
define("BNRLAN_47", "Todas as campanhas em menus separados");


?>