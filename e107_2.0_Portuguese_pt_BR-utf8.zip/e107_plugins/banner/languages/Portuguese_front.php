<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/banner/languages/Portuguese_front.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/21 21:47:47 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Banner");
define("BANNERLAN_16", "Usuário:");
define("BANNERLAN_17", "Senha:");
define("BANNERLAN_19", "Favor digitar o login e senha do cliente para continuar");
define("BANNERLAN_20", "Desculpe, não encontramos esses detalhes em nosso banco de dados. Favor entrar em contato com o administrador do site para saber mais.");
define("BANNERLAN_21", "Estatísticas de banners");
define("BANNERLAN_22", "Cliente");
define("BANNERLAN_23", "ID do Banner");
define("BANNERLAN_24", "Cliques");
define("BANNERLAN_25", "Clique %");
define("BANNERLAN_26", "Impressões");
define("BANNERLAN_27", "Impressões Compradas");
define("BANNERLAN_28", "Impressões restantes");
define("BANNERLAN_29", "Sem banners");
define("BANNERLAN_30", "Ilimitado");
define("BANNERLAN_31", "Não aplicável");
define("BANNERLAN_34", "Termina em:");
define("BANNERLAN_35", "Endereços IP dos cliques");
define("BANNERLAN_36", "Ativo:");
define("BANNERLAN_37", "Inicia em:");


?>