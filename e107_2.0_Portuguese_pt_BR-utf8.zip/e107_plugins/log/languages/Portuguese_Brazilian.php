<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/log/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Estat�sticas");
define("ADSTAT_L1", "Este plugin regista todas as visitas ao seu site, e cria op��es de estat�sticas detalhadas baseadas nas informa��es recolhidas.");
define("ADSTAT_L2", "O registro de estat�sticas foi instalado com sucesso. Para converter as suas estat�sticas existentes para o novo sistema, por favor <a href='".e_PLUGIN."log/update_routine.php'>clique aqui para executar a rotina de atualiza��o</a>.");
define("ADSTAT_L3", "Registro de Estat�sticas");
define("ADSTAT_L4", "N�o tem permiss�o para ver esta p�gina.");
define("ADSTAT_L5", "As fun��es desta p�gina foram desativadas.");
define("ADSTAT_L6", "Estat�sticas do Site");
define("ADSTAT_L7", "Estat�sticas para este tipo n�o foram recolhidas.");
define("ADSTAT_L8", "Estat�sticas de Hoje");
define("ADSTAT_L9", "Estat�sticas Gerais");
define("ADSTAT_L10", "Estat�sticas Di�rias");
define("ADSTAT_L11", "Estat�sticas Mensais");
define("ADSTAT_L12", "Navegadores");
define("ADSTAT_L13", "Sistemas Operacionais");
define("ADSTAT_L14", "Dom�nios");
define("ADSTAT_L15", "Resolu��es de Tela / Quantidade de Cores");
define("ADSTAT_L16", "Refer�ncias");
define("ADSTAT_L17", "Strings de Busca");
define("ADSTAT_L18", "Visitantes Recentes");
define("ADSTAT_L19", "P�gina");
define("ADSTAT_L20", "Visitas de Hoje");
define("ADSTAT_L21", "Total");
define("ADSTAT_L22", "�nicos");
define("ADSTAT_L23", "Total de Visitas");
define("ADSTAT_L24", "Total de Visitas �nicas");
define("ADSTAT_L25", "Nenhuma estat�stica ainda.");
define("ADSTAT_L26", "Navegador");
define("ADSTAT_L27", "Sistema Operacional");
define("ADSTAT_L28", "Pa�ses / Dom�nios");
define("ADSTAT_L29", "Resolu��o de Tela");
define("ADSTAT_L30", "Refer�ncias do Site");
define("ADSTAT_L31", "Pesquisas dos Motores de Busca");
define("ADSTAT_L32", "Referenciado de");
define("ADSTAT_L33", "Visitas nos �ltimos");
define("ADSTAT_L34", "Visitas");
define("ADSTAT_L35", "Visitas �nicas nos �ltimos");
define("ADSTAT_L36", "dias por p�gina");
define("ADSTAT_L37", "Visitas por m�s");
define("ADSTAT_L38", "Visitas �nicas por m�s");
define("ADSTAT_L39", "remover este registro");
define("ADSTAT_L40", "dias");
define("ADSTAT_L41", "Erro");
define("ADSTAT_L42", "N�o h� estat�stica mensal ainda.");
define("ADSTAT_L43", "Erros em p�ginas hoje");
define("ADSTAT_L44", "Erros em p�ginas (todos)");
define("ADSTAT_L45", "Estat�sticas deletadas para:");
define("ADSTAT_L46", "Nota: qualquer estat�stica para hoje n�o ser� apagada");
define("ADSTAT_L47", "Nenhuma estat�stica encontrada para:");
define("ADSTAT_L48", "");
define("ADSTAT_L49", "");
define("ADSTAT_L50", "");


?>
