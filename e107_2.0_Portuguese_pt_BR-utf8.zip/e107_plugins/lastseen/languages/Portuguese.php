<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/lastseen/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LSP_LAN_1", "Visto pela última vez");


?>