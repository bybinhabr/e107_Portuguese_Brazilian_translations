<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/alt_auth/languages/Portuguese/admin_importdb_conf.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/16 19:59:49 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/
define("IMPORTDB_LAN_9", "Método da senha:");
define("IMPORTDB_LAN_10", "Configurar tipo de senha importada do BD");
define("IMPORTDB_LAN_11", "Esta opção é para ser usada quando você importa algum outro sistema baseado em usuário dentro do e107. Isto permite a você a aceitar senhas codificadas em formato fora do padrão selecionado. Cada senha de usuário é convertida para o formato do e107 quando eles fizerem login.");
define("LAN_AUTHENTICATE_HELP", "Este método de autenticação é para ser usado <i>apenas</i> quando você tiver importado um BD de usuários para o e107, com senhas de formato incompatível. A senha original é lida do banco de dados local e validada com o formato original guardado no sistema. Se a verificação estiver correta, é convertida para o formato compatível com o e107 e gravada no banco de dados. Depois de algum tempo, você pode desativar o plugin alt-auth (de autenticação), quando todos os usuários ativos tiverem suas senhas armazenadas no formato compatível.");


?>