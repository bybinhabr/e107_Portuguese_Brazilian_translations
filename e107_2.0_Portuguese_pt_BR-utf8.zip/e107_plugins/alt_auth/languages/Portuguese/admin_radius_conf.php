<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/alt_auth/languages/Portuguese/admin_radius_conf.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/21 21:11:22 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_RADIUS_01", "Endereço do Servidor");
define("LAN_RADIUS_02", "Segredo compartilhado");
define("LAN_RADIUS_03", "Usuário do Servidor");
define("LAN_RADIUS_04", "Senha do servidor");
define("LAN_RADIUS_06", "Configurar autenticação RADIUS");
define("LAN_RADIUS_11", "AVISO: Parece que o módulo RADIUS não está disponível atualmente; configurar seu método para RADIUS provavelmente não funcionará!");
define("LAN_AUTHENTICATE_HELP", "Este método de autenticação é usado com um servidor RADIUS externo. Isto requer que a extensão RADIUS do PHP esteja ativada. <br />Note que o servidor RADIUS poderá apenas permitir acesso de um certo alcance específico de endereços IP.");


?>