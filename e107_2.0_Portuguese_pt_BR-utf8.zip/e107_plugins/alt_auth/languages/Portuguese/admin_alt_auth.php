<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/alt_auth/languages/Portuguese/admin_alt_auth.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/28 17:12:46 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/
define("LAN_ALT_1", "Tipo de autorização primária");
define("LAN_ALT_2", "Atualizar configurações");
define("LAN_ALT_3", "Escolher tipo de autorização alternativa");
define("LAN_ALT_4", "Configurar parâmetros para");
define("LAN_ALT_5", "Configurar parâmetros de autorização");
define("LAN_ALT_6", "Ação para conexão falha");
define("LAN_ALT_7", "Se a conexão para o tipo de autorização primária falhar (e se não é o BD local do e107), como deverá ser manipulada?");
define("LAN_ALT_8", "Tipo de autorização secundária");
define("LAN_ALT_9", "Isto é usado se o método de autorização primária não encontrar o usuário");
define("LAN_ALT_10", "Campo Nome de login do usuário");
define("LAN_ALT_11", "Campo Senha do usuário");
define("LAN_ALT_12", "Campo Email do usuário");
define("LAN_ALT_13", "Campo Esconder Email?");
define("LAN_ALT_14", "Campo Nome de Exibição do usuário");
define("LAN_ALT_15", "Campo Nome Real do usuário");
define("LAN_ALT_16", "Campo Título Customizado do usuário");
define("LAN_ALT_17", "Campo de Assinatura");
define("LAN_ALT_18", "Campo Avatar");
define("LAN_ALT_19", "Campo Foto");
define("LAN_ALT_20", "Campo Data de Afiliação no Site");
define("LAN_ALT_21", "Campo Status de Banimento");
define("LAN_ALT_22", "Campo Classe de usuário");
define("LAN_ALT_24", "Campo Senha Refinada/Esperta");
define("LAN_ALT_25", "(às vezes combinada com a senha para adicionar mais segurança)");
define("LAN_ALT_26", "Tipo de banco de dados:");
define("LAN_ALT_27", "Para transferir um campo de valor no banco de dados local, especifique o nome do campo correspondente na caixa abaixo. (Usuário e senha sempre serão transferidos) <br />Deixe em branco para não transferir nada");
define("LAN_ALT_29", "Métodos de autenticação");
define("LAN_ALT_30", "Configurar");
define("LAN_ALT_31", "Configuração Principal");
define("LAN_ALT_32", "Servidor:");
define("LAN_ALT_33", "Usuário:");
define("LAN_ALT_34", "Senha:");
define("LAN_ALT_35", "Banco de Dados:");
define("LAN_ALT_36", "Tabela:");
define("LAN_ALT_37", "Campo Nome de usuário:");
define("LAN_ALT_38", "Campo Senha:");
define("LAN_ALT_39", "Prefixo da Tabela:");
define("LAN_ALT_40", "Teste de Acesso ao Banco de Dados");
define("LAN_ALT_41", "(usando credenciais acima)");
define("LAN_ALT_42", "Se tiver digitado um usuário e senha, este usuário será sempre validado");
define("LAN_ALT_43", "Conexão ao banco de dados realizada com sucesso");
define("LAN_ALT_44", "Conexão ao banco de dados falhou");
define("LAN_ALT_45", "Pesquisa de Nome de usuário bem sucedida");
define("LAN_ALT_46", "Pesquisa de Nome de usuário falhou");
define("LAN_ALT_47", "Teste");
define("LAN_ALT_48", "Validação anterior");
define("LAN_ALT_49", "Usuário = ");
define("LAN_ALT_50", "Senha = ");
define("LAN_ALT_51", "(em branco)");
define("LAN_ALT_52", "Autenticação falhou - ");
define("LAN_ALT_53", "causa desconhecida");
define("LAN_ALT_54", "não há como conectar ao BD / provedor de serviço");
define("LAN_ALT_55", "usuário inválido");
define("LAN_ALT_56", "senha incorreta");
define("LAN_ALT_57", "método não disponível");
define("LAN_ALT_58", "Autenticação realizada com sucesso");
define("LAN_ALT_59", "Parâmetros recuperados:");
define("LAN_ALT_60", "Campos Estendidos de usuários");
define("LAN_ALT_61", "Permitir");
define("LAN_ALT_62", "Nome do Campo");
define("LAN_ALT_63", "Descrição");
define("LAN_ALT_64", "Tipo");
define("LAN_ALT_65", "Alternar Autenticação");
define("LAN_ALT_66", "Este plugin permite alternar métodos de autenticação.");
define("LAN_ALT_67", "Configurar Alternar Autenticação");
define("LAN_ALT_68", "Serviço Alternar Autenticação não está configurado. Você precisa agora configurar seu método preferido.");
define("LAN_ALT_69", "");
define("LAN_ALT_70", "Nenhum");
define("LAN_ALT_71", "VERDADEIRO/FALSO");
define("LAN_ALT_72", "Letras maiúsculas");
define("LAN_ALT_73", "Letras minúsculas");
define("LAN_ALT_74", "Primeira letra maiúscula");
define("LAN_ALT_75", "Palavras com letras maiúsculas");
define("LAN_ALT_76", "Restrição de classe de usuário (um valor numérico - zero ou em branco para todos)");
define("LAN_ALT_77", "Apenas usuários nesta classe (no banco de dados configurado acima) têm permissão de acesso");
define("LAN_ALT_78", "Ação de senha errada/falha");
define("LAN_ALT_79", "Se o usuário existir no BD primário, mas digitar uma senha incorreta, como devemos lidar com isso?");
define("IMPORTDB_LAN_2", "Texto Plano");
define("IMPORTDB_LAN_3", "Joomla modo esperto");
define("IMPORTDB_LAN_4", "Mambo modo esperto");
define("IMPORTDB_LAN_5", "SMF (SHA1)");
define("IMPORTDB_LAN_6", "SHA1 Genérico");
define("IMPORTDB_LAN_7", "MD5 (original do e107)");
define("IMPORTDB_LAN_8", "E107 modo esperto (opção com 2.0 ligado)");
define("IMPORTDB_LAN_12", "PHPBB2/PHPBB3 modo esperto");
define("IMPORTDB_LAN_13", "WordPress modo esperto");
define("IMPORTDB_LAN_14", "Magento modo esperto");
define("LAN_ALT_FALLBACK", "Usar autorização secundária");
define("LAN_ALT_FAIL", "Login falhou");
define("LAN_ALT_UPDATESET", "Atualizar configurações");
define("LAN_ALT_UPDATED", "Configurações atualizadas");
define("LAN_ALT_AUTH_HELP", "Estas são configurações comuns a todos os métodos de autenticação e determinam as ações a serem tomadas<br /><br />A opção Campo Estendido de Usuário determina quais <i>talvez</i> sejam adicionados/atualizados quando um usuário fizer login - configuração adicional é necessária para o método específico de autenticação.");
define("LAN_ALT_VALIDATE_HELP", "Você pode verificar as configurações usando a seção de \'Teste de Acesso ao Banco de Dados\' para tentar validar um usuário - este usa exatamente o mesmo processo que quando um usuário tenta fazer login, e confirma se as configurações estão corretas. <br /> Se você tiver configurado alguns parâmetros a serem copiados para a tabela de usuário no login bem-sucedido, estes também são listados.");
define("LAN_ALT_COPY_HELP", "Você pode selecionar campos para copiar a partir do banco de dados remoto no banco de dados do usuário, inserindo os nomes apropriados. <br /> <br />");
define("LAN_ALT_CONVERSION_HELP", "Para alguns campos, a caixa dropdown à direita da caixa de entrada de campo seleciona uma conversão que pode ser aplicada ao valor lido a partir do banco de dados remoto; se \'nenhum\' é selecionado, o valor é copiado como recebido. As conversões são:<br /><b>VERDADEIRO / FALSO</b> - as palavras \'TRUE\' e \'FALSE\' (e seus equivalentes em maiúsculas ou minúsculas) são convertidos para os Booleans 1 e zero <br /><b>Maiúsculas</b> - Todas as letras são convertidas para maiúsculas <br /> <b>Minúsculas</b> - Todas as letras são convertidas para minúsculas <br /> <b>Alta primeiro</b> - o primeiro caractere é convertido para maiúscula<br /> <b>Palavras superiores</b> - a primeira letra de cada palavra é convertida para maiúsculas <br /> <br /> <br />");


?>