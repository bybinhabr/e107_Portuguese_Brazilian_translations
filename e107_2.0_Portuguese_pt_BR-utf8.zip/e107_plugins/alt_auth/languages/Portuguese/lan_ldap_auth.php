<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/alt_auth/languages/Portuguese_Brazilian/lan_ldap_auth.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LDAPLAN_1", "Endereço do Servidor");
define("LDAPLAN_2", "Base de Nomes de Domínio ou Domínio<br />Se LDAP - Digite a Base de Domínio<br />Se AD - Digite domínio");
define("LDAPLAN_3", "LDAP Usuário navegando<br />Contexto completo de quem é o usuário que está apto a procurar no diretório");
define("LDAPLAN_4", "LDAP Senha para navegar<br />Senha para o usuário que vai navegar na LDAP.");
define("LDAPLAN_5", "Versão da LDAP");
define("LDAPLAN_6", "Configurar autorização para LDAP");
define("LDAPLAN_7", "Filtro de busca eDiretório:");
define("LDAPLAN_8", "Isto será usado para certificar que o usuário está na árvore correta, <br />ex. '(objectclass=inetOrgPerson)'");
define("LDAPLAN_9", "Filtro de busca atual será:");
define("LDAPLAN_10", "Configurações atualizadas");
define("LDAPLAN_11", "ATENÇÃO: Parece que o módulo ldap não está disponível atualmente, configurar seu método de autenticação para LDAP provavelmente não funcionará!");
define("LDAPLAN_12", "Tipo de servidor");
define("LDAPLAN_13", "Atualizar configurações");


?>