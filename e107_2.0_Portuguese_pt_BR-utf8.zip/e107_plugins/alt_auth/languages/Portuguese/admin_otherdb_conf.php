<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/alt_auth/languages/Portuguese/admin_otherdb_conf.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/21 21:17:56 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("OTHERDB_LAN_1", "Tipo de Banco de Dados:");
define("OTHERDB_LAN_2", "Servidor:");
define("OTHERDB_LAN_3", "Usuário:");
define("OTHERDB_LAN_4", "Senha:");
define("OTHERDB_LAN_5", "Banco de dados");
define("OTHERDB_LAN_6", "Tabela");
define("OTHERDB_LAN_7", "Campo de usuário:");
define("OTHERDB_LAN_8", "Campo de senha:");
define("OTHERDB_LAN_9", "Método de senha:");
define("OTHERDB_LAN_10", "Configurar banco de dados para outro método de autenticação");
define("OTHERDB_LAN_12", "Campo (Salt) da Senha:");
define("OTHERDB_LAN_13", "(Deixe em branco se não for usada)");
define("OTHERDB_LAN_14", "Campo do endereço de email:");
define("OTHERDB_LAN_15", "MySQL - banco de dados genérico");
define("LAN_AUTHENTICATE_HELP", "Este método de autenticação é usado para validar bancos de dados não-e107. A senha precisa ser guardada em um dos formatos suportados.");


?>