<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/alt_auth/languages/Portuguese/admin_ldap_conf.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/18 23:04:37 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/
define("LDAPLAN_1", "Endereço do servidor");
define("LDAPLAN_2", "DN Base ou Domínio<br />LDAP - Digite o DN Base<br />AD - digite o fqdn ex.: ad.meudominio.com.br");
define("LDAPLAN_3", "LDAP - navegação do usuário<br />Contexto completo do usuário que pode pesquisar o diretório.");
define("LDAPLAN_4", "LDAP - senha de navegação<br />Senha para o usuário navegar no LDAP");
define("LDAPLAN_5", "Versão do LDAP");
define("LDAPLAN_6", "Configurar autenticação LDAP");
define("LDAPLAN_7", "Filtro de busca do eDiretório:");
define("LDAPLAN_8", "Isto será usado para certificar que o usuário está na árvore correta, <br />ex.: '(objectclass=inetOrgPerson)'");
define("LDAPLAN_9", "O filtro atual será:");
define("LDAPLAN_10", "Configurações atualizadas");
define("LDAPLAN_11", "AVISO: Parece que o módulo Idap não está disponível; configurar seu método de autenticação para LDAP provavelmente não funcionará!");
define("LDAPLAN_12", "Tipo de Servidor");
define("LDAPLAN_13", "Atualizar Configurações");
define("LDAPLAN_14", "OU para AD (ex.: ou=itdept)");
define("LAN_AUTHENTICATE_HELP", "Este método pode ser usado para autenticar a maioria dos servidores LDAP, inclusive eDiretórios da Novell e Diretórios Ativos da Microsoft. Isto requer que a extensão PHP LDAP esteja lida. Procure no wiki para mais informações. O LDAP foi criado como uma alternativa ao muito mais incômodo Directory Access Protocol (DAP).");


?>