<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/alt_auth/languages/Portuguese/admin_e107db_conf.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/18 21:52:21 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("E107DB_LAN_1", "Banco de dados formato e107");
define("E107DB_LAN_9", "Método da Senha:");
define("E107DB_LAN_10", "Configurar o Banco de Dados de autenticação do e107");
define("E107DB_LAN_11", "Marque a caixa de qualquer campo que você deseja transferir para o banco de dados local:");
define("IMPORTDB_LAN_7", "MD5 (e107 original)");
define("IMPORTDB_LAN_8", "E107 expert (opção 2.0 ligada)");
define("LAN_AUTHENTICATE_HELP", "Este método de autenticação é para ser usado com uma segunda base de dados para o e107, que pode usar formato diferente de senha para o sistema. A senha original é lida do banco de dados local e validada com o formato gravado no sistema original. Se isto estiver marcado, isso vai converter o formato compatível atual do e107 e gravá-lo no banco de dados.");


?>