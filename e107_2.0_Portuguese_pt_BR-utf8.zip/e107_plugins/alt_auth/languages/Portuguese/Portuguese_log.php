<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/alt_auth/languages/Portuguese/Portuguese_log.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/15 19:52:50 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_AL_AUTH_01", "Configurações modificadas para Autenticação");
define("LAN_AL_AUTH_02", "Plugin Alt auth - Classes de usuários estendidas modificadas");
define("LAN_AL_AUTH_03", "Plugin Alt auth - configurações salvas para método de autenticação");
define("LAN_AL_AUTH_04", "");
define("LAN_AL_AUTH_05", "");
define("LAN_AL_AUTH_06", "");


?>