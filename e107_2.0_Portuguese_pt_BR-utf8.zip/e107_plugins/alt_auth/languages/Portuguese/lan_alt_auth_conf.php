<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/alt_auth/languages/Portuguese_Brazilian/lan_alt_auth_conf.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LAN_ALT_2", "Atualizar Configurações");
define("LAN_ALT_3", "Escolher tipo de autorização alternativa");
define("LAN_ALT_4", "Configurar parâmetros para");
define("LAN_ALT_5", "Configurar parâmetros de autorização");
define("LAN_ALT_6", "Ação de conexão falhou");
define("LAN_ALT_7", "Se a conexão para os métodos alternativos falhar, como lidar com isso?");
define("LAN_ALT_8", "Ação para usuário não encontrado");
define("LAN_ALT_9", "Se o nome do usuário não for encontrado usando métodos alternativos, como lidar com isso?");
define("LAN_ALT_10", "Login Falho");
define("LAN_ALT_11", "Use a tabela de usuários do e107");
define("LAN_ALT_PAGE", "Autenticação Alternativa");


?>