<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/alt_auth/languages/Portuguese_Brazilian/lan_alt_auth_conf.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LAN_ALT_1", "Tipo de autoriza��o atual");
define("LAN_ALT_2", "Atualizar Configura��es");
define("LAN_ALT_3", "Escolher tipo de autoriza��o 
alternativa");
define("LAN_ALT_4", "Configurar par�metros para");
define("LAN_ALT_5", "Configurar par�metros de autoriza��o");
define("LAN_ALT_6", "A��o de conex�o falhou");
define("LAN_ALT_7", "Se a conex�o para os m�todos alternativos falhar, como lidar com isso?");
define("LAN_ALT_8", "A��o para usu�rio n�o encontrado");
define("LAN_ALT_9", "Se o nome do usu�rio n�o for encontrado usando m�todos alternativos, como lidar com isso?");
define("LAN_ALT_FALLBACK", "Usar a tabela de usu�rios do e107");
define("LAN_ALT_FAIL", "Login falho");

?>
