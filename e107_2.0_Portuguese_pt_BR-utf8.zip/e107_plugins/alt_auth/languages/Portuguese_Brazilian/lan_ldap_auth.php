<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/alt_auth/languages/Portuguese_Brazilian/lan_ldap_auth.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LDAPLAN_1", "Endere�o do Servidor");
define("LDAPLAN_2", "Base de Nomes de Dom�nio ou Dom�nio<br />Se LDAP - Digite a Base de Dom�nio<br />Se AD - Digite dom�nio");
define("LDAPLAN_3", "LDAP Usu�rio navegando<br />Contexto completo de quem � o usu�rio que est� apto a procurar no diret�rio");
define("LDAPLAN_4", "LDAP Senha para navegar<br />Senha para o usu�rio que vai navegar na LDAP.");
define("LDAPLAN_5", "Vers�o da LDAP");
define("LDAPLAN_6", "Configurar autoriza��o para LDAP");
define("LDAPLAN_7", "Filtro de busca eDiret�rio:");
define("LDAPLAN_8", "Isto ser� usado para certificar que o usu�rio est� na �rvore correta, <br />ex. '(objectclass=inetOrgPerson)'");
define("LDAPLAN_9", "Filtro de busca atual ser�:");
define("LDAPLAN_10", "Configura��es atualizadas");
define("LDAPLAN_11", "ATEN��O: Parece que o m�dulo ldap n�o est� dispon�vel atualmente, configurar seu m�todo de autentica��o para LDAP provavelmente n�o funcionar�!");
define("LDAPLAN_12", "Tipo de servidor");
define("LDAPLAN_13", "Atualizar configura��es");


?>
