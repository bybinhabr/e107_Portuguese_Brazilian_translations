<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/lan_date.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LANDT_01", "ano");
define("LANDT_02", "mês");
define("LANDT_03", "semana");
define("LANDT_04", "dia");
define("LANDT_05", "hora");
define("LANDT_06", "minuto");
define("LANDT_07", "segundo");
define("LANDT_01s", "anos");
define("LANDT_02s", "meses");
define("LANDT_03s", "semanas");
define("LANDT_04s", "dias");
define("LANDT_05s", "horas");
define("LANDT_06s", "minutos");
define("LANDT_07s", "segundos");
define("LANDT_08", "min");
define("LANDT_08s", "mins");
define("LANDT_09", "seg");
define("LANDT_09s", "segs");
define("LANDT_AGO", "atrás");


?>