<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/lan_sitedown.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Site temporariamente fechado =-= (EM MANUTENÇÃO)");
define("LAN_SITEDOWN_00", "está temporariamente fechado");
define("LAN_SITEDOWN_01", "Nós estamos temporariamente fechados para manutenção essencial do site. Isto não irá demorar muito - favor verificar em breve, desculpe-nos pela inconveniência.");


?>