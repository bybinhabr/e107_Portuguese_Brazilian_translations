<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
setlocale(LC_ALL,'portuguese');
define("CORE_LC", "pt");
define("CORE_LC2", "br");
define("CORE_LAN1", "Erro: Faltando arquivos do tema. <b>Mude o tema usado em suas preferências (Área de administração) ou faça upload dos arquivos do tema atual.</b>");
define("CORE_LAN4", "Por favor, apague o arquivo install.php do seu servidor");
define("CORE_LAN5", "pois ele pode ser potencialmente perigoso para seu website");
define("CORE_LAN6", "A proteção de flood foi ativada neste site e você está sendo avisado que poderá ser banido caso continue a solicitar páginas com muita frequência.");
define("CORE_LAN7", "O sistema está tentando restaurar as preferências de um backup automático.");
define("CORE_LAN8", "Erro nas Preferências do Sistema");
define("CORE_LAN9", "Execução falhou. O sistema não pode se restaurar de um backup automático.");
define("CORE_LAN10", "Cookie corrompido detectado - faça login novamente.");
define("CORE_LAN11", "Tempo de renderização:");
define("CORE_LAN12", " segundos (");
define("CORE_LAN13", "%  disso para consultas).");
define("CORE_LAN14", "%2.3f uso de cpu por seg (%2.2f%% carregados, %2.3f iniciados). Relógio:");
define("CORE_LAN15", "Conteúdos no BD:");
define("CORE_LAN16", "Uso de Memória:");
define("CORE_LAN17", "[ imagem desativada ]");
define("CORE_LAN18", "Imagem:");
define("CORE_LAN_B", "b");
define("CORE_LAN_KB", "kb");
define("CORE_LAN_MB", "Mb");
define("CORE_LAN_GB", "Gb");
define("CORE_LAN_TB", "Tb");
define("EMESSLAN_TITLE_INFO", "Informação do Sistema");
define("EMESSLAN_TITLE_ERROR", "Erro");
define("EMESSLAN_TITLE_SUCCESS", "Sucesso");
define("EMESSLAN_TITLE_WARNING", "Aviso");
define("EMESSLAN_TITLE_DEBUG", "Debug do Sistema");
define("LAN_EDIT", "Editar");
define("LAN_DELETE", "Deletar");
define("LAN_MORE", "Mais...");
define("LAN_READ_MORE", "Leia mais...");
define("LAN_GOPAGE", "Ir para a página");
define("LAN_GO", "Ir");
define("LAN_NONE", "Nenhum(a)");
define("LAN_WARNING", "Atenção!");
define("LAN_ERROR", "Erro");
define("LAN_ANONYMOUS", "Anônimo");
define("LAN_EMAIL_SUBS", "-email-");
define("LAN_YES", "Sim");
define("LAN_NO", "Não");
define("LAN_OK", "OK");
define("LAN_CONTINUE", "Continue");
define("LAN_ENTER", "Digitar");
define("LAN_ENTER_CODE", "Digite o código");
define("LAN_INVALID_CODE", "Código incorreto digitado.");
define("LAN_SEARCH", "Procurar");
define("LAN_SHARE", "Compartilhar");
define("LAN_BACK", "Voltar");
define("LAN_NAME", "Nome");
define("LAN_CANCEL", "Cancelar");
define("LAN_DATE", "Data");
define("LAN_DATE_POSTED", "Data da postagem");
define("LAN_JSCONFIRM", "Tem certeza?");
define("LAN_IP", "Endereço IP");
define("LAN_AUTHOR", "Autor");
define("LAN_CATEGORY", "Categoria");


?>