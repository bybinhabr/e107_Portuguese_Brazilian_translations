<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/lan_links.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Links");
define("LAN_61", "Categorias de Link");
define("LAN_62", "categorias");
define("LAN_63", "categoria");
define("LAN_64", "nesta categoria");
define("LAN_65", "link");
define("LAN_66", "links");
define("LAN_67", "Mostrar Todos os Links");
define("LAN_68", "editar");
define("LAN_69", "apagar");
define("LAN_86", "Categoria:");
define("LAN_88", "Orientações:");
define("LAN_89", "Admin.:");
define("LAN_90", "adicionar novo link nesta categoria");
define("LAN_91", "adicionar nova categoria");
define("LAN_92", "Enviar um link");
define("LAN_93", "Depois de enviado, o link será analisado por um administrador do site, e, se aprovado, será adicionado à página de links.");
define("LAN_94", "Nome para o Link:");
define("LAN_95", "URL do Link:");
define("LAN_96", "Descrição do Link:");
define("LAN_97", "URL para o botão do link:");
define("LAN_98", "Enviar Link");
define("LAN_99", "Obrigado");
define("LAN_100", "O seu link foi gravado e vai ser analisado por um administrador do site.");
define("LAN_101", "Clique aqui para enviar um link");
define("LAN_102", "Há");
define("LAN_103", "é");
define("LAN_104", "são");
define("LAN_105", "total em");
define("LAN_106", "Os campos sublinhados são requeridos.");
define("LAN_Links_1", "Total de links");
define("LAN_Links_2", "Total de links ativos");
define("LAN_LINKS_3", "Anônimos");


?>