<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_updateadmin.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("UDALAN_1", "Erro - por favor repita");
define("UDALAN_2", "Preferências atualizadas");
define("UDALAN_3", "Preferências Atualizadas para");
define("UDALAN_4", "Nome");
define("UDALAN_5", "Senha");
define("UDALAN_6", "Repita a Senha");
define("UDALAN_7", "Mudar a Senha");
define("UDALAN_8", "Senha Atualizada para");


?>