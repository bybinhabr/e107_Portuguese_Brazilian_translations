<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_users.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("USRLAN_1", "Opções Salvas.");
define("USRLAN_3", "listado agora um administrador - Para definir permissões, vá para");
define("USRLAN_4", "Página do administrador");
define("USRLAN_5", "Não se pode remover permissão de administração do administrador principal do site");
define("USRLAN_6", "status de administração foi removido.");
define("USRLAN_7", "Não se pode banir o administrador do site");
define("USRLAN_8", "Usuário banido.");
define("USRLAN_9", "Usuário reintegrado.");
define("USRLAN_10", "Usuário apagado.");
define("USRLAN_11", "Apagamento cancelado.");
define("USRLAN_12", "Não se pode apagar o administrador principal do site.");
define("USRLAN_13", "Confirme eliminação deste membro");
define("USRLAN_16", "Confirme Eliminação");
define("USRLAN_17", "Confirme Eliminação do Usuário");
define("USRLAN_30", "Banir");
define("USRLAN_32", "Ativar");
define("USRLAN_33", "Reintegrar");
define("USRLAN_34", "Remover status de administrador");
define("USRLAN_35", "Tornar administrador");
define("USRLAN_36", "Definir Classe");
define("USRLAN_44", "Permitir que os membros façam upload de avatares?");
define("USRLAN_47", "Comprimento máximo do avatar (em pixels)");
define("USRLAN_48", "valor padrão é 120");
define("USRLAN_49", "Altura máxima do avatar (em pixels)");
define("USRLAN_50", "valor padrão é 100");
define("USRLAN_51", "Atualizar Opções");
define("USRLAN_52", "Opções de Membros");
define("USRLAN_53", "Permitir aos usuários fazer upload de foto?");
define("USRLAN_54", "Clique aqui para apagar os usuários não ativados");
define("USRLAN_55", "Eliminar");
define("USRLAN_56", "Apagado(s)");
define("USRLAN_57", "Apagando os usuários não ativados...");
define("USRLAN_58", "O upload de arquivos está desativado no php.ini");
define("USRLAN_59", "Adicionar usuário rapidamente");
define("USRLAN_60", "Adicionar Usuário");
define("USRLAN_61", "Nome de Usuário");
define("USRLAN_62", "Senha");
define("USRLAN_63", "Confirmar Senha");
define("USRLAN_64", "E-Mail");
define("USRLAN_65", "Esse nome de usuário não pode ser aceito. Por favor, escolha outro nome de usuário diferente");
define("USRLAN_66", "Esse nome de usuário já existe na base de dados. Por favor, escolha um diferente");
define("USRLAN_67", "As duas senhas não conferem");
define("USRLAN_68", "Campo(s) obrigatório(s) deixado(s) em branco");
define("USRLAN_69", "O e-mail não parece ser válido!");
define("USRLAN_78", "Nome de Usuário");
define("USRLAN_79", "Situação");
define("USRLAN_80", "Info");
define("USRLAN_84", "Existem");
define("USRLAN_85", "usuários que não ativaram suas contas - clique abaixo para apagar.");
define("USRLAN_86", "Usuário verificado");
define("USRLAN_87", "Configuração de usuário atualizada");
define("USRLAN_88", "Classes de usuário atualizadas");
define("USRLAN_90", "Procurar Usuários");
define("USRLAN_91", "Classe");
define("USRLAN_92", "Caracteres inválidos no nome de usuário");
define("USRLAN_93", "Apagar usuários não verificados");
define("USRLAN_94", "Apaga registros se não verificados depois desse tempo decorrido - deixar em branco para não usar a opção <br />Esta opção é ignorada se os registros de usuários forem moderados por administrador");
define("USRLAN_95", "minutos");
define("USRLAN_112", "Reenviar E-Mail");
define("USRLAN_113", "Detalhes de registro para");
define("USRLAN_114", "Prezado(a)");
define("USRLAN_115", "Obrigado por ser registrar.");
define("USRLAN_116", "Favor confirmar seu desejo de reenviar um e-mail de confirmação para:");
define("USRLAN_117", "Clique no botão abaixo para testar o seguinte e-mail:");
define("USRLAN_118", "Testar E-Mail");
define("USRLAN_120", "Definir Classes");
define("USRLAN_121", "Enviar Newsletter");
define("USRLAN_122", "Bem Vindo a");
define("USRLAN_123", "Seu registo foi recebido e criado.");
define("USRLAN_124", "Sua conta está setada como inativa, para ativá-la, basta acessar o seguinte link");
define("USRLAN_125", "Para");
define("USRLAN_126", "Permitir que os usuários avaliem outros usuários");
define("USRLAN_127", "Permitir comentários no perfil de usuário");
define("USRLAN_128", "Nome de Usuário (Login)");
define("USRLAN_129", "Nome Real");
define("USRLAN_130", "Permitir rastrear (tracking) usuários online");
define("USRLAN_131", "<u>Você deve habilitar essa opção para usar as opções de rastreamento de usuários online, como online.php, informação online do fórum e menus</u>");
define("USRLAN_132", "Habilitar");
define("USRLAN_133", "Forçar usuários a atualizar as preferências");
define("USRLAN_134", "<u>Ativando essa opcão irá levar o usuário automaticamente à sua página de preferências se o campo requerido não estiver marcado (ou selecionado).</u>");
define("USRLAN_135", "Nenhum endereço IP encontrado nas informações do usuário, não foi possível banir este IP");
define("USRLAN_136", "Múltiplos usuários encontrados com o IP {IP}, não foi possível banir este IP.");
define("USRLAN_137", "Usuários banidos do IP {IP}.");
define("USRLAN_138", "Usuários não verificados");
define("USRLAN_139", "Sua conta foi ativada!.nnVocê deve acessar o {SITEURL} para fazer login usando as informações fornecidas anteriormente.");
define("USRLAN_140", "Re-enviar e-mail para");
define("USRLAN_141", "Falha no reenvio de e-mail para");
define("USRLAN_142", "com o seguinte link de ativação");
define("USRLAN_143", "Checar por Retornos");
define("USRLAN_144", "Re-enviar Confirmação de E-mail para Todos");
define("USRLAN_145", "Usuários que retornaram e-mail");
define("USRLAN_146", "Informação do membro disponível para");
define("USRLAN_147", "Endereço de email já foi usado por um usuário banido");
define("USRLAN_148", "Endereço de email está banido");
define("USRLAN_149", "Deletar emails marcados");
define("USRLAN_150", "Deletar todos os emails");
define("USRLAN_151", "Limpar emails que voltam (bounce), requer Ativação");
define("USRLAN_152", "Limpar emails que voltam (bounce) e Ativar");
define("USRLAN_153", "Deletar emails não entregues");
define("USRLAN_154", "Limpar emails marcados");
define("USRLAN_155", "Um total de {TOTAL} emails foram encontrados. {DELCOUNT} foram apagados nas opções. <br />{DELUSER} usuários marcados como 'devolvedores' (bounced) (em {FOUND} emails).");
define("USRLAN_156", "Endereço de email já está em uso");
define("USRLAN_160", "Total de --COUNT-- usuários do tipo --TYPE-- apagados");
define("USRLAN_161", "ID de Usuário --UID-- nome --NAME-- banido");
define("USRLAN_162", "ID de Usuário --UID-- nome --NAME-- desbanido");
define("USRLAN_163", "ID de Usuário --UID-- deletado");
define("USRLAN_164", "ID de Usuário --UID-- nome --NAME-- (--EMAIL--) se tornou admin");
define("USRLAN_165", "ID de Usuário --UID-- name --NAME-- admin status revoked");
define("USRLAN_166", "ID de Usuário --UID-- nome --NAME-- aprovado");
define("USRLAN_167", "ID de Validação de email --ID-- reenviado para --NAME-- em --EMAIL--");
define("USRLAN_168", "Reenviados --COUNT-- emails de validação");
define("USRLAN_169", "Total de --COUNT-- emails retornando deletados");
define("USRLAN_170", "Randomizar nome de usuário");
define("USRLAN_171", "Randomizar senha");
define("USRLAN_172", "A conta do usuário foi criada com os seguintes dados:");
define("USRLAN_175", "");
define("USRLAN_179", "Usuário banido:");
define("USRLAN_180", "Endereço IP de {IP} está na Lista Branca (whitelist); IP não foi banido.");
define("USRLAN_181", "Escolha opção para status do usuário e envie email de confirmação para o mesmo");
define("USRLAN_182", "Caracteres inválidos no nome de login");
define("USRLAN_183", "Este nome de login já está em uso");
define("USRLAN_184", "Tamanho do nome de login ultrapassa os limites");
define("USRLAN_185", "Uma conta de usuário foi criada para você em {SITEURL} com os seguintes dados de login:<br /><br /><b>Nome de Login:</b> {LOGINNAME}<br /><b>Senha:</b> {PASSWORD}<br/><b>Link de Ativação:</b> {ACTIVATION_LINK}<br /><br />");
define("USRLAN_186", "Favor visitar o site o quanto antes e fazer login, então mude sua senha usando as opções de \'Configurações\'.<br /><br />Você pode também aproveitar e mudar outras configurações.<br /><br />Note que sua senha não poderá ser recuperada caso você a perca.");
define("USRLAN_187", "Acesso ao site:");
define("USRLAN_188", "Email enviado com sucesso");
define("USRLAN_189", "Erro ao enviar email");
define("USRLAN_190", "Período experimental de novo usuário (dias)");
define("USRLAN_191", "Administrador pode impor restrições durante este período em algumas áreas");
define("USRLAN_192", "");
define("USRLAN_193", "Nada modificado - nada salvo");
define("USRLAN_194", "Assinatura pode ser modificada por");
define("USRLAN_195", "");
define("USRLAN_197", "Fonte");
define("USRLAN_198", "Nome do Campo");
define("USRLAN_199", "Operação");
define("USRLAN_200", "Valor");
define("USRLAN_201", "Número de comentários");
define("USRLAN_202", "Número de visitas");
define("USRLAN_203", "Número de dias como membro");
define("USRLAN_204", "Core");
define("USRLAN_206", "Cálculo Atual");
define("USRLAN_207", "Tipo");
define("USRLAN_208", "Nome da Categoria");
define("USRLAN_209", "Inicia com");
define("USRLAN_210", "Prefixo do Idioma");
define("USRLAN_211", "Imagem da Categoria");
define("USRLAN_212", "Categoria do Usuário");
define("USRLAN_214", "Adicionar nova categoria");
define("USRLAN_216", "--selecionar imagem--");
define("USRLAN_219", "Mais antigo que 30 dias");
define("LAN_MAINADMIN", "Admin Principal");
define("LAN_NOTVERIFIED", "Não Verificado");
define("LAN_BANNED", "Banido");
define("LAN_BOUNCED", "Retornado");
define("USRLAN_220", "Todas as Classes de Usuários");
define("USRLAN_221", "Editar permissões de admin");
define("UCSLAN_1", "Enviar email de notificação para");
define("UCSLAN_2", "Atualizar Privilégios");
define("UCSLAN_3", "Prezado(a)");
define("UCSLAN_4", "Seus privilégios foram atualizados em");
define("UCSLAN_5", "Você agora tem acesso à(s) seguinte(s) área(s)");
define("UCSLAN_6", "Configurar classe para usuário");
define("UCSLAN_7", "Configurar classes");
define("UCSLAN_8", "Notificar usuário");
define("UCSLAN_9", "Classes Atualizadas.");
define("UCSLAN_10", "Saudações,");
define("UCSLAN_11", "Classe de usuário para ID de usuário --UID-- mudada para --CLASSES--");
define("UCSLAN_12", "Privilégios de membro apenas");
define("USFLAN_1", "Incapaz de encontrar endereço IP de quem postou - nenhuma informação disponível.");
define("USFLAN_3", "Mensagens postadas do endereço IP");
define("USFLAN_4", "Servidor");
define("USFLAN_5", "Clique aqui para transferir o endereço IP para a página de banimento do admin");
define("USFLAN_6", "ID do usuário");
define("USFLAN_7", "Informação do usuário");
define("USRLAN_AS_1", "Logado como %s");
define("USRLAN_AS_2", "Deslogado da conta %s");
define("USRLAN_AS_3", "Você já está logado com outra conta de usuário. Favor deslogar primeiro.");


?>