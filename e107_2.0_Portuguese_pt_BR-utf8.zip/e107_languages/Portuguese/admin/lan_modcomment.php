<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_modcomment.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("MDCLAN_1", "Moderada.");
define("MDCLAN_2", "Não é permitido comentário para este ítem");
define("MDCLAN_3", "Membro");
define("MDCLAN_4", "Visitante");
define("MDCLAN_5", "desbloquear");
define("MDCLAN_6", "bloquear");
define("MDCLAN_7", "aprovar");
define("MDCLAN_8", "Moderação de Comentários");
define("MDCLAN_9", "Aviso! Deletar comentários da categoria <b>Pai</b> deletará também todas as respostas!");
define("MDCLAN_10", "opções");
define("MDCLAN_11", "comentário");
define("MDCLAN_12", "comentários");
define("MDCLAN_13", "bloqueado");
define("MDCLAN_14", "bloquear comentários");
define("MDCLAN_15", "aberto");
define("MDCLAN_16", "fechado");
define("MDCLAN_17", "Não há comentários pendentes de aprovação");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");


?>