<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_prefs.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PRFLAN_1", "Informação do Site");
define("PRFLAN_2", "Nome do Site");
define("PRFLAN_3", "URL do Site");
define("PRFLAN_4", "Botão de Link do Site");
define("PRFLAN_5", "Tagline do Site");
define("PRFLAN_6", "Descrição do Site");
define("PRFLAN_7", "Administrador principal do site");
define("PRFLAN_8", "E-Mail do administrador");
define("PRFLAN_9", "Observações do Site");
define("PRFLAN_13", "Mostrar Informação");
define("PRFLAN_14", "Mostrar informação do thema?");
define("PRFLAN_15", "Mostrar tempo de execução?");
define("PRFLAN_16", "Mostrar as queries de SQL?");
define("PRFLAN_17", "Compactar os dados do site usando gzip");
define("PRFLAN_19", "Opções de Registro de Página");
define("PRFLAN_21", "Opções de Exibição de Data");
define("PRFLAN_22", "Formato de data curto");
define("PRFLAN_23", "Formato de data longo");
define("PRFLAN_24", "Formato da data no fórum");
define("PRFLAN_25", "Para mais informações sobre formato de data, veja a");
define("PRFLAN_26", "Compensação de hora");
define("PRFLAN_27", "Exemplo: se preencher com +2, todas as horas no site serão somadas de 2 horas");
define("PRFLAN_28", "Registro/Postagem de Usuário");
define("PRFLAN_29", "Ativar o sistema de registro de usuários?");
define("PRFLAN_30", "<u>Permitir aos usuários registrarem-se como membros do site?</u>");
define("PRFLAN_32", "Permitir postagens anônimas?");
define("PRFLAN_33", "<u>Se desmarcado, só os membros do site poderão postar ou comentar.</u>");
define("PRFLAN_35", "Ativar a proteção contra excesso de requisições?");
define("PRFLAN_36", "Tempo de Requisição (Flood)");
define("PRFLAN_37", "Auto Banimento");
define("PRFLAN_38", "Tempo requerido em segundos entre 2 postagens em áreas que os usuários podem postar (chat, fóruns...) se um usuário postar muito rápido, ele será redirecionado para a homepage");
define("PRFLAN_40", "Filtro de vocabulário indecoroso ou ofensivo?");
define("PRFLAN_41", "Se ativado as palavras não permitidas serão substituídas pela(s) indicada(s) abaixo");
define("PRFLAN_42", "Palavra(s) de substituição");
define("PRFLAN_43", "Filtrar palavras");
define("PRFLAN_44", "palavras a censurar, separadas por vírgulas");
define("PRFLAN_45", "Usar a página do COPPA no registro?");
define("PRFLAN_46", "Para mais informações sobre o COPPA veja");
define("PRFLAN_47", "Segurança e Proteção");
define("PRFLAN_48", "Método de rastreamento de usuário");
define("PRFLAN_49", "Cookies");
define("PRFLAN_50", "Sessões");
define("PRFLAN_52", "Gravar Alterações");
define("PRFLAN_53", "Preferências do Site");
define("PRFLAN_55", "Nome do Cookie (se opção de cookies selecionada)");
define("PRFLAN_56", "Fuso Horário");
define("PRFLAN_58", "Restringir o site só para membros");
define("PRFLAN_59", "<u>Se selecionar vai tornar todas as áreas, além da página inicial e de registro, só para membros</u>");
define("PRFLAN_60", "Ativar SSL");
define("PRFLAN_61", "Só ative esse recurso se tiver certeza do que está fazendo!");
define("PRFLAN_76", "Habilita verificação por código de imagem no cadastro.");
define("PRFLAN_77", "Mostra Opções de Administração");
define("PRFLAN_78", "Deixar em branco para desabilitar");
define("PRFLAN_81", "Habilita verificação por código de imagem no LOGIN.");
define("PRFLAN_83", "exemplo");
define("PRFLAN_87", "Comentários");
define("PRFLAN_88", "Permitir comentários aninhados");
define("PRFLAN_89", "Mostrar ícone após novo comentário");
define("PRFLAN_90", "Permita que os postadores editem seus comentários");
define("CUSTSIG_2", "Nome Real:");
define("CUSTSIG_6", "Assinatura:");
define("CUSTSIG_7", "Avatar");
define("CUSTSIG_12", "Ocultar");
define("CUSTSIG_13", "Campos");
define("CUSTSIG_14", "Mostrar");
define("CUSTSIG_15", "Requerido");
define("CUSTSIG_16", "Comprimento mínimo para senhas");
define("CUSTSIG_17", "Subscrever o conteúdo/saída de mensagens");
define("CUSTSIG_18", "Desativar usernames");
define("CUSTSIG_19", "Os usuários que contêm o seguinte texto serão rejeitados, palavras separadas por vírgulas");
define("CUSTSIG_20", "Título customizado do usuário");
define("PRFLAN_91", "Se alguém estiver atacando seu servidor por excesso de requisição, o IP será banido automaticamente!  Melhor se fizer com uma configuração do servidor, se possível!");
define("PRFLAN_92", "Verificação segura do cadastro -- esconder a senha enviada no email?");
define("PRFLAN_93", "página da função do strftime em php.net");
define("PRFLAN_94", "AQUI");
define("PRFLAN_95", "Exibição de informações de plugin:");
define("PRFLAN_96", "Indicará as informações em todas as páginas do admin para cada plugin suportando este tipo de função");
define("PRFLAN_97", "Menu original de 'Plugins info':");
define("PRFLAN_98", "Se não selecionado, cada plugin indicará sua própria informação em um menu individual. Se selecionado, toda a informação será indicada em um menu.");
define("PRFLAN_101", "Texto Traduzido");
define("PRFLAN_102", "Substituir os links");
define("PRFLAN_103", "Ativando esta opção, os links postados serão substituídos por texto inserido na caixa de texto abaixo, os links muito longos serão divididos para evitar problemas no layout do site");
define("PRFLAN_104", "Links substituídos por texto");
define("PRFLAN_105", "O texto para substituir os links com imagem pode ser usado usando tag da imagem <img> com a url da imagem a ser exibida");
define("PRFLAN_106", "Preferências do sistema salvas no banco de dados.");
define("PRFLAN_107", "Links de e-mail substituídos por texto");
define("PRFLAN_108", "O texto para substituir os links de e-mail com imagem pode ser usado usando tag da imagem <img> , com a url da imagem a ser exibida");
define("PRFLAN_109", "Texto principal com palavras muito longas");
define("PRFLAN_110", "As palavras maiores do que o comprimento incorporado, serão envolvidas por muito mais tempo em uma linha nova");
define("PRFLAN_111", "Menu de texto com palavras muito longas");
define("PRFLAN_113", "Não");
define("PRFLAN_116", "Permitir postagem HTML");
define("PRFLAN_117", "Isto permitirá que os usuários postem em código HTML em qualquer lugar do site, selecione depois qual classe de usuário terá esta permissão.");
define("PRFLAN_118", "Use Geshi para o destaque de sintaxe");
define("PRFLAN_119", "Geshi é um destacador aberto de sintaxe multi-idioma, veja [link] para mais informações");
define("PRFLAN_120", "Padrão Geshi de língua de sintaxe");
define("PRFLAN_121", "se nenhuma língua for especificada no bbtag do código, esta língua será usada destacando");
define("PRFLAN_122", "Habilitar o editor WYSIWYG nas áreas de texto");
define("PRFLAN_123", "O editor indicará o que-você-vê-é-o-que-você-começa nas áreas de texto quando disponível. Aplica-se somente a Admins e a usuários que são permitidos postar em HTML.");
define("PRFLAN_124", "Usar o estilo clássico de paginação");
define("PRFLAN_125", "Ativando esta opção, as páginas de notícia seguinte serão visualizadas com numeração 1, 2 3... 21 22 23, em vez de economizar espaço com um menu dropdown.");
define("PRFLAN_126", "Indicar texto na página de registro");
define("PRFLAN_127", "Faça postagem de links clicáveis");
define("PRFLAN_128", "Ativando esta opção, links postados serão convertidos em hyperlinks");
define("PRFLAN_129", "Desativar múltiplos logins");
define("PRFLAN_130", "Ativando esta opção, será impedido que mais de uma pessoa entre com o mesmo usuário/senha (detalhe do login que compartilha)");
define("PRFLAN_133", "A extensão GD é requerida e não foi encontrada");
define("PRFLAN_134", "Redirecione todos os pedidos da URL do site");
define("PRFLAN_135", "Por exemplo, se sua URL do site acima for http://foo.com ajustado, qualquer acesso ao endereço http://www.foo.com será redirecionado novamente a http://foo.com");
define("PRFLAN_136", "Máximo de registros acima permitido no mesmo endereço de IP.");
define("PRFLAN_137", "Mostrar Uso da Memória");
define("PRFLAN_138", "Habilitar a imagem de verificação de segurança(Securit Code) durante a recuperação de senha esquecida.");
define("PRFLAN_139", "Mostrar aviso quando a senha principal do administrador não foi alterada pelo menos em 30 dias");
define("PRFLAN_140", "Mostrar texto depois que o formulário de registro acima foi enviado.");
define("PRFLAN_142", "Somente Flood");
define("PRFLAN_143", "Somente Logins Falhos");
define("PRFLAN_144", "Flood & Logins Falhos");
define("PRFLAN_145", "Links em nova janela");
define("PRFLAN_146", "Selecione aqui para fazer com que todos os links abram em nova janela (isto aplicará o sitewide).");
define("PRFLAN_147", "Modo Desenvolvedor");
define("PRFLAN_148", "Ativar as funções de colaborador. isto é para colaboradores somente. Não use para produção de sites por motivos de segurança.");
define("PRFLAN_149", "Funções Avançadas");
define("PRFLAN_150", "Selecione o método de autenticação do e107");
define("PRFLAN_151", "e107 - Não há métodos alternativos de autenticação instalados");
define("PRFLAN_31", "Usar e-mail de verificação para registro?");
define("PRFLAN_152", "Sem Verificação");
define("PRFLAN_153", "Aprovação do Admin");
define("PRFLAN_154", "Método de verificação de novo usuário");
define("PRFLAN_155", "Nome de exibição e nome de login devem ser diferentes para");
define("PRFLAN_156", "Restaurar todos os nomes de exibição");
define("PRFLAN_157", "Todos os nomes mostrados como 'Visualização de Nome' foram trocados pelo Nome de Login");
define("PRFLAN_158", "Tamanho máximo para o nome de exibição (5...100)");
define("PRFLAN_159", "vendo esta página com");
define("PRFLAN_160", "Marcar servidores remotos quando validar um endereço de e-mail.");
define("PRFLAN_161", "Desabilitar todos os comentários neste site");
define("PRFLAN_162", "Informações de Contato do Site");
define("PRFLAN_163", "ex. Nome da Empresa, Endereço, Telefone, etc.");
define("PRFLAN_164", "Permitir usuários enviarem uma cópia do e-mail de contato para eles mesmos");
define("PRFLAN_165", "Possibilidade de permitir spam, use com precaução");
define("PRFLAN_166", "Mostrar imagens de emoticon no formulário de comentários?");
define("PRFLAN_167", "Fazer a digitação de endereço de e-mail ser opcional");
define("PRFLAN_168", "Contato(s) Pessoal(is) do Site");
define("PRFLAN_169", "Se o grupo escolhido contém mais de uma pessoa, o usuário será questionado para selecionar uma pessoa do grupo.");
define("PRFLAN_172", "Tamanho máximo para o Nome de Login (10...100)");
define("PRFLAN_173", "Verifique no SourceForge por atualizações do e107 a cada... (dias)");
define("PRFLAN_174", "Nome para respostas de emails do site");
define("PRFLAN_175", "Isto irá aparecer no campo 'De' do registro e em outros emails enviados pelo site");
define("PRFLAN_176", "Endereço de email para os emails que partirem do site");
define("PRFLAN_177", "Endereço especificado para respostas de emails a partir deste site.");
define("PRFLAN_178", "Método de transmissão de senha");
define("PRFLAN_179", "(Apenas suportado se usar sessões para rastrear usuários.)");
define("PRFLAN_180", "Texto plano");
define("PRFLAN_181", "CHAP, texto plano");
define("PRFLAN_182", "Apenas CHAP");
define("PRFLAN_183", "CHAP requer JS ativo no navegador do usuário");
define("PRFLAN_184", "Método de login de usuário");
define("PRFLAN_188", "Codificação da Senha");
define("PRFLAN_189", "md5 (legado)");
define("PRFLAN_190", "Esperto");
define("PRFLAN_191", "(md5 é adequado para uma Intranet, e geralmente para outros sites)");
define("PRFLAN_192", "Gerar nomes de login predefinidos randômicos de acordo com um padrão");
define("PRFLAN_193", "Para permitir que os usuários escolham seus nomes de login, deixe em branco");
define("PRFLAN_194", "# alfa[br]. numérico[br]* alfanumérico[br]Outros caracteres usados na digitação.");
define("PRFLAN_196", "Fazer log de todos os acessos em páginas");
define("PRFLAN_197", "Login automático de novo usuário depois de clicar no link de registro");
define("PRFLAN_198", "Se desativado, o usuário terá que fazer login depois do registro");
define("PRFLAN_154a", "Se 'Aprovação do Admin' estiver selecionado, é recomendável que você ative a notificação por email quando o usuário se registrar <a href='.e_ADMIN.'notify.php'>aqui</a>.");
define("PRFLAN_196a", "Diretório de log:");
define("PRFLAN_199", "Mostrar sub-links de admin");
define("PRFLAN_200", "Se ativado, o menu de navegação de admin (se suportado pelo tema atual) irá renderizar sub-links quando necessário (ex.: Notícias - Criar item de notícias).");
define("PRFLAN_201", "Usuário e Senha");
define("PRFLAN_202", "Email e Senha");
define("PRFLAN_203", "Usuário/Email e Senha");
define("PRFLAN_204", "Separar os plugins em seus próprios menus.");
define("PRFLAN_205", "Se ativado, os plugins serão mostrados em seus próprios menus de navegação, similar ao e107 v0.7 e anteriores.");
define("PRFLAN_206", "Exceções de URL para membros apenas");
define("PRFLAN_207", "Modo Membros Apenas será desativado para URLs que se encaixem nos termos na lista. Um por linha.");
define("PRFLAN_208", "Classe de usuário que poderá enviar links por email de itens do site");
define("PRFLAN_209", "Outras Funções");
define("PRFLAN_210", "Comentários/Postagens");
define("PRFLAN_211", "Não há como fazer o endereço de email ser opcional se for obrigatório para validação ou login");
define("PRFLAN_212", "Valor para --FIELD-- muito alto - mude para --VALUE--");
define("PRFLAN_213", "Valor para --FIELD-- muito baixo - mude para --VALUE--");
define("PRFLAN_214", "Logo do Site");
define("PRFLAN_215", "Classes que podem postar < script > e tags similares");
define("PRFLAN_216", "(Requer permissões de postagem HTML também)");
define("PRFLAN_217", "Filtrar conteúdo HTML");
define("PRFLAN_218", "Se [desligado], coloca os usuários sob risco de exploits XSS postados por membros de classes acima (v0.7.24)");
define("PRFLAN_219", "Caracteres não permitidos encontrados no nome do Cookie (apenas caracteres alfanuméricos são permitidos). Nome do Cookie não foi salvo.");
define("PRFLAN_220", "Filtro de Abuso HTML (experimental)");
define("PRFLAN_221", "Bloqueia algumas tags que não combinam para aqueles que têm permissão para postar código HTML");
define("PRFLAN_222", "Moderação de Comentários feita por");
define("PRFLAN_223", "Comentários devem ser aprovados manualmente por um administrador antes de se tornarem visíveis a outros usuários");
define("PRFLAN_224", "Sistema de registro de usuário");


?>