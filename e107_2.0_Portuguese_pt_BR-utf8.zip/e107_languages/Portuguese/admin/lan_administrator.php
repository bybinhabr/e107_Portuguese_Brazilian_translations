<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_administrator.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("ADMSLAN_4", "Continuar");
define("ADMSLAN_6", "é o administrador principal do site e não pode ser apagado.");
define("ADMSLAN_13", "Administradores Existentes");
define("ADMSLAN_16", "Nome do Admin");
define("ADMSLAN_18", "Permissões");
define("ADMSLAN_19", "Alterar as definições do site");
define("ADMSLAN_20", "Alterar os Menus");
define("ADMSLAN_21", "Adicionar administradores do site");
define("ADMSLAN_22", "Moderar usuários/banidos etc");
define("ADMSLAN_23", "Criar/editar páginas customizadas/menus");
define("ADMSLAN_24", "Gerenciar categorias de download");
define("ADMSLAN_25", "Gerenciar arquivos/uploads");
define("ADMSLAN_26", "Visão geral da categoria de notícias");
define("ADMSLAN_27", "Visão geral da categoria de links");
define("ADMSLAN_28", "Colocar o site em manutenção");
define("ADMSLAN_29", "Gerenciar os anúncios(banners)");
define("ADMSLAN_30", "Configurar notícias externas(rss)");
define("ADMSLAN_31", "Configurar emoticons");
define("ADMSLAN_32", "Configurar o conteúdo da página inicial");
define("ADMSLAN_33", "Configurar log/estatísticas");
define("ADMSLAN_34", "Configurar meta tags");
define("ADMSLAN_35", "Configurar arquivos públicos de upload");
define("ADMSLAN_36", "Configurar Opções de Imagem");
define("ADMSLAN_37", "Moderar comentários");
define("ADMSLAN_39", "Postar notícias");
define("ADMSLAN_40", "Postar links");
define("ADMSLAN_41", "Criar/editar menus customizados");
define("ADMSLAN_42", "Postar revisões");
define("ADMSLAN_43", "Configurar URLs");
define("ADMSLAN_44", "Postar downloads");
define("ADMSLAN_45", "Postar enquetes");
define("ADMSLAN_46", "Mensagens de boas-vindas");
define("ADMSLAN_47", "Moderar notícias enviadas");
define("ADMSLAN_52", "Atualizar administrador");
define("ADMSLAN_56", "Administrador do Site");
define("ADMSLAN_58", "Administrador Geral");
define("ADMSLAN_59", "Remover Status de Admin");
define("ADMSLAN_61", "Administrador excluído");
define("ADMSLAN_62", "Gerenciar os Plugins");
define("ADMSLAN_64", "Limpar o sistema de cache");
define("ADMSLAN_65", "Configurar preferências de e-mail e mailout");
define("ADMSLAN_66", "Configurar a busca");
define("ADMSLAN_67", "Verificar os arquivos com o inspetor de arquivos");
define("ADMSLAN_68", "Configurar o e-mail de notificação");
define("ADMSLAN_71", "Clique aqui para mostrar os privilégios");
define("ADMSLAN_72", "ID do Admin: --ID-- nome: --NAME-- novas permissões:");
define("ADMSLAN_73", "ID do Admin: --ID-- nome: --NAME-- ");
define("ADMSLAN_74", "Geral");
define("ADMSLAN_76", "Gerenciar pacotes de idiomas");


?>