<?php
/*
	**** Tradu��o Original
|Brazilian_portuguese Translation, 2004
|Author: Claytom Valle
|E-mail: claytomv@yahoo.com
	**** Revis�o
|Revis�o da Tradu��o para Portugu�s do Brasil 10/2004
|Autor: PHPautH e Colaboradores
|WebSite: http://www.e107brasil.net
*/
define("ARLAN_0", "Artigo adicionado na base de dados.");
define("ARLAN_1", "Ficaram campos em branco.");
define("ARLAN_2", "Artigo atualizado na base de dados.");
define("ARLAN_3", "Categoria principal adicionada na base de dados.");
define("ARLAN_4", "Artigo principal atualizado na base de dados.");
define("ARLAN_5", "Artigo principal apagado.");
define("ARLAN_6", "Clique na caixa para apagar este artigo");
define("ARLAN_7", "Artigos");
define("ARLAN_8", "Sem principais por enquanto");
define("ARLAN_9", "Principais existentes");
define("ARLAN_10", "T�tulo Principal");
define("ARLAN_11", "Sum�rio Principal");
define("ARLAN_12", "Principal");
define("ARLAN_13", "Principais");
define("ARLAN_14", "Sem artigos por enquanto.");
define("ARLAN_15", "Artigos");
define("ARLAN_16", "Sem principal");
define("ARLAN_17", "T�tulo");
define("ARLAN_18", "Subt�tulo");
define("ARLAN_19", "Sum�rio");
define("ARLAN_20", "Artigo");
define("ARLAN_21", "Permitir coment�rios?");
define("ARLAN_22", "Sim");
define("ARLAN_23", "N�o");
define("ARLAN_24", "Adicionar �cones de e-mail/print?");
define("ARLAN_25", "Sim");
define("ARLAN_26", "N�o");
define("ARLAN_27", "Visualizar de novo");
define("ARLAN_28", "Visualizar");
define("ARLAN_29", "Clique a caixa para apagar o artigo");
define("ARLAN_30", "Artigo apagado.");
define("ARLAN_31", "Configurar os emoticons");
define("ARLAN_32", "Configurar o conte�do da p�gina inicial");
define("ARLAN_55", "Vis�vel para");
define("ARLAN_56", "Categoria de artigos gravada");
define("ARLAN_57", "categoria de artigos atualizada");
define("ARLAN_58", "Categoria apagada");
define("ARLAN_59", "Categoria");
define("ARLAN_60", "Op��es");
define("ARLAN_61", "Editar");
define("ARLAN_62", "Apagar");
define("ARLAN_63", "N�o h� categoria de artigos");
define("ARLAN_64", "Categoria de artigos existentes");
define("ARLAN_65", "Nome da categoria");
define("ARLAN_66", "�cone da categoria");
define("ARLAN_67", "Ver imagens");
define("ARLAN_68", "Sum�rio da categoria");
define("ARLAN_69", "Atualizar categoria de artigos");
define("ARLAN_70", "Limpar o formato");
define("ARLAN_71", "Criar categoria de artigos");
define("ARLAN_72", "Artigos existentes");
define("ARLAN_73", "Abrir o editor HTML");
define("ARLAN_74", "Categoria");
define("ARLAN_75", "Nada");
define("ARLAN_76", "Artigo da p�gina principal");
define("ARLAN_77", "Criar novo artigo");
define("ARLAN_78", "Categorias");
define("ARLAN_79", "Op��es dos artigos");
define("ARLAN_80", "Quer mesmo apagar esta categoria?");
define("ARLAN_81", "Quer mesmo apagar este artigo?");
define("ARLAN_82", "Dados do autor");
define("ARLAN_83", "Deixar em branco se escrito por voc�");
define("ARLAN_84", "Nome do autor");
define("ARLAN_85", "E-mail do autor");
define("ARLAN_86", "Permitir o envio de artigos");
define("ARLAN_87", "Permitir aos visitantes o envio de artigos para o site");
define("ARLAN_88", "Submeter classe do artigo");
define("ARLAN_89", "Selecione os usu�rios que podem enviar artigos");
define("ARLAN_90", "Op��es de atualiza��o");
define("ARLAN_91", "Op��es dos artigos");
define("ARLAN_92", "Op��es dos artigos atualizadas");
define("ARLAN_93", "Artigos enviados");
define("ARLAN_94", "N�o h� artigos enviados");
define("ARLAN_95", "N�o foi fornecido o e-mail");
define("ARLAN_96", "Cabe�alho do artigo");
define("ARLAN_97", "Postar");
define("ARLAN_98", "Postar artigo recebido de usu�rio");
define("ARLAN_99", "Artigo recebido de usu�rio gravado na base de dados");
define("ARLAN_100", "Clique aqui para preencher campos de autor");
define("ARLAN_101", "por");


?>