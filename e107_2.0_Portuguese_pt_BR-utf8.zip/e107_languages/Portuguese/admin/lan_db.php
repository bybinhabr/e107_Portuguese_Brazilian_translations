<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_db.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("DBLAN_1", "Definições dos arquivos de sistema salvos na base de dados.");
define("DBLAN_4", "Clique no botão para verificar a validade da base de dados do e107");
define("DBLAN_5", "Verificar a validade da base de dados");
define("DBLAN_6", "Clique no botão para otimizar a base de dados do e107");
define("DBLAN_7", "Otimizar a base de dados SQL");
define("DBLAN_8", "Clique no botão para fazer uma cópia de segurança das definições dos arquivos de sistema");
define("DBLAN_9", "Cópia de segurança dos arquivos de sistema");
define("DBLAN_10", "Utilitários da base de dados");
define("DBLAN_11", "Base de dados MySQL");
define("DBLAN_12", "otimizada");
define("DBLAN_15", "Clique no botão para verificar disponibilidade de atualização do BD");
define("DBLAN_16", "Verificar Atualizações");
define("DBLAN_17", "Nome da Preferência");
define("DBLAN_18", "Valor da Preferência");
define("DBLAN_19", "Clique no botão para abrir o editor de preferências (para usuários avançados apenas)");
define("DBLAN_20", "Editor de Preferências");
define("DBLAN_22", "Plugin: Ver e escanear");
define("DBLAN_23", "Escaneamento Completado");
define("DBLAN_25", "Diretório");
define("DBLAN_26", "Adicionais Incluídos");
define("DBLAN_27", "Instalado");
define("DBLAN_28", "Clique no botão para escanear o diretório de plugins para procurar modificações");
define("DBLAN_29", "Escanear o diretório de plugins");
define("DBLAN_30", "(Se um addon mostrar um erro, fazer verificação para caracteres fora da abertura de PHP/Tag de fechamento)");
define("DBLAN_31", "Passou");
define("DBLAN_32", "Erro");
define("DBLAN_33", "Inacessível");
define("DBLAN_34", "Não checado");
define("DBLAN_35", "Clique no botão para verificar a validade da tabela de usuários");
define("DBLAN_36", "Verificar a tabela de usuários");
define("DBLAN_37", "Escolher tabela(s) para validar");
define("DBLAN_38", "Iniciar Verificação");
define("DBLAN_39", "Validação dos dados gravanos no BD");
define("DBLAN_40", "Validação dos dados:");
define("DBLAN_41", "tabela");
define("DBLAN_42", "ID");
define("DBLAN_43", "remarcar");
define("DBLAN_45", "ID não encontrado!");
define("DBLAN_46", "Tabela não encontrada!");
define("DBLAN_49", "Sem dados na tabela atual, então não há nada a validar");
define("DBLAN_50", "Validação de dados SQL");
define("DBLAN_51", "Executar selecionado");
define("DBLAN_52", "Deletar Duplicados");
define("DBLAN_53", "Favor selecionar uma ação.");
define("DBLAN_54", "Nenhum erro de validação encontrado.");
define("DBLAN_55", "Selecione para escanear o diretório de shortcode ultrapassados para novos shortcodes");
define("DBLAN_56", "Escanear diretórios ultrapassados");
define("DBLAN_57", "Lista de Shortcodes ultrapassados configurada para");
define("DBLAN_58", "Exportar dados do site");
define("DBLAN_59", "Importar dados do site");


?>