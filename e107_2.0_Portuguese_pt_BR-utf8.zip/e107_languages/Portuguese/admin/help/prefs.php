<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = "As preferências permitem a você especificar todas as configurações importantes do seu site, desde o nome e descrição do site até a proteção de flood e filtros de censura a palavras profanas.";
$ns -> tablerender("Preferências - Ajuda", $text);
?>

