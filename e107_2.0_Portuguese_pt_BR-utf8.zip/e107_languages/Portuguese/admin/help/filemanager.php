<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = "Você pode gerenciar os arquivos da pasta /files nesta página. Se você está recebendo uma mensagem de erro sobre permissões quando faz upload/envio, então você deve fazer CHMOD 777 no diretório que você quer fazer envio/upload.";
$ns -> tablerender("Gerenciador de Arquivos", $text);
?>
