<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_plugin.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("EPL_ADLAN_0", "Instalar");
define("EPL_ADLAN_1", "Desinstalar");
define("EPL_ADLAN_2", "Tem certeza que quer desinstalar este plugin?");
define("EPL_ADLAN_3", "Confirme a desinstalação");
define("EPL_ADLAN_4", "Desinstalação cancelada.");
define("EPL_ADLAN_5", "O processo de instalação vai criar novas definições de preferência.");
define("EPL_ADLAN_6", "...clique aqui para iniciar o processo de instalação");
define("EPL_ADLAN_7", "As tabelas da base de dados foram atualizadas com sucesso.");
define("EPL_ADLAN_8", "Preferências criadas com sucesso.");
define("EPL_ADLAN_9", "Os comandos do SQL falharam. Verifique para estar seguro se todas as modificações estão corretas.");
define("EPL_ADLAN_10", "Nome");
define("EPL_ADLAN_11", "Versão");
define("EPL_ADLAN_12", "Autor");
define("EPL_ADLAN_13", "Compatibilidade");
define("EPL_ADLAN_14", "Descrição");
define("EPL_ADLAN_15", "Leia o arquivo README para mais informações");
define("EPL_ADLAN_16", "Informação do Plugin");
define("EPL_ADLAN_17", "Mais informações...");
define("EPL_ADLAN_18", "Impossível criar a(s) tabela(s) com sucesso para este plugin.");
define("EPL_ADLAN_19", "Tabelas criadas com sucesso na base de dados.");
define("EPL_ADLAN_21", "Este plugin já se encontra instalado.");
define("EPL_ADLAN_22", "Instalado");
define("EPL_ADLAN_23", "Não instalado");
define("EPL_ADLAN_24", "Atualização disponível");
define("EPL_ADLAN_25", "Não necessita instalar");
define("EPL_ADLAN_26", "... clique aqui para iniciar o processo de desinstalação");
define("EPL_ADLAN_27", "Impossível apagar com sucesso");
define("EPL_ADLAN_28", "As tabelas na base de dados foram apagadas com sucesso.");
define("EPL_ADLAN_29", "Preferências apagadas com sucesso.");
define("EPL_ADLAN_30", "por favor apague manualmente.");
define("EPL_ADLAN_31", "Por favor, apague agora a pasta");
define("EPL_ADLAN_32", "e todos os arquivos contidos para completar o processo de desinstalação.");
define("EPL_ADLAN_33", "Plugin instalado com sucesso.");
define("EPL_ADLAN_34", "Plugin atualizado com sucesso.");
define("EPL_ADLAN_35", "Definições de depuração adicionadas com sucesso.");
define("EPL_ADLAN_36", "Inserção de código de depuração falhou; formatado incorretamente.");
define("EPL_ADLAN_37", "Upload de Arquivos (Formatos suportados: .zip ou tar.gz)");
define("EPL_ADLAN_38", "Fazer Upload!");
define("EPL_ADLAN_39", "O arquivo não foi enviado para ".e_PLUGIN." pois a pasta não apresenta as permissões corretas - Por favor aplique a permissão CHMOD 777 e faça o re-envio do arquivo.");
define("EPL_ADLAN_40", "Mensagem de Admin");
define("EPL_ADLAN_41", "Este arquivo não apresenta um formato válido .zip ou .tar");
define("EPL_ADLAN_42", "Um erro ocorreu, impossível desarquivar o arquivo");
define("EPL_ADLAN_43", "Este plugin foi enviado e descompactado, por favor selecione abaixo o plugin na lista.");
define("EPL_ADLAN_44", "O auto envio e extração está desativado pois a pasta de plugins não apresenta as permissões corretas - Por favor, aplique a permissão CHMOD 777 na pasta e107_plugins");
define("EPL_ADLAN_45", "Este menu foi enviado e descompactado, para ativar acesse a <a href='".e_ADMIN."menus.php'>Página de configuração de menus</a>.");
define("EPL_ADLAN_46", "Erro na extração PCLZIP:");
define("EPL_ADLAN_47", "Erro na extração PCLTAR:");
define("EPL_ADLAN_48", "código:");
define("EPL_ADLAN_49", "As tabelas não foram apagadas durante a desinstalação solicitada");
define("EPL_WEBSITE", "Website");
define("EPL_NOINSTALL", "Não é necessário instalar, apenas ative a partir dos menus. Para desinstalar, apague o");
define("EPL_DIRECTORY", "diretório.");
define("EPL_NOINSTALL_1", "Não é necessário instalar; para remover, apague o");
define("EPL_UPGRADE", "Atualizar");
define("EPL_ADLAN_50", "Comentários deletados com sucesso");
define("EPL_ADLAN_53", "Diretório sem permissão de escrita");
define("EPL_ADLAN_54", "Por favor selecione a opção para a desinstalação do plugin:");
define("EPL_ADLAN_55", "Desinstalação de Plugins");
define("EPL_ADLAN_57", "Deletar as tabelas dos plugins");
define("EPL_ADLAN_58", "Se as tabelas não forem removidas, o plugin poderá ser reinstalado sem perda de dados. A criação de tabelas durante a reinstalação irá falhar. As tabelas precisarão ser apagadas manualmente para remover.");
define("EPL_ADLAN_59", "Deletar arquivos dos plugins");
define("EPL_ADLAN_60", "O e107 irá remover todos os arquivos relacionados ao plugin.");
define("EPL_ADLAN_62", "Cancelar desinstalação");
define("EPL_ADLAN_63", "Desinstalação:");
define("EPL_ADLAN_64", "Todos os arquivos foram removidos de");
define("EPL_ADLAN_70", "Plugin necessário não instalado:");
define("EPL_ADLAN_71", "Versão mais nova de plugin necessária:");
define("EPL_ADLAN_72", "Versão:");
define("EPL_ADLAN_73", "Extensão de PHP necessária não foi lida:");
define("EPL_ADLAN_74", "Nova versão de PHP necessária:");
define("EPL_ADLAN_75", "Nova versão de MySQL necessária:");
define("EPL_ADLAN_76", "Erro no arquivo plugin.xml");
define("EPL_ADLAN_77", "Arquivo plugin.xml não encontrado");
define("EPL_ADLAN_78", "Deletar Classes de Usuários criado pelo plugin:");
define("EPL_ADLAN_79", "Apenas deletar se você não estiver usando para outros propósitos.");
define("EPL_ADLAN_80", "Deletar campos estendidos de usuários criado pelo plugin:");
define("EPL_ADLAN_81", "Xhtml");
define("EPL_ADLAN_82", "Ícone");
define("EPL_ADLAN_83", "Notas");
define("EPL_ADLAN_84", "Instalar Selecionados");
define("EPL_ADLAN_85", "Desinstalar Selecionados");
define("EPL_ADLAN_86", "Todos os arquivos removidos de");
define("EPL_ADLAN_87", "Deletar Arquivo falhou");
define("LAN_UPGRADE_SUCCESSFUL", "Atualização feita com sucesso");
define("LAN_INSTALL_SUCCESSFUL", "Instalação feita com sucesso");
define("LAN_INSTALL_FAIL", "Instalação falhou");


?>