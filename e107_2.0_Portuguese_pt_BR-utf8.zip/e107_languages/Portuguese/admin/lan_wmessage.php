<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_wmessage.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("WMLAN_00", "Mensagens de Boas Vindas");
define("WMLAN_01", "Criar Nova Mensagem");
define("WMLAN_02", "Mensagem");
define("WMLAN_03", "Visibilidade");
define("WMLAN_04", "Texto da Mensagem");
define("WMLAN_05", "Inclua");
define("WMLAN_06", "<u>Se selecionada, a mensagem será renderizada dentro da caixa</u>");
define("WMLAN_07", "Sistema padrão de ultrapassagem para usar o shortcode {WMESSAGE}:");
define("WMLAN_09", "Nenhuma mensagem de boas vindas foi pré-definida");
define("WMLAN_10", "Subtítulo da mensagem");


?>