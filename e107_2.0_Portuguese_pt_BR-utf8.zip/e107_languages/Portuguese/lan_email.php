<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/lan_email.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) {define("PAGE_NAME", "E-Mail");}
define("LAN_EMAIL_1", "De: ");
define("LAN_EMAIL_2", "Endereço IP de quem enviou: ");
define("LAN_EMAIL_3", "Item enviado de ");
define("LAN_EMAIL_4", "Enviar E-Mail");
define("LAN_EMAIL_5", "Enviar item para um amigo");
define("LAN_EMAIL_6", "Acho que você pode se interessar por este item de");
define("LAN_EMAIL_7", "enviar e-mail para alguém");
define("LAN_EMAIL_8", "Comentar");
define("LAN_EMAIL_9", "Desculpe - não há como enviar e-mail");
define("LAN_EMAIL_10", "E-mail enviado para ");
define("LAN_EMAIL_11", "E-mail enviado");
define("LAN_EMAIL_12", "Erro");
define("LAN_EMAIL_13", "Enviar artigo por e-mail para amigo");
define("LAN_EMAIL_14", "Enviar item de notícia para amigo");
define("LAN_EMAIL_15", "Login: ");
define("LAN_EMAIL_106", "Parece que este endereço de e-mail não é válido");
define("LAN_EMAIL_185", "Enviar Artigo");
define("LAN_EMAIL_186", "Enviar item de Notícia");
define("LAN_EMAIL_187", "Endereço de e-mail para enviar");
define("LAN_EMAIL_188", "Acho que você pode se interessar por esta história de ");
define("LAN_EMAIL_189", "Acho que você pode se interessar por este artigo de ");
define("LAN_EMAIL_190", "Digite o código ");


?>