<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/lan_request.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.net
|        (http://www.e107brasil.net), 2005-2006
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LAN_dl_61", "Erro de Download");
define("LAN_dl_62", "Voc� foi impedido de baixar este arquivo, voc� excedeu sua quota de download");
define("LAN_dl_63", "Voc� n�o tem as permiss�es corretas para baixar este arquivo.");
define("LAN_dl_64", "Voltar");
define("LAN_dl_65", "Arquivo N�o Encontrado");


?>