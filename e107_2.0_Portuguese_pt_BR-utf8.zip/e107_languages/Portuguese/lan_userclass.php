<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/lan_userclass.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("UC_LAN_0", "Todos (público)");
define("UC_LAN_1", "Convidados apenas");
define("UC_LAN_2", "Ninguém (inativo)");
define("UC_LAN_3", "Membros apenas");
define("UC_LAN_4", "Somente leitura");
define("UC_LAN_5", "Admin apenas");
define("UC_LAN_6", "Admin principal");
define("UC_LAN_7", "Moderadores do Fórum");
define("UC_LAN_8", "Admins e Moderadores");
define("UC_LAN_9", "Novos usuários");
define("UC_LAN_10", "Bots (Robôs) de Busca");
define("UC_LAN_INVERT", "Sem --CLASS--");
define("UC_LAN_INVERTLABEL", "Todos menos...");


?>