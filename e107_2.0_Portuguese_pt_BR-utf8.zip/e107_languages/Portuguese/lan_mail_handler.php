<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/lan_mail_handler.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LANMAILH_1", "Produzido pelo sistema de website e107");
define("LANMAILH_2", "Esta é uma mensagem múltiplas-partes no formato do MIME.");
define("LANMAILH_3", " não é formatado corretamente");
define("LANMAILH_4", "Endereço rejeitado pelo servidor");
define("LANMAILH_5", "Nenhuma resposta do servidor");
define("LANMAILH_6", "Não foi possível encontrar o servidor de e-mail.");
define("LANMAILH_7", " parece ser válido.");


?>