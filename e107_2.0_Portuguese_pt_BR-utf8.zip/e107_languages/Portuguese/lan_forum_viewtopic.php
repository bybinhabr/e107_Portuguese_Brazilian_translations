<?php
/*
	**** Tradu��o Original
|Brazilian_portuguese Translation, 2004
|Author: Claytom Valle
|E-mail: claytomv@yahoo.com
	**** Revis�o
|Revis�o da Tradu��o para Portugu�s do Brasil 10/2004
|Autor: PHPautH e Colaboradores
|WebSite: http://www.e107.com.br
*/
define("PAGE_NAME", "F�rum");
define("LAN_01", "F�runs");
define("LAN_02", "Ir para a p�gina");
define("LAN_03", "Ir");
define("LAN_04", "Anterior");
define("LAN_05", "Seguinte");
define("LAN_06", "Aderiu");
define("LAN_07", "Localiza��o");
define("LAN_08", "Website");
define("LAN_09", "Visitas ao site desde o registro");
define("LAN_10", "Voltar ao Topo");
define("LAN_65", "Saltar");
define("LAN_66", "Este tema est� agora encerrado");
define("LAN_67", "Mensagens:");
define("LAN_194", "Visitante");
define("LAN_195", "Membro registrado");
define("LAN_321", "Moderadores: ");
define("LAN_389", "Debate Anterior");
define("LAN_390", "Debate Seguinte");
define("LAN_391", "Seguir este debate");
define("LAN_392", "Parar de seguir este debate");
define("LAN_393", "Resposta R�pida");
define("LAN_394", "Visualiza��o");
define("LAN_395", "Responder ao Debate");
define("LAN_396", "Website");
define("LAN_397", "E-mail");
define("LAN_398", "Perfil");
define("LAN_399", "Mensagem Privada");
define("LAN_400", "Editar");
define("LAN_401", "Citar");
define("LAN_402", "Autor");
define("LAN_403", "Postar");
define("LAN_404", "N�o h� tema anterior");
define("LAN_405", "N�o h� tema seguinte");
define("LAN_406", "Moderador: Editar");
define("LAN_407", "Moderador: Apagar");
define("LAN_408", "Moderador: Mover");
define("LAN_409", "Tem certeza que quer apagar esse debate e todas as respostas?");
define("LAN_410", "Tem certeza que quer apagar essa resposta?");
define("LAN_411", "postado por ");
define("LAN_412", "T�tulo");
define("LAN_413", "Relat�rio");
define("LAN_414", "Relatar esse debate para um moderador");
define("LAN_415", "T�tulo do debate");
define("LAN_416", "Informe seu relat�rio");
define("LAN_417", "O administrador saber� sobre esse debate. Voc� pode afixar uma explica��o da mensagem que voc� achou ser desagrad�vel.");
define("LAN_418", "<b>N�O</b> use esse formul�rio para contatar o administrador por qualquer outra raz�o.");
define("LAN_419", "Enviar Relat�rio");
define("LAN_420", "Clique para ver a postagem");
define("LAN_421", "Debate de F�rum relatado de");
define("LAN_422", "Essa postagem foi relatada do site ");
define("LAN_423", "Mensagem n�o pode ser enviada ");
define("LAN_424", "Postagem foi relatada para o moderador.<br />Obrigado.");
define("LAN_425", "Mensagem de: ");
define("LAN_426", "Relatando postagem no t�pico: ");
define("LAN_427", "Erro enviando e-mail");
define("LAN_428", "Postagem foi relatada");
define("LAN_429", "Clique aqui para voltar para o f�rum");
define("LAN_430", "Enquete");
define("FORLAN_26", "R�plica deletada");


?>