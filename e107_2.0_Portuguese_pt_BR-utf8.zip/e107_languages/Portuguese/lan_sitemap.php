<?php
/*
	**** Tradu��o Original
|Brazilian_portuguese Translation, 2004
|Author: Claytom Valle
|E-mail: claytomv@yahoo.com
	**** Revis�o
|Revis�o da Tradu��o para Portugu�s do Brasil 10/2004
|Autor: PHPautH e Colaboradores
|WebSite: http://www.e107.com.br
*/
define("PAGE_NAME", "Mapa do Site");
define("LANSM_1", "Mapa do Site de");
define("LANSM_2", "In�cio");
define("LANSM_3", "(P�gina Inicial)");
define("LANSM_4", "Conte�do");
define("LANSM_5", "Not�cias");
define("LANSM_6", "(Categorias de not�cias)");
define("LANSM_7", "CLique aqui para mostrar/esconder o mapa do site por completo");
define("LANSM_8", "Links");
define("LANSM_9", "(Categoria de links)");
define("LANSM_10", "F�runs");
define("LANSM_11", "(Lista de F�runs)");
define("LANSM_12", "Downloads");
define("LANSM_13", "(Categorias de downloads)");
define("LANSM_14", "Artigos");
define("LANSM_15", "(Categoria de artigos)");
define("LANSM_16", "Resenha");
define("LANSM_17", "(Categorias de resenhas)");
define("LANSM_18", "P�gina de rosto");
define("LANSM_19", "Membros");
define("LANSM_20", "Status");
define("LANSM_21", "Op��es de Usu�rio");
define("LANSM_22", "Informa��es pessoais");
define("LANSM_23", "Categorias:");
define("LANSM_24", "Aspectos principais");
define("LANSM_25", "Plugins");
define("LANSM_26", "Mensagens na Chatbox");
define("LANSM_27", "T�tulos");
define("LANSM_28", "Pesquisas antigas");
define("LANSM_29", "Conte�do");
define("LANSM_30", "(Lista de p�ginas de conte�do)");
define("LANSM_31", "ou clique em");
define("LANSM_32", "Lista de usu�rios registrados");
define("LANSM_33", "(Estat�sticas deste site)");
define("LANSM_34", "(Informa��es sobre um membro)");
define("LANSM_35", "(Arranjo de informa��es de membro)");
define("LANSM_36", "(Outras p�ginas de conte�do)");
define("LANSM_37", "Subcategorias:");
define("LANSM_38", "P�ginas");
define("LANSM_39", "(cadeia/respostas");
define("LANSM_40", "N�o categorizado");
define("LANSM_41", "expandir/esconder uma subcategoria");
define("LANSM_42", "Chat");
define("LANSM_43", "(Todas mensagens postadas no menu chatbox)");
define("LANSM_44", "Outras p�ginas");
define("LANSM_45", "Entrar");
define("LANSM_46", "Esqueceu suas senha?");
define("LANSM_47", "Busca");
define("LANSM_48", "Publicar not�cia");
define("LANSM_49", "Publicar conte�do");
define("LANSM_50", "Top posters");
define("LANSM_51", "Publicar links");
define("LANSM_52", "Posts de usu�rios");
define("LANSM_53", "(Checar coment�rios de usu�rios espec�ficos no site)");


?>