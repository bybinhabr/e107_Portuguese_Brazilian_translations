<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
setlocale(LC_ALL,'portuguese');
define("CORE_LC", "pt-br");
define("CORE_LC2", "br");
define("CHARSET", "iso 8859-1");
define("CORE_LAN1", "Erro: Faltando arquivos do tema. <b>Mude o tema usado em suas prefer�ncias (�rea de administra��o) ou fa�a upload dos arquivos do tema atual.</b>");
define("CORE_LAN4", "Por favor, apague o arquivo install.php do seu servidor");
define("CORE_LAN5", "pois ele pode ser potencialmente perigoso para seu website");
define("CORE_LAN6", "A prote��o de flood foi ativada neste site e voc� est� sendo avisado que poder� ser banido caso continue a solicitar p�ginas com muita frequ�ncia.");
define("CORE_LAN7", "O sistema est� tentando restaurar as prefer�ncias de um backup autom�tico.");
define("CORE_LAN8", "Erro nas Prefer�ncias do Sistema");
define("CORE_LAN9", "Execu��o falhou. O sistema n�o pode se restaurar de um backup autom�tico.");
define("CORE_LAN10", "Cookie corrompido detectado - fa�a login novamente.");
define("CORE_LAN11", "Tempo de renderiza��o: ");
define("CORE_LAN12", " segundos, ");
define("CORE_LAN13", " para conte�dos. ");
define("CORE_LAN14", "");
define("CORE_LAN15", "Conte�dos no BD: ");
define("CORE_LAN16", "Uso de Mem�ria: ");
define("CORE_LAN17", "[ imagem desativada ]");
define("CORE_LAN18", "Imagem: ");
define("CORE_LAN_B", "b");
define("CORE_LAN_KB", "kb");
define("CORE_LAN_MB", "Mb");
define("CORE_LAN_GB", "Gb");
define("CORE_LAN_TB", "Tb");
define("LAN_WARNING", "Aten��o!");
define("LAN_ERROR", "Erro");
define("LAN_ANONYMOUS", "An�nimo");
define("LAN_EMAIL_SUBS", "-email-");
define("LAN_SANITISED", "SANITIZADO");


?>