<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_themes/leaf/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LAN_THEME_1", "Coment�rio(s)");
define("LAN_THEME_2", "Os coment�rios est�o desativados para este item");
define("LAN_THEME_3", "Coment�rio(s)");
define("LAN_THEME_4", ">>Leia Mais!<<");
define("LAN_THEME_5", "TrackBacks:");
define("LAN_THEME_6", "Comentado por");
define("LAN_THEME_7", "Not�cias");


?>
