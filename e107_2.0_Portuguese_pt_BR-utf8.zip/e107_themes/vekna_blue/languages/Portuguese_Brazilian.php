<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_themes/vekna_blue/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2008
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LAN_THEME_1", "Vekna Blue desenvolvido por <a href='http://e107.org' rel='external'>jalist</a>, permitido e baseado no thema do Arach's site, <a href='http://e107.vekna.com' rel='external'>http://e107.vekna.com</a>");
define("LAN_THEME_2", "Ler/Postar Coment�rios:");
define("LAN_THEME_3", "Os coment�rios est�o desativados para este item");
define("LAN_THEME_4", ">>Leia Mais!<<");
define("LAN_THEME_5", "TrackBacks:");

?>
