<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_themes/jayya/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LAN_THEME_1", "Os comentários estão desativados para este item");
define("LAN_THEME_2", "Ler/Postar Comentários:");
define("LAN_THEME_3", ">> Leia Mais!");
define("LAN_THEME_4", "TrackBacks:");
define("LAN_THEME_5", "Postado por");
define("LAN_THEME_6", "no(a)");


?>