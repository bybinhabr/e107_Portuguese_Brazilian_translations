<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/bootstrap/languages/Portuguese.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/14 15:47:52 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "Comentários desativados para este item");
define("LAN_THEME_2", "Ler/Postar Comentários:");
define("LAN_THEME_3", "Leia mais...");
define("LAN_THEME_4", "Trackbacks:");
define("LAN_THEME_5", "Postado por");
define("LAN_THEME_6", "em");


?>