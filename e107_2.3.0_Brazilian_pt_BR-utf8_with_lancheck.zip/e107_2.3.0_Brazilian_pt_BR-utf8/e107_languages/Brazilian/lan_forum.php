<?php
/*
	**** Tradu��o Original
|Brazilian_portuguese Translation, 2004
|Author: Claytom Valle
|E-mail: claytomv@yahoo.com
	**** Revis�o
|Revis�o da Tradu��o para Portugu�s do Brasil 10/2004
|Autor: PHPautH e Colaboradores
|WebSite: http://www.e107.com.br
*/
define("PAGE_NAME", "F�rum");
define("LAN_30", "Bem-vindo(a)");
define("LAN_31", "N�o h� novas postagens ");
define("LAN_32", "H� 1 nova mensagem ");
define("LAN_33", "H� ");
define("LAN_34", "novas mensagens ");
define("LAN_35", "desde a sua �ltima visita.");
define("LAN_36", "A sua �ltima visita foi em ");
define("LAN_37", "Agora � ");
define("LAN_38", ", todas a horas s�o ");
define("LAN_41", "Membro mais recente: ");
define("LAN_42", "Membros registrados: ");
define("LAN_44", "Estes f�runs podem ser pesquisados e postados por usu�rios n�o registrados, o endere�o IP e o ISP ser�o registrados devidamente. Se desejar,");
define("LAN_45", "Estes f�runs s� podem ser postados por usu�rios registrados como membros.");
define("LAN_46", "F�rum");
define("LAN_47", "Debates");
define("LAN_48", "Respostas");
define("LAN_49", "�ltima Postagem");
define("LAN_51", "N�o h� f�runs ainda. Por favor, volte mais tarde.");
define("LAN_52", "N�o h� f�runs nesta se��o ainda. Por favor, volte mais tarde.");
define("LAN_79", "Novas postagens");
define("LAN_80", "N�o h� novas postagens");
define("LAN_81", "Debate encerrado");
define("LAN_100", "Artigos");
define("LAN_180", "Procurar");
define("LAN_191", "Informa��o");
define("LAN_192", "Os usu�rios postaram um total de ");
define("LAN_196", "Voc� leu ");
define("LAN_197", " dessas mensagens.");
define("LAN_198", " Todas as mensagens foram lidas.");
define("LAN_199", "Marcar todas as postagens como lidas");
define("LAN_204", "Voc� <b>pode</b> iniciar novo debates");
define("LAN_205", "Voc� <b>n�o pode</b> iniciar novos debates");
define("LAN_206", "Voc� <b>pode</b> responder a mensagens");
define("LAN_207", "Voc� <b>n�o pode</b> responder a mensagens");
define("LAN_208", "Voc� <b>pode</b> editar suas mensagens");
define("LAN_209", "Voc� <b>n�o pode</b> editar suas mensagens");
define("LAN_392", "Parar de seguir este debate");
define("LAN_393", "Listar todos os debates seguidos");
define("LAN_394", "F�rum fechado");
define("LAN_397", "Debates seguidos");
define("LAN_398", "Fechado");
define("LAN_399", "Restrito");
define("LAN_400", "Este f�rum s� pode ser pesquisado por usu�rios registrados");
define("LAN_401", "S� para Membros");
define("LAN_402", "Este f�rum � s� de leitura");
define("LAN_403", "Sem Mensagens");
define("LAN_404", "Mensagens");
define("LAN_405", "S� de leitura");
define("LAN_406", "Este f�rum � restrito a administradores");
define("LAN_407", "Este f�rum � restrito a membros");
define("LAN_408", "Este f�rum � s� de leitura");
define("LAN_409", "Este f�rum � de uma classe restrita");
define("LAN_410", "Bem-vindo, visitante");
define("LAN_411", "Debate");
define("LAN_412", "Resposta");
define("LAN_413", "Debates");
define("LAN_414", "Respostas");
define("LAN_415", "Usu�rio vendo os f�runs neste momento");
define("LAN_416", "Usu�rios vendo os f�runs neste momento");
define("LAN_417", "Membro");
define("LAN_418", "Visitante");
define("LAN_419", "Membros");
define("LAN_420", "Visitantes");
define("LAN_421", "Mostrar novas postagens");
define("LAN_422", "Novas postagens desde a sua �ltima visita");
define("LAN_423", "Postado por");
define("LAN_424", "Novos temas");
define("LAN_425", "Res:");
define("LAN_426", "Quem est� online: ");
define("LAN_427", "Ver lista detalhada.");
define("LAN_428", "Res:");
define("LAN_429", "Membros Mais Ativos");
define("LAN_430", "Debates Mais Ativos");
define("LAN_431", "Minhas Postagens");
define("LAN_432", "Minhas Configura��es");
define("LAN_433", "Regras do F�rum");
define("LAN_434", "Voltar para os f�runs");
define("LAN_435", "Meu Perfil");
define("LAN_436", " (Abrir� uma nova janela.)");
define("LAN_437", "registre-se");
define("LAN_438", "ou logue-se.");
define("LAN_439", "Clique AQUI");
define("LAN_440", "para se registrar!.");


?>