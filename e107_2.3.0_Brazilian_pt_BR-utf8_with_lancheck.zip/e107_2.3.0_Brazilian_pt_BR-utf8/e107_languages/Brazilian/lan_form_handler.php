<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Brazilian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/11/08 11:46:15
|
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_EFORM_001", "Clique no avatar para mudá-lo");
define("LAN_EFORM_002", "Escolha o Avatar");
define("LAN_EFORM_003", "OU");
define("LAN_EFORM_004", "Escolher este avatar");
define("LAN_EFORM_005", "Sem avatares disponíveis");
define("LAN_EFORM_006", "Aviso apenas: [br] na pasta [b] [x] [/ b] está vazio. [br] Fazer upload de algumas imagens de avatares padrão para esta pasta para que os usuários escolher avatares de.");
define("LAN_EFORM_007", "Gerenciador de Arquivos de Mídia");
define("LAN_EFORM_008", "Selecionar colunas para exibir");
define("LAN_EFORM_009", "Exibir colunas");
define("LAN_EFORM_010", "Visualização rápida");
define("LAN_EFORM_011", "Vá para o perfil de usuário");
define("LAN_EFORM_012", "Campo multi-língua");
define("LAN_EFORM_013", "ir para a lista");
define("LAN_EFORM_014", "Crie outro");
define("LAN_EFORM_015", "edição atual");
define("LAN_EFORM_016", "Depois de apresentar:");
