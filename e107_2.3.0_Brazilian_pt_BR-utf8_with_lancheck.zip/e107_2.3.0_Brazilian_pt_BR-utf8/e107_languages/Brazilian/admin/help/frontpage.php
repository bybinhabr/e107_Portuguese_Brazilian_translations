<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$caption = "Página Inicial";
$text = "Nesta tela você pode escolher o que mostrar na primeira página do seu site, o padrão é mostrar notícias.  Você pode usar esta página, também, para configurar uma 'splashscreen', uma página que será mostrada apenas quando o visitante entrar pela primeira vez no seu site.";
$ns -> tablerender($caption, $text);
?>
