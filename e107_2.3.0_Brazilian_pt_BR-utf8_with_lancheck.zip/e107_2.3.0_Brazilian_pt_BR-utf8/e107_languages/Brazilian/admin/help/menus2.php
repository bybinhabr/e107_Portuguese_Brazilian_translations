<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$caption = "Menus";
$text .= "Você pode arrumar onde e em que ordem os itens de menu serão mostrados aqui. Use as setas para mover os menus para cima e para baixo até que você esteja satisfeito com suas posições.<br />
Os itens de menus no meio da tela estão desativados, você pode ativá-los selecionando um local para eles.
";

$ns -> tablerender("Menus", $text);
?>
