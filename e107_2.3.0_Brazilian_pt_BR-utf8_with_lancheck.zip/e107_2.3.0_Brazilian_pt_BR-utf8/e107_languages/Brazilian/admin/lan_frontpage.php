<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_frontpage.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("FRTLAN_13", "Preferências da Página Inicial");
// define("FRTLAN_15", "Outra (insira a url):");
define("FRTLAN_30", "Página Customizada");
define("FRTLAN_35", "Página após o login");
define("FRTLAN_42", "Adicionar nova regra");
define("FRTLAN_43", "Classe");
define("FRTLAN_46", "Editar regra existente");
// define("FRTLAN_47", "Mover para cima");
// define("FRTLAN_48", "Mover para baixo");
define("FRTLAN_49", "Página Inicial");
// define("FRTLAN_50", "(Para desativar, selecione &quot;Outra&quot; com uma URL em branco)");
define("FRTLAN_51", "Outra");
// define("FRTLAN_53", "Classe de Usuário");
define("FRTLAN_PAGE_TITLE", "Página Inicial");


define("FRTLAN_56", "duplicar definição para a classe:");
define("FRTLAN_57", "Erro de software");
define("FRTLAN_61", "Seleção");
