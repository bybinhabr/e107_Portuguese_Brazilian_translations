<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_footer.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("FOOTLAN_1", "Site e107");
define("FOOTLAN_2", "Admin Principal");
define("FOOTLAN_3", "Versão");
define("FOOTLAN_4", "Rev.");
define("FOOTLAN_5", "Thema");
define("FOOTLAN_6", "Por");
define("FOOTLAN_7", "Informações");
define("FOOTLAN_8", "Data de Instalação");
define("FOOTLAN_9", "Servidor");
define("FOOTLAN_10", "Hospedeiro/Host");
define("FOOTLAN_11", "Versão de PHP");
define("FOOTLAN_12", "Versão de MySQL");
define("FOOTLAN_13", "Informação do Site");
define("FOOTLAN_14", "Ver Documentos");
define("FOOTLAN_15", "Documentação");
define("FOOTLAN_16", "Base de dados");
define("FOOTLAN_17", "Codificação dos caracteres");
define("FOOTLAN_18", "Thema do Site");
define("FOOTLAN_19", "Hora Atual do Servidor");
define("FOOTLAN_20", "Nível de segurança");
