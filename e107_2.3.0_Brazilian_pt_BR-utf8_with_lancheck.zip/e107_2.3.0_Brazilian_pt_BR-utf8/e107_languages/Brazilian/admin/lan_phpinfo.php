<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Brazilian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2020/12/30 13:39:52
|
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("PHP_LAN_1", "Se você tiver Curl habilitado, você deve considerar desabilitar esse recurso.");
define("PHP_LAN_2", "Este é um risco de segurança e não é necessário por e107.");
define("PHP_LAN_3", "Em um servidor de produção, é melhor desativar a exibição de erros no navegador.");
define("PHP_LAN_4", "Desabilitar este irá esconder a sua versão do PHP de navegadores.");
define("PHP_LAN_5", "Este é um risco de segurança e deve ser desativado.");
define("PHP_LAN_6", "[b]session.save_path[/b] não é gravável. Isso pode causar problemas com seu site.");
define("PHP_LAN_7", "Problema(s) de configuração de PHP encontrados:");
define("PHP_LAN_8", "[x] está faltando e precisa ser instalado.");
