<?php
/*
	**** Tradu��o Original
|Brazilian_portuguese Translation, 2004
|Author: Claytom Valle
|E-mail: claytomv@yahoo.com
	**** Revis�o
|Revis�o da Tradu��o para Portugu�s do Brasil 10/2004
|Autor: PHPautH e Colaboradores
|WebSite: http://www.e107.com.br
*/
define("TPVLAN_1", "Esta � uma p�gina de teste de Tema");
define("TPVLAN_2", "Este tema � ativado apenas para esta p�gina. Os Links abaixo n�o v�o funcionar.");
define("TPVLAN_3", "Prefer�ncias");
define("TPVLAN_4", "Visualizar mais Temas");
define("TPVLAN_5", "Visualizar os Temas do site");
define("TPVLAN_6", "Visualizar");
define("TPVLAN_7", "Visualizar o Tema");
define("TPVLAN_8", "Este tema � ativado somente para esta p�gina. Os Links abaixo n�o funcionar�o.");
define("TPVLAN_9", "Visualizar mais Temas");
define("TPVLAN_10", "Clique no bot�o Submit para definir como Tema do site. ");
define("TPVLAN_11", "informa��o");
define("TPVLAN_12", "Prefer�ncias do Tema gravadas.");
define("TPVLAN_13", "Tema");
define("TPVLAN_15", "Salvar");
define("TPVLAN_14", "Se um tema n�o aparecer corretamente, certifique-se de que ele foi enviado com as permiss�es certas para o servidor. Permiss�o de leitura.");


?>