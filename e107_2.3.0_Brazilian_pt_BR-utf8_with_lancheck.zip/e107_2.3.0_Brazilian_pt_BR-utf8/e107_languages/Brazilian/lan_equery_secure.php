<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/lan_equery_secure.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("EQSEC_LAN1", "Você está sendo redirecionado para uma função do admin, modificações possíveis da base de dados poderão ocorrer");
define("EQSEC_LAN2", "Por favor confirme esta ação:");
define("EQSEC_LAN3", "Nenhuma referência");
define("EQSEC_LAN4", "Ação de:");
define("EQSEC_LAN5", "Ação para:");
define("EQSEC_LAN6", "Confirme ação");
define("EQSEC_LAN7", "ou cancele");


?>