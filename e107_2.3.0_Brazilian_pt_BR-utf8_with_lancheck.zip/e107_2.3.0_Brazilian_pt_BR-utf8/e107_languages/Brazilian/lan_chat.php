<?php
/*
	**** Tradu��o Original
|Brazilian_portuguese Translation, 2004
|Author: Claytom Valle
|E-mail: claytomv@yahoo.com
	**** Revis�o
|Revis�o da Tradu��o para Portugu�s do Brasil 10/2004
|Autor: PHPautH e Colaboradores
|WebSite: http://www.e107.com.br
*/
define("PAGE_NAME", "Janela de Chat");
define("LAN_11", "��rea de Chat (todas as postagens)");
define("LAN_12", "Postagens de Chat");
define("LAN_13", "em");
define("LAN_14", "Erro!");
define("LAN_15", "Voc� n�o tem permiss�es corretas para ver esta p�gina.");
define("LAN_16", "[esta postagem foi bloqueada pelo administrador]");


?>