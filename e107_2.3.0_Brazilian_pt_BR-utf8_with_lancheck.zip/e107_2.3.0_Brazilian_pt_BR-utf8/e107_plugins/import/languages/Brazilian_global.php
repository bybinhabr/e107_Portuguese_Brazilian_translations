<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/import/languages/Portuguese_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/21 21:24:46 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_IMPORT_NAME", "Importar para o e107");
define("LAN_PLUGIN_IMPORT_DESCRIPTION", "Importar dados do  Wordpress, Joomla, Drupal, Blogpost, RSS e outros formatos.");


?>