<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Brazilian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/11/08 20:41:13
|
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("XMLRPC_ADMIN_001", "Menu principal");
define("XMLRPC_CONFIG_001", "MetaWeblog :: configuração");
define("XMLRPC_PREFS_001", "eXMLRPC - opções");
define("XMLRPC_PREFS_002", "cliente eXMLRPC");
define("XMLRPC_PREFS_003", "Tipo de render notícias (0,1,2,3)");
define("XMLRPC_PREFS_004", "Upload de diretório (e_FILE /)");
define("XMLRPC_PREFS_005", "ID do Blog para cliente");
define("XMLRPC_PREFS_006", "Nome do blog para o cliente");
define("XMLRPC_HELP_001", "Instruções");
define("XMLRPC_HELP_010", "Geral");
define("XMLRPC_HELP_011", "Este plugin em si não faz nada! É só para as configurações de alguns variáveis XMLRPC. Aponte seu cliente XMLRPC (por exemplo: Windows Live Writer) para <strong>'. SITEURL'. metaweblog.php</strong> e preencha os valores solicitados. Aviso! Este plugin é experimental!");
define("XMLRPC_HELP_020", "Título de plugin");
define("XMLRPC_HELP_021", "Não importa o plugin não dá saída");
define("XMLRPC_HELP_030", "Tipo de render notícias");
define("XMLRPC_HELP_031", "Importante! Tipo de render padrão notícias");
define("XMLRPC_HELP_040", "Carregar a pasta de arquivos");
define("XMLRPC_HELP_041", "É sempre uma pasta dentro de e107_files!");
define("XMLRPC_HELP_050", "Blog ID de cliente");
define("XMLRPC_HELP_051", "Blog Id para cliente XMLRPC (qualquer string que você quer)");
define("XMLRPC_HELP_060", "Nome do blog para o cliente");
define("XMLRPC_HELP_061", "Nome do blog para cliente XMLRPC (qualquer string que você quiser)");
