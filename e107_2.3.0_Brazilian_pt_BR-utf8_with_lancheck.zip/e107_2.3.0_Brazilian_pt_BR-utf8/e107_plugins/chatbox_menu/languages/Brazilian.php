<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|
|	(c)Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
|
|	Portuguese (Brazilian) translation by Claytom Valle
|	(claytomv@yahoo.com), 2004
+---------------------------------------------------------------+
*/
define("CHATBOX_L1", "Imposs�vel aceitar postagem com este nome de usu�rio. Se � seu, favor registrar ou logar.");
define("CHATBOX_L2", "Janela de chat");
define("CHATBOX_L3", "Voc� precisa entrar seu nome e senha para postar coment�rios neste site - favor faz�-lo. Se voc� ainda n�o � registrado, <a href='".e_BASE."signup.php'>clique aqui</a> para assinar");
define("CHATBOX_L4", "Enviar");
define("CHATBOX_L5", "Limpar");
define("CHATBOX_L6", "[bloqueado pela administra��o]");
define("CHATBOX_L7", "Desbloquear");
define("CHATBOX_L8", "Info");
define("CHATBOX_L9", "Bloquear");
define("CHATBOX_L10", "Apagar");
define("CHATBOX_L11", "Sem mensagens Ainda.");
define("CHATBOX_L12", "Ver todas as postagens");
define("CHATBOX_L13", "moderar janela de chat");
define("CHATBOX_L14", "Smilies");
define("CHATBOX_L15", "Postagem muito longa ou vazia");
define("CHATBOX_L16", "An�nimo");
define("CHATBOX_L17", "Duplicar postagem");


?>