<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/chatbox_menu/languages/Portuguese/Portuguese_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/21 21:24:07 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_CHATBOX_MENU_NAME", "Chat");
define("LAN_PLUGIN_CHATBOX_MENU_DESCRIPTION", "Menu do Chat");
define("LAN_PLUGIN_CHATBOX_MENU_POSTS", "Postagens do Chat");
define("LAN_AL_CHBLAN_01", "Configurações do Chat atualizadas");
define("LAN_AL_CHBLAN_02", "Chat limpo");
define("LAN_AL_CHBLAN_03", "Postagens no chat recalculadas");
define("LAN_AL_CHBLAN_04", "");
define("LAN_AL_CHBLAN_05", "");
define("NT_LAN_CB_1", "Eventos no chat");
define("NT_LAN_CB_2", "Mensagens postadas");
define("NT_LAN_CB_3", "Postado por");
define("NT_LAN_CB_5", "Mensagem");
define("NT_LAN_CB_6", "Mensagem do chat postada");


?>