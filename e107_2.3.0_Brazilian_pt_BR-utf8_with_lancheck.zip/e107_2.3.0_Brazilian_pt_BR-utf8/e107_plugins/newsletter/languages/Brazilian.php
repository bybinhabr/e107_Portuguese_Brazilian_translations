<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/newsletter/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("NLLAN_MENU_CAPTION", "Newsletter - Boletim");
define("NLLAN_48", "você é assinante deste boletim de notícias - se deseja encerrar a assinatura, por favor clique no botão abaixo.");
define("NLLAN_49", "Tem certeza de que deseja cancelar a assinatura deste boletim de notícias?");
define("NLLAN_50", "Clique no botão para assinar ( o endereço da assinatura é");
define("NLLAN_51", "Cancelar Assinatura");
define("NLLAN_52", "Assinar");
define("NLLAN_53", "Tem a certeza de que deseja assinar esta newsletter?");
define("NLLAN_67", "Visão geral do Arquivo");
define("NLLAN_68", "Parâmetro inválido definido");
define("NLLAN_69", "Nenhuma newsletter enviada disponível.");
define("NLLAN_70", "A newsletter selecionada não existe");
// define("NLLAN_71", "Voltar");
define("NLLAN_72", "Ver arquivo");


define("NLLAN_73", "Digite seu E-mail");

