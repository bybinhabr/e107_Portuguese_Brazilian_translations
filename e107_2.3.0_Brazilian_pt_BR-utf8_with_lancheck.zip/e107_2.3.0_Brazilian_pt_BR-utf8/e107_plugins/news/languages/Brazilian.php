<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/news/languages/Portuguese.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/21 21:55:46 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("TD_MENU_L1", "Outras Notícias");
define("TD_MENU_L2", "Outras Notícias");
define("LAN_NEWSCAT_MENU_TITLE", "Categorias de Notícias");
define("LAN_NEWSLATEST_MENU_TITLE", "Últimas Notícias");


?>define("LAN_NEWSARCHIVE_MENU_TITLE", "Arquivo de notícias");
define("LAN_NEWSARCHIVE_MENU_TITLE", "Arquivo de notícias");
