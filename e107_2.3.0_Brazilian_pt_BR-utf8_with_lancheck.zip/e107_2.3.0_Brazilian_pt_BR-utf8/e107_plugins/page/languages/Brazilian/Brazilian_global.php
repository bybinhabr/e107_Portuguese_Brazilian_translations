<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Brazilian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2020/12/30 16:18:37
|
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_PAGE_BOCHAP", "Pesquisar no livro/capítulo");
define("LAN_PLUGIN_PAGE_NAME", "Páginas");
