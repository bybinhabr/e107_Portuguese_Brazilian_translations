<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/poll/languages/Portuguese_admin_poll.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/15 21:12:19 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/
define("POLL_ADLAN04", "O plugin de pesquisas foi instalado com sucesso. Para adicionar pesquisas, clique no ícone Pesquisas na área de plugins de sua página inicial de admin, e lembre-se de ativar o item de menu na página de menus.");
define("LAN_AL_POLL_02", "Enquete atualizada");
define("LAN_AL_POLL_03", "Enquete adicionada");
