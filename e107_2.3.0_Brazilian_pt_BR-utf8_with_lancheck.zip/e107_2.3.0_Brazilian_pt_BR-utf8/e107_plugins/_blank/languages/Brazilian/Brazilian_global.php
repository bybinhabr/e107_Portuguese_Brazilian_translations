<?php

// define("EXAMPLE","Generated Empty Language File");define("LAN_PLUGIN__BLANK_NAME", "Plugin em branco");
define("LAN_PLUGIN__BLANK_DIZ", "Um Plugin em branco para ajudá-lo a começar no desenvolvimento de plugin. Mais detalhes podem ser adicionados aqui.");
define("LAN_PLUGIN__BLANK_LINK", "Link em branco");
define("LAN_PLUGIN__BLANK_NAME", "Plugin em branco");

