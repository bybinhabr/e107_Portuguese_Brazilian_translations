<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/linkwords/languages/Portuguese_log.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/28 19:38:55 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_AL_LINKWD_00", "Mensagem relacionada à palavra-link");
define("LAN_AL_LINKWD_01", "Palavra-link adicionada");
define("LAN_AL_LINKWD_02", "Palavra-link editada");
define("LAN_AL_LINKWD_03", "Palavra-link deletada");
define("LAN_AL_LINKWD_04", "Opções atualizadas para Palavra-link");
define("LAN_AL_LINKWD_05", "Versão do plugin Palavras-link atualizada");
// define("LAN_AL_LINKWD_06", " ");


