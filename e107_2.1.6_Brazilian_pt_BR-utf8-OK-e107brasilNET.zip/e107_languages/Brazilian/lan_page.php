<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/lan_page.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LAN_PAGE_1", "A listagem da página está desativada");
define("LAN_PAGE_2", "Não há nenhuma página");
define("LAN_PAGE_3", "A página requisitada não existe ou você não tem permissão para acessá-la! Faça login e tente novamente.");
define("LAN_PAGE_4", "Avaliar esta página");
define("LAN_PAGE_5", "Obrigado por avaliar esta página");
define("LAN_PAGE_6", "Você não tem permissão para visualizar esta página");
// define("LAN_PAGE_7", "Senha incorreta");
define("LAN_PAGE_8", "Senha de Proteção de Página");
// define("LAN_PAGE_9", "Senha");
// define("LAN_PAGE_10", "Enviar");
define("LAN_PAGE_11", "Lista da Página");
define("LAN_PAGE_12", "Página Restrita");
define("LAN_PAGE_13", "Página");


define("LAN_PAGE_15", "Artigos");
define("LAN_PAGE_16", "Não há nenhum capítulos neste livro");

define("LAN_PAGE_14", "Outros artigos");
