<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/lan_newspost.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("NWSLAN_1", "Notícia apagada.");
define("NWSLAN_2", "Clique na caixa para confirmar que quer apagar este item de notícia.");
define("NWSLAN_3", "Não há notícias por enquanto.");
define("NWSLAN_4", "Notícias Existentes");
define("NWSLAN_5", "Abrir o editor HTML");
define("NWSLAN_6", "Categoria");
define("NWSLAN_7", "Editar");
define("NWSLAN_8", "Apagar");
define("NWSLAN_9", "clique para confirmar");
define("NWSLAN_10", "Não há categorias ainda.");
define("NWSLAN_11", "Adicionar/Editar Categorias");
define("NWSLAN_12", "Título");
define("NWSLAN_13", "Texto");
define("NWSLAN_14", "Estendido");
define("NWSLAN_15", "Comentários");
define("NWSLAN_16", "Ativado(s)");
define("NWSLAN_17", "Desativado(s)");
define("NWSLAN_18", "Permitir comentários para este item de notícia");
define("NWSLAN_19", "Ativação");
define("NWSLAN_20", "Deixar em branco para desabilitar a auto-ativação");
define("NWSLAN_21", "Ativo entre");
define("NWSLAN_22", "Visibilidade:");
define("NWSLAN_23", "Se selecionar vai fazer este item ficar ativo para os usuários da classe, apenas");
define("NWSLAN_24", "Visualizar novamente");
define("NWSLAN_25", "Atualizar a notícia na base de dados");
define("NWSLAN_26", "Gravar a notícia na base de dados");
define("NWSLAN_27", "Visualizar");
define("NWSLAN_28", "Novo artigo");
define("NWSLAN_29", "Postar Notícia");
define("NWSLAN_30", "Ver somente o título");


?>