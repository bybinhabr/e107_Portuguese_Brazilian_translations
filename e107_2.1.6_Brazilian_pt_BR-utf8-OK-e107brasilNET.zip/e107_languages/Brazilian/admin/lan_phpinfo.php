<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("PHP_LAN_1", "Se você tiver Curl habilitado, você deve considerar desabilitar esse recurso.");
define("PHP_LAN_2", "Este é um risco de segurança e não é necessário por e107.");
define("PHP_LAN_3", "Em um servidor de produção, é melhor desativar a exibição de erros no navegador.");
define("PHP_LAN_4", "Desabilitar este irá esconder a sua versão do PHP de navegadores.");
define("PHP_LAN_5", "Este é um risco de segurança e deve ser desativado.");
define("PHP_LAN_6", "[b]session.save_path[/b] não é gravável. Isso pode causar problemas com seu site.");
