<?php
/*
	**** Tradu��o Original
|Brazilian_portuguese Translation, 2004
|Author: Claytom Valle
|E-mail: claytomv@yahoo.com
	**** Revis�o
|Revis�o da Tradu��o para Portugu�s do Brasil 10/2004
|Autor: PHPautH e Colaboradores
|WebSite: http://www.e107.com.br
*/
define("CUSLAN_1", "Ficaram campos em branco.");
define("CUSLAN_2", "Imposs�vel criar menu de usu�rio - assegure-se de que ");
define("CUSLAN_3", "o diret�rio 'custom' de usu�rios est� com CHMOD 777.");
define("CUSLAN_4", "Menu de usu�rios atualizado.");
define("CUSLAN_5", "Menu de usu�rios criado com sucesso. Para ativ�-lo, v� para a janela de menus.");
define("CUSLAN_6", "Imposs�vel abrir o menu");
define("CUSLAN_7", "para leitura");
define("CUSLAN_8", "Menus existentes");
define("CUSLAN_9", "Editar");
define("CUSLAN_10", "Nenhum");
define("CUSLAN_11", "Nome do arquivo do Menu");
define("CUSLAN_12", "T�tulo do menu");
define("CUSLAN_13", "Texto do Menu");
define("CUSLAN_14", "Visualizar de novo");
define("CUSLAN_15", "Visualizar");
define("CUSLAN_16", "Atualizar menu de usu�rios");
define("CUSLAN_17", "Criar Menu de usu�rios");
define("CUSLAN_18", "Menus de Usu�rios");
define("CUSLAN_19", "P�ginas Existentes");
define("CUSLAN_20", "Imposs�vel criar a Custom Page - Por favor tente novamente ");
define("CUSLAN_21", "O diret�rio das Custom Pages deve ter CHMOD 777.");
define("CUSLAN_22", "Menu");
define("CUSLAN_23", "P�gina");
define("CUSLAN_24", "P�gina feita sob encomenda criada com sucesso. A URL ser�:");
define("CUSLAN_25", "Criar um link no menu principal?");
define("CUSLAN_26", "Link setado para todos e aberta na mesma janela!");
define("CUSLAN_27", "Você j� possui um link no menu principal para este conte�do");
define("CUSLAN_28", "Link para esta p�gina criada agora!  V� para a sua se��o de links e atualize-os para exibi��o.");
define("CUSLAN_29", "e107_plugins/custompages/");
define("CUSLAN_30", "Se requerido edite as propriedades dos links aqui ");


?>