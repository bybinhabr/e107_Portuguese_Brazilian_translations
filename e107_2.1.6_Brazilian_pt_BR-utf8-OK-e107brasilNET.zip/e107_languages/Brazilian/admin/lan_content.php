<?php
/*
	**** Tradu��o Original
|Brazilian_portuguese Translation, 2004
|Author: Claytom Valle
|E-mail: claytomv@yahoo.com
	**** Revis�o
|Revis�o da Tradu��o para Portugu�s do Brasil 10/2004
|Autor: PHPautH e Colaboradores
|WebSite: http://www.e107.com.br
*/
define("CNTLAN_1", "Ficaram campos em branco.");
define("CNTLAN_2", "Conte�do atualizado na base de dados.");
define("CNTLAN_3", "Clique para confirmar que quer apagar este conte�do");
define("CNTLAN_4", "N�o h� p�ginas de conte�dos.");
define("CNTLAN_5", "P�ginas de conte�dos existentes");
define("CNTLAN_6", "Editar");
define("CNTLAN_7", "Apagar");
define("CNTLAN_8", "Clique para confirmar");
define("CNTLAN_9", "Abrir o editor HTML");
define("CNTLAN_10", "Nome do Link");
define("CNTLAN_11", "T�tulo da P�gina");
define("CNTLAN_12", "Conte�do");
define("CNTLAN_13", "Permitir coment�rios");
define("CNTLAN_14", "Sim");
define("CNTLAN_15", "N�o");
define("CNTLAN_16", "Atualizar p�gina de conte�do");
define("CNTLAN_17", "Enviar p�gina de conte�do");
define("CNTLAN_18", "P�ginas de Conte�dos");
define("CNTLAN_19", "Vis�vel para");
define("CNTLAN_20", "P�gina de conte�do apagada.");
define("CNTLAN_21", "Salto de linha autom�tico");
define("CNTLAN_22", "(se est� postando com c�digo HTML, deve selecionar isto com N�o)");
define("CNTLAN_23", "P�gina de conte�do adicionada sem link - para ligar a essa p�gina, use esta URL");
define("CNTLAN_24", "P�gina de conte�do adicionada e link criado no Menu Principal");
define("CNTLAN_25", "T�tulo");
define("CNTLAN_26", "Op��es");
define("CNTLAN_27", "Tem certeza que quer apagar este conte�do?");
define("CNTLAN_28", "Adicionar �cones de impress�o/envio de e-mails?");
define("CNTLAN_29", "Sim");
define("CNTLAN_30", "N�o");


?>