<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_cpage.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("CUSLAN_1", "Visão geral");
define("CUSLAN_2", "Título da página");
define("CUSLAN_3", "Itens por página");
define("CUSLAN_4", "Campos personalizados");
define("CUSLAN_5", "(Novo livro)");
define("CUSLAN_9", "Texto");
define("CUSLAN_11", "Página Inicial");
define("CUSLAN_12", "Criar Página");
define("CUSLAN_29", "Lista páginas se não houver páginas selecionadas");
define("CUSLAN_30", "Tempo para expirar o cookie <b>(em segundos)</b>");
define("CUSLAN_31", "Criar Menu");
define("CUSLAN_48", "Listagem de Páginas");
define("CUSLAN_49", "Listagem de Menus");
define("CUSLAN_50", "Lista de livros/capítulos");
define("CUSLAN_51", "Adicionar livro/capítulo");
define("CUSLAN_52", "Livro");
define("CUSLAN_53", "Livro ou capítulo de título");
define("CUSLAN_55", "Pode ser editado pelo");
define("CUSLAN_56", "Pai");
define("CUSLAN_57", "Por favor, escolha uma única SEF URL para esta entrada.");
define("CUSLAN_58", "Páginas de exibição neste capítulo");
define("CUSLAN_59", "Página de vídeo");
define("CUSLAN_60", "Opções de página");
define("CUSLAN_61", "Menu de");
define("CUSLAN_62", "Opções do menu");
define("CUSLAN_63", "Livro/capítulo");
define("CUSLAN_64", "Nome do menu");
define("CUSLAN_65", "Título do menu");
define("CUSLAN_66", "Corpo de menu");
define("CUSLAN_67", "Modelo de menu");
define("CUSLAN_68", "Texto de botão personalizado");
define("CUSLAN_69", "URL do botão personalizado");
define("CUSLAN_70", "Ícone/glifo de menu");
define("CUSLAN_71", "Menu imagem/vídeo");
define("CUSLAN_72", "Modelo de lista de livros/capítulos");
define("CUSLAN_73", "Menu criado");
define("CUSLAN_74", "Menu atualizado");
define("CUSLAN_75", "Desaparecida-id Menu detectado:");
define("CUSLAN_76", "Menu com caminho #");
define("CUSLAN_77", "excluído");
define("CUSLAN_78", "Não há como deletar um menu com caminho");
define("CUSLAN_79", "Você deve digitar um nome de menu ou um título de página.");


?>