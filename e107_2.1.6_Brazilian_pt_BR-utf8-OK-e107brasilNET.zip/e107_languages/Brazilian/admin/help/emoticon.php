<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = "Marque a caixa para ter emoticons em forma de texto convertidos para emoticons em imagens.<br /><br />
Digite qualquer atualização que você quiser nas caixas de texto, e clique em salvar para atualizar as opções. Use o formulário no rodapé da página para adicionar novos emoticons.";

$ns -> tablerender("Emoticons", $text);
?>
