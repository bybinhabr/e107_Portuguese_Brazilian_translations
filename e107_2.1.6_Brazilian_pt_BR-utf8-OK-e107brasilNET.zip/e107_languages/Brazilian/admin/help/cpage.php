<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = "Nesta tela você pode criar menus ou páginas customizadas (custom menus) com o conteúdo que você quiser.<br /><br />
Favor ver os documentos de como usar as Páginas e Menus Customizados (Custom Pages e Custom Menus) para conhecer todas as funções.";
$ns -> tablerender(CUSLAN_18, $text);
?>

