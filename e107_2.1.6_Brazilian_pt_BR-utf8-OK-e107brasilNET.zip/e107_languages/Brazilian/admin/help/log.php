<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2005-2006             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = "Ative as estatísticas do site nesta página. Se você tem pouco espaço no servidor, marque a opção de 'só domínio' no tipo de log, isso irá guardar o domínio ao invés do endereço completo da url, por exemplo 'jalist.com' no lugar de 'http://jalist.com/links.php' ";
$ns -> tablerender("Estatísticas dos Logs", $text);
?>
