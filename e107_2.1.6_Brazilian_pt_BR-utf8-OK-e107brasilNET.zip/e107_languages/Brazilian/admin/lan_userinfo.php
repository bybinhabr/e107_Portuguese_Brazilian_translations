<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_userinfo.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("USFLAN_1", "Impossível encontrar o endereço IP do autor - não há informação disponível.");
define("USFLAN_3", "Mensagens postadas do endereço IP");
define("USFLAN_4", "Host ");
define("USFLAN_5", "Clique aqui para transferir o endereço IP para a página de banidos");
define("USFLAN_6", "ID do Usuário");
define("USFLAN_7", "Informação do Usuário");


?>