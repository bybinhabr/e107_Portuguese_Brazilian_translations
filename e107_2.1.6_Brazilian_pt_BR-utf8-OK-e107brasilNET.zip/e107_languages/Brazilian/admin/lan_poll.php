<?php
/*
	**** Tradu��o Original
|Brazilian_portuguese Translation, 2004
|Author: Claytom Valle
|E-mail: claytomv@yahoo.com
	**** Revis�o
|Revis�o da Tradu��o para Portugu�s do Brasil 10/2004
|Autor: PHPautH e Colaboradores
|WebSite: http://www.e107.com.br
*/
define("POLLAN_1", "Apagar cancelado.");
define("POLLAN_2", "Sem pesquisas no momento");
define("POLLAN_3", "Pesquisas existentes");
define("POLLAN_4", "Editar");
define("POLLAN_5", "Apagar");
define("POLLAN_6", "clique para confirmar");
define("POLLAN_7", "Quest�o para Pesquisa");
define("POLLAN_8", "Op��o");
define("POLLAN_9", "Adicionar outra op��o");
define("POLLAN_10", "Estado da pesquisa");
define("POLLAN_11", "Inativa");
define("POLLAN_12", "Ativa - Permitir votos de todos");
define("POLLAN_13", "Ativa - permitir votos s� de membros");
define("POLLAN_14", "Visualizar de novo");
define("POLLAN_15", "Atualizar a pesquisa na base de dados");
define("POLLAN_16", "Gravar a pesquisa na base de dados");
define("POLLAN_17", "Visualizar");
define("POLLAN_18", "Limpar");
define("POLLAN_19", "Pesquisas");
define("POLLAN_20", "Op��es");
define("POLLAN_21", "Quer mesmo apagar esta Pesquisa?");
define("POLLAN_22", "Sem Pesquisas");
define("POLLAN_23", "Visualizar enquete");
define("POLLAN_24", "Permitir coment�rios nesta enquete?");
define("POLLAN_25", "Sim");
define("POLLAN_26", "N�o");


?>