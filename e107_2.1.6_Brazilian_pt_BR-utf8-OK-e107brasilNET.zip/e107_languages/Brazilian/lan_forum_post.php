<?php
/*
	**** Tradu��o Original
|Brazilian_portuguese Translation, 2004
|Author: Claytom Valle
|E-mail: claytomv@yahoo.com
	**** Revis�o
|Revis�o da Tradu��o para Portugu�s do Brasil 10/2004
|Autor: PHPautH e Colaboradores
|WebSite: http://www.e107.com.br
*/
define("PAGE_NAME", "F�rum");
define("LAN_01", "F�runs");
define("LAN_02", "Respondendo para: ");
define("LAN_03", "Novo Debate");
define("LAN_1", "Normal");
define("LAN_2", "Anexada");
define("LAN_3", "An�ncios");
define("LAN_4", "Postar Pesquisa");
define("LAN_5", "Quest�o para Pesquisa:");
define("LAN_6", "Adicionar outra op��o");
define("LAN_7", "Op��o de Voto:");
define("LAN_8", "Permitir votos de todos");
define("LAN_9", "Permitir votos s� de membros");
define("LAN_10", "Login");
define("LAN_11", "Lembrar meu login");
define("LAN_16", "Nome do Usu�rio: ");
define("LAN_17", "Senha: ");
define("LAN_20", "Erro");
define("LAN_27", "Deixou campo(s) obrigat�rio(s) em branco");
define("LAN_28", "Voc� n�o postou nada...");
define("LAN_29", "Editado");
define("LAN_45", "Estes f�runs s� podem ser postados por membros registrados e com login efetuado.");
define("LAN_60", "Iniciar Novo Debate");
define("LAN_61", "O seu Nome: ");
define("LAN_62", "Assunto: ");
define("LAN_63", "Post: ");
define("LAN_64", "Submeter novo detabe");
define("LAN_73", "Responder: ");
define("LAN_74", "Responder ao debate");
define("LAN_77", "Atualizar Debate");
define("LAN_78", "Atualizar Resposta");
define("LAN_94", "Postado por");
define("LAN_95", "N�o autorizado");
define("LAN_96", "N�o est� autorizado a editar esta postagem.");
define("LAN_100", "Primeira postagem");
define("LAN_101", "�ltimas 10 postagens");
define("LAN_102", " respostas");
define("LAN_103", "Rever debate completo. (Abrir� nova janela.)");
define("LAN_133", "Obrigado");
define("LAN_174", "Registrar");
define("LAN_175", "Login");
define("LAN_212", "Esqueceu a senha?");
define("LAN_310", "Imposs�vel aceitar esta postagem devido ao usu�rio n�o ser registrado - se por acaso � o seu nome de usu�rio, efetue o login para postar.");
define("LAN_311", "An�nimo");
define("LAN_322", "Postado: ");
define("LAN_323", "Visualizar");
define("LAN_324", "A sua mensagem foi postada corretamente.");
define("LAN_325", "Clique aqui para ver sua mensagem");
define("LAN_326", "Clique aqui para voltar ao f�rum");
define("LAN_327", "Rever");
define("LAN_380", "Se desejar ser notificado quando existir alguma resposta � postagem, clique na caixa ");
define("LAN_381", "Resposta ao f�rum de ");
define("LAN_382", "Postagem efetuada: ");
define("LAN_383", "Clique no link seguinte para ver todo o debate...");
define("LAN_384", "Resposta ao F�rum em ");
define("LAN_385", "Postagem: ");
define("LAN_386", "Se n�o deseja adicionar uma pesquisa � sua postagem, deixe os campos em branco ");
define("LAN_387", "Ir");
define("LAN_388", "Voltar ao topo");
define("LAN_389", "Postagem duplicada; redirecionando...");
define("LAN_390", "Anexar arquivo/imagem");
define("LAN_391", "Op��o");
define("LAN_392", "Arquivo a anexar");
define("LAN_393", "<b>Tome nota</b><br />Arquivos permitidos:");
define("LAN_394", "Qualquer outro tipo ser� apagado de imediato.");
define("LAN_395", "Tamanho m�ximo de arquivo");
define("LAN_396", "bytes");
define("LAN_397", "Este assunto est� fechado.");
define("LAN_398", "Este f�rum � s� de leitura");
define("LAN_399", "N�o est� autorizado(a) a postar neste f�rum.");
define("LAN_400", "postagem tratada como");
define("LAN_401", "Ir para");
define("LAN_402", "Enquete");
define("LAN_403", "An�ncio");
define("LAN_404", "anexado");
define("LAN_405", "F�runs");
define("LAN_406", "Res:");
define("LAN_407", "Redirecionamento");
define("LAN_408", "Se seu navegador n�o suporta meta-redirecionamento, por favor clique");
define("LAN_409", "AQUI");
define("LAN_410", "para ser redirecionado.");
define("LAN_411", "Clique AQUI");
define("LAN_412", "para se registrar!.");


?>