<?php
/*
	**** Tradu��o Original
|Brazilian_portuguese Translation, 2004
|Author: Claytom Valle
|E-mail: claytomv@yahoo.com
	**** Revis�o
|Revis�o da Tradu��o para Portugu�s do Brasil 10/2004
|Autor: PHPautH e Colaboradores
|WebSite: http://www.e107.com.br
*/
define("PAGE_NAME", "Estat�sticas");
define("LAN_124", "Total de visitas �nicas ao site: ");
define("LAN_125", "Total de visitas ao site: ");
define("LAN_126", "Visitas �nicas por p�gina: ");
define("LAN_127", "Total de visitas por p�gina: ");
define("LAN_128", "Browser: ");
define("LAN_129", "Sistema Operacional: ");
define("LAN_130", "Visitas de pa�ses/dom�nios: ");
define("LAN_131", "Pesquisas: ");
define("LAN_132", "Estat�sticas do Site");
define("LAN_371", "Os registros n�o est�o ativos. Para ativ�-los, v� � se��o de administra��o, clique em Logs e na caixa de Ativar Log/Contadores.");
define("LAN_372", "Esta fun��o n�o est� ativada para esta p�gina.");
define("LAN_373", "N�o h� estat�sticas no momento.");
define("LAN_374", "O registro come�ou em:");
define("LAN_375", "Ver tudo");
define("LAN_376", "�ltimas 10 visitas");
define("LAN_377", "Todos");
define("LAN_378", "Os 10 mais");
define("LAN_379", "Resolu��es de tela");
define("LAN_418", " dias atr�s");
define("LAN_419", "M�dia di�ria");
define("LAN_420", "M�dia Semanal");
define("LAN_421", "M�dia Mensal");
define("LAN_422", "N�o foi calculado ainda");


?>