<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/lan_banner.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Banner");
define("BANNERLAN_16", "Usuário:");
define("BANNERLAN_17", "Senha:");
define("BANNERLAN_18", "Continuar");
define("BANNERLAN_19", "Favor digitar seu login e senha para continuar");
define("BANNERLAN_20", "Desculpe, não encontramos seus detalhes no banco de dados. Favor entrar em contato com o administrador para detalhes.");
define("BANNERLAN_21", "Estatísticas de Banners");
define("BANNERLAN_22", "Cliente");
define("BANNERLAN_23", "ID do Banner");
define("BANNERLAN_24", "Cliques recebidos");
define("BANNERLAN_25", "Cliques em %");
define("BANNERLAN_26", "Impressões");
define("BANNERLAN_27", "Impressões Compradas");
define("BANNERLAN_28", "Impressões Restantes");
define("BANNERLAN_29", "Não há banners");
define("BANNERLAN_30", "Ilimitado");
define("BANNERLAN_31", "Não aplicável");
define("BANNERLAN_32", "Sim");
define("BANNERLAN_33", "Não");
define("BANNERLAN_34", "Termina em:");
define("BANNERLAN_35", "IPs dos Cliques");
define("BANNERLAN_36", "Ativado em:");
define("BANNERLAN_37", "Começa em:");
define("BANNERLAN_38", "Erro");


?>