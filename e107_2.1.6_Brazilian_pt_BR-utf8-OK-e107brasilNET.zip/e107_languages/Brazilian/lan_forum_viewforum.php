<?php
/*
	**** Tradu��o Original
|Brazilian_portuguese Translation, 2004
|Author: Claytom Valle
|E-mail: claytomv@yahoo.com
	**** Revis�o
|Revis�o da Tradu��o para Portugu�s do Brasil 10/2004
|Autor: PHPautH e Colaboradores
|WebSite: http://www.e107.com.br
*/
define("PAGE_NAME", "F�rum");
define("LAN_01", "F�runs");
define("LAN_02", "Voltar ao Topo");
define("LAN_03", "Ir");
define("LAN_53", "T�pico");
define("LAN_54", "Iniciado por ");
define("LAN_55", "Respostas");
define("LAN_56", "Visualiza��es");
define("LAN_57", "�ltimo post");
define("LAN_58", "N�o h� t�picos neste f�rum por enquanto.");
define("LAN_59", "Tem de ser um membro registrado e com o login efetuado para poder postar neste f�rum.");
define("LAN_79", "Novas postagens");
define("LAN_80", " N�o h� novas postagens");
define("LAN_81", "T�pico Fechado");
define("LAN_180", "Procurar");
define("LAN_202", "Anexada");
define("LAN_203", "Anexada/Fechada");
define("LAN_204", "Voc� <b>pode</b> iniciar novos debates");
define("LAN_205", "Voc� <b>n�o pode</b> iniciar novos debates");
define("LAN_206", "Voc� <b>pode</b> responder");
define("LAN_207", "Voc� <b>n�o pode</b> responder");
define("LAN_208", "Voc� <b>pode</b> editar as suas postagens");
define("LAN_209", "Voc� <b>n�o pode</b> editar as suas postagens");
define("LAN_316", "Ir para a p�gina ");
define("LAN_317", "Nenhuma");
define("LAN_321", "Moderadores: ");
define("LAN_395", "[popular]");
define("LAN_396", "An�ncios");
define("LAN_397", "Este f�rum � s� de leitura");
define("LAN_398", "Desmarcar t�pico");
define("LAN_399", "Travar t�pico");
define("LAN_400", "Destravar t�pico");
define("LAN_401", "Marcar t�pico");
define("LAN_402", "Mover t�pico");
define("LAN_403", "Ir para f�rum");
define("LAN_404", "Este f�rum � moderado por ");
define("LAN_405", "usu�rio est� vendo este f�rum no momento");
define("LAN_406", "usu�rios est�o vendo este f�rum no momento");
define("LAN_407", "membro");
define("LAN_408", "convidado");
define("LAN_409", "membros");
define("LAN_410", "convidados");
define("LAN_411", "T�picos Importantes");
define("LAN_412", "F�rum T�picos");
define("FORLAN_CLOSE", "T�pico fechado.");
define("FORLAN_OPEN", "T�pico reaberto.");
define("FORLAN_STICK", "T�pico marcado.");
define("FORLAN_UNSTICK", "T�pico destravado.");
define("FORLAN_6", "T�pico deletado");
define("FORLAN_7", "r�plicas deletadas");
define("FORLAN_8", "Clique AQUI");
define("FORLAN_9", "para registrar ou efetue o login do menu de login.");
define("FORLAN_10", "Começar novo t�pico");
define("FORLAN_11", "Novas Postagens");
define("FORLAN_12", "N�o h� novos posts");
define("FORLAN_13", "Novas mensagens nos T�picos Populares");
define("FORLAN_14", "N�o h� novas mensagens em T�picos Populares");
define("FORLAN_15", "T�pico Marcado");
define("FORLAN_16", "T�pico Marcado fechado");
define("FORLAN_17", "T�pico de An�ncio");
define("FORLAN_18", "T�pico Fechado");


?>