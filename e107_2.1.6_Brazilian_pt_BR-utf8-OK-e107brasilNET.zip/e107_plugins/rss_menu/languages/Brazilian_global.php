<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/rss_menu/languages/Portuguese_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/14 19:13:37 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/
define("LAN_PLUGIN_RSS_NAME", "RSS Feed");
define("LAN_PLUGIN_RSS_DESCRIPTION", "Alimentadores RSS do seu site.");
define("LAN_PLUGIN_RSS_SUBSCRIBE", "Inscreva-se");
define("LAN_PLUGIN_RSS_SUBSCRIBE_TO", "Inscrever-se [x]");
