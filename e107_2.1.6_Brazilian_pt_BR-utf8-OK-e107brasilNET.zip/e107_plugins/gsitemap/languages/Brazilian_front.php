<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/gsitemap/languages/Portuguese_front.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/15 21:13:01 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("GSLAN_Name", "Mapa do Site");


?>