<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/newsfeed/languages/Portuguese_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/21 21:57:06 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_NEWSFEEDS_NAME", "Alimentadores de Notícias (Newsfeeds)");
define("LAN_PLUGIN_NEWSFEEDS_DESCRIPTION", "Este plugin vai alimentar seu site com notícias RSS de outros sites e mostrar de acordo com suas preferências.");


?>