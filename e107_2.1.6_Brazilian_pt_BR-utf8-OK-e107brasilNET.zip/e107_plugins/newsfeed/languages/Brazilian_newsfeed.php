<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/newsfeed/languages/Portuguese_newsfeed.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/28 19:37:19 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("NFLAN_29", "Alimentadores de Notícias disponíveis");
define("NFLAN_31", "Voltar para a lista de alimentadores de notícias");
define("NFLAN_33", "Data da publicação:");
define("NFLAN_34", "desconhecido");
define("NFLAN_38", "Chamadas");
define("NFLAN_39", "Detalhes");
define("NFLAN_48", "Não há como salvar dados no banco de dados.");


?>