<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/forum/languages/Portuguese_Brazilian/lan_forum_uploads.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Uploads do Fórum");
define("FRMUP_1", "Arquivos enviados no fórum");
define("FRMUP_2", "Arquivo apagado");
define("FRMUP_3", "Erro: Impossível apagar este arquivo");
define("FRMUP_4", "Apagamento do arquivo");
define("FRMUP_5", "Nome do arquivo");
define("FRMUP_6", "Resultado");
define("FRMUP_7", "Encontrado no tópico");
define("FRMUP_8", "NÃO ENCONTRADO");
define("FRMUP_9", "Não há arquivos enviados");
define("FRMUP_10", "Apagar");


?>