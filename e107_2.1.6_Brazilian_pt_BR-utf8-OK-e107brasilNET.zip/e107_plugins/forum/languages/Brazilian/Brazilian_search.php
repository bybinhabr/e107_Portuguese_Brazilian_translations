<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/forum/languages/Portuguese/Portuguese_search.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/18 21:46:15 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/
define("FOR_SCH_LAN_2", "Procurar no Fórum");
define("FOR_SCH_LAN_4", "Postagem completa");
define("FOR_SCH_LAN_5", "Como parte da discussão");


?>