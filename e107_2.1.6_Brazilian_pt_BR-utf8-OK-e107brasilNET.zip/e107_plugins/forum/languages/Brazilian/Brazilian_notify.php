<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/forum/languages/Portuguese/Portuguese_notify.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/21 21:44:11 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/
define("LAN_FORUM_NT_7", "Fórum - Tópico criado por novo usuário");
define("LAN_FORUM_NT_8", "Fórum - Tópico deletado");
define("LAN_FORUM_NT_9", "Fórum - Tópico dividido");
define("LAN_FORUM_NT_10", "Fórum - Postagem deletada");
define("LAN_FORUM_NT_11", "Fórum - Postagem reportada");
define("LAN_FORUM_NT_NEWTOPIC", "Novo tópico criado");
define("LAN_FORUM_NT_NEWTOPIC_PROB", "Novo tópico criado por membro em análise");
define("LAN_FORUM_NT_TOPIC_DELETED", "Tópico deletado");
define("LAN_FORUM_NT_TOPIC_SPLIT", "Tópico dividido");
define("LAN_FORUM_NT_POST_DELETED", "Postagem deletada");
define("LAN_FORUM_NT_POST_REPORTED", "Postagem reportada");


?>