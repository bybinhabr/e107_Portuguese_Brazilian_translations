<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/trackback/languages/Portuguese_admin_trackback.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/14 17:31:38 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/
define("TRACKBACK_L7", "Ativar trackback");
define("TRACKBACK_L8", "Texto da URL do Trackback");
define("TRACKBACK_L10", "Configurações de Trackback");
define("TRACKBACK_L11", "Endereço Trackback para esta postagem:");
define("TRACKBACK_L12", "Sem trackbacks para este item");
define("TRACKBACK_L13", "Moderar trackbacks");
define("TRACKBACK_L16", "Trackback Plugin");
