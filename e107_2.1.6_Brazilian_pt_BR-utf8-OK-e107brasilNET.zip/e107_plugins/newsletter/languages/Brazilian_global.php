<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/newsletter/languages/Portuguese_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/21 21:55:09 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/
define("LAN_PLUGIN_NEWSLETTER_NAME", "Newsletter Plugin");
define("LAN_PLUGIN_NEWSLETTER_DESCRIPTION", "Provê um jeito rápido de configurar e enviar newsletters.");
