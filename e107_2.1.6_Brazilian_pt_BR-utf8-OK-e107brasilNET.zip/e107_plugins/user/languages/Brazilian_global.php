<?php

// define("EXAMPLE","Generated Empty Language File");define("LAN_PLUGIN_USER_NAME", "Usuário");
define("LAN_PLUGIN_USER_DESC", "Tema de usuário e Menus de idioma");
define("LAN_PLUGIN_USER_NAME", "Usuário");

