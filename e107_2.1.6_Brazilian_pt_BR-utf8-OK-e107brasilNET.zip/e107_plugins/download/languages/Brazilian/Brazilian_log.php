<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/download/languages/Portuguese/Portuguese_log.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/19 01:37:22 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/
define("LAN_AL_DOWNL_01", "Downloads - opções de download modificadas");
define("LAN_AL_DOWNL_02", "Downloads - opções de upload modificadas");
define("LAN_AL_DOWNL_03", "Downloads - limite adicionado");
define("LAN_AL_DOWNL_04", "Downloads -- log 04");
define("LAN_AL_DOWNL_05", "Downloads -- log 05");
define("LAN_AL_DOWNL_06", "Downloads -- log 06");
define("LAN_AL_DOWNL_07", "Downloads -- log 07");
define("LAN_AL_DOWNL_08", "Downloads -- log 08");
define("LAN_AL_DOWNL_09", "Downloads -- log 09");
define("LAN_AL_DOWNL_10", "Downloads - limite atualizado");
define("LAN_AL_DOWNL_11", "Downloads - limite removido");
