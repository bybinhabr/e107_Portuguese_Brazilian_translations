<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/download/languages/Portuguese/Portuguese_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/16 20:21:36 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/
define("LAN_PLUGIN_DOWNLOAD_NAME", "Arquivos de Downloads");
define("LAN_PLUGIN_DOWNLOAD_DIZ", "Este plugin é um sistema completo de downloads de arquivos.");
