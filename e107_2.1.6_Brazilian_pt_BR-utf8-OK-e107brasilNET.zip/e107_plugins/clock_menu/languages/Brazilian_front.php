<?php

// define("EXAMPLE","Generated Empty Language File");define("CLOCK_MENU_L1", "Relógio menu configuração salvada");
define("CLOCK_MENU_L2", "Legenda");
define("CLOCK_MENU_L3", "Atualizar configurações de Menu");
define("CLOCK_MENU_L4", "Relógio Menu Config");
define("CLOCK_MENU_L5", "Segunda-feira,");
define("CLOCK_MENU_L6", "Terça-feira,");
define("CLOCK_MENU_L7", "Quarta-feira,");
define("CLOCK_MENU_L8", "Quinta-feira,");
define("CLOCK_MENU_L9", "Sexta-feira,");
define("CLOCK_MENU_L10", "Sábado,");
define("CLOCK_MENU_L11", "Domingo,");
define("CLOCK_MENU_L12", "Janeiro de");
define("CLOCK_MENU_L13", "Fevereiro");
define("CLOCK_MENU_L14", "Março de");
define("CLOCK_MENU_L15", "Abril");
define("CLOCK_MENU_L16", "Maio");
define("CLOCK_MENU_L17", "Junho de");
define("CLOCK_MENU_L18", "Julho");
define("CLOCK_MENU_L19", "Agosto");
define("CLOCK_MENU_L20", "Setembro de");
define("CLOCK_MENU_L21", "Outubro");
define("CLOCK_MENU_L22", "Novembro de");
define("CLOCK_MENU_L23", "Dezembro de");
define("CLOCK_MENU_L1", "Relógio menu configuração salvada");

