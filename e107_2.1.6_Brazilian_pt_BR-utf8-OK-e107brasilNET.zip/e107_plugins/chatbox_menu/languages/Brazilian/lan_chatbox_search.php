<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/chatbox_menu/languages/Portuguese_Brazilian/lan_chatbox_search.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("CB_SCH_LAN_1", "Área de Chat");


?>