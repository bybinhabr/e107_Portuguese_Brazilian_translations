<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/pm/languages/Portuguese_log.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/21 21:54:27 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_AL_PM_ADM_01", "MP: Preferências padrão utilizadas");
define("LAN_AL_PM_ADM_02", "MP: Preferências atualizadas");
define("LAN_AL_PM_ADM_03", "MP: Manutenção no Banco de Dados completada");
define("LAN_AL_PM_ADM_04", "MP: Manutenção no Banco de Dados iniciada");
define("LAN_AL_PM_ADM_05", "MP: Limite adicionado");
define("LAN_AL_PM_ADM_06", "MP: Limite atualizado");
define("LAN_AL_PM_ADM_07", "MP: Limite deletado");
define("LAN_AL_PM_ADM_08", "MP: Erro ao criar dados de limite");
define("LAN_AL_PM_ADM_09", "MP: Erro ao atualizar dados de limite");
define("LAN_AL_PM_ADM_10", "MP: Erro ao deletar dados de limite");


?>